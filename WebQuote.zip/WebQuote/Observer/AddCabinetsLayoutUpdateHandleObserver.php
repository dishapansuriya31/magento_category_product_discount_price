<?php
/**
 * Commercepundit
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Commercepundit.com license that is
 * available through the world-wide-web at this URL:
 * http://commercepundit.com/license
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category   Commercepundit
 * @package    Commercepundit_WebQuote
 * @copyright  Copyright (c) Commercepundit (http://www.commercepundit.com/)
 * @license    http://www.commercepundit.com/LICENSE-1.0.html
 */
namespace Commercepundit\WebQuote\Observer;

use Magento\Framework\Event;
use Magento\Framework\Event\Observer as EventObserver;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Registry;

/**
 *  AddCabinetsLayoutUpdateHandleObserver for layout update
 */
class AddCabinetsLayoutUpdateHandleObserver implements ObserverInterface
{
    /**
     * @const CABINETS_CATEGORY_LAYOUT_HANDLE_NAME
     */
    public const CABINETS_CATEGORY_LAYOUT_HANDLE_NAME = 'cabinets_category_view';

    /**
     * @const CATALOG_CATEGORY_LAYOUT_HANDLE_NAME
     */
    public const CATALOG_CATEGORY_LAYOUT_HANDLE_NAME = 'catalog_category_view';

    /**
     * @const CATALOG_PRODUCT_LAYOUT_HANDLE_NAME
     */
    public const CATALOG_PRODUCT_LAYOUT_HANDLE_NAME = 'catalog_product_view';

    /**
     * @const CABINETS_PRODUCT_LAYOUT_HANDLE_NAME
     */
    public const CABINETS_PRODUCT_LAYOUT_HANDLE_NAME = 'cabinets_product_view';

    /**
     * @const CUSTOM_CABINETS_CATEGORY_LAYOUT_HANDLE_NAME
     */
    public const CUSTOM_CABINETS_CATEGORY_LAYOUT_HANDLE_NAME = 'custom_cabinets_category_view';

    /**
     * @const CUSTOM_CABINETS_PRODUCT_LAYOUT_HANDLE_NAME
     */
    public const CUSTOM_CABINETS_PRODUCT_LAYOUT_HANDLE_NAME = 'custom_cabinets_product_view';

    /**
     * @const KITCHEN_CABINETS_CATEGORY_LAYOUT_HANDLE_NAME
     */
    public const KITCHEN_CABINETS_CATEGORY_LAYOUT_HANDLE_NAME = 'kitchen_cabinets_category_view';

    /**
     * @const KITCHEN_CABINETS_PRODUCT_LAYOUT_HANDLE_NAME
     */
    public const KITCHEN_CABINETS_PRODUCT_LAYOUT_HANDLE_NAME = 'kitchen_cabinets_product_view';

    /**
     * @const CABINETS_LAYOUT
     */
    public const CABINETS_LAYOUT = 'cabinets-layout';

    /**
     * @const CUSTOM_CABINETS_LAYOUT
     */
    public const CUSTOM_CABINETS_LAYOUT = 'custom-cabinets-layout';

    /**
     * @const KITCHEN_CABINETS_LAYOUT
     */
    public const KITCHEN_CABINETS_LAYOUT = 'kitchen-cabinets-layout';

    /**
     * @const WISHLIST_LAYOUT_HANDLE_NAME
     */
    public const WISHLIST_LAYOUT_HANDLE_NAME = 'wishlist_index_configure';

    /**
     * @const CUSTOM_CABINETS_WISHLIST_LAYOUT_HANDLE_NAME
     */
    public const CUSTOM_CABINETS_WISHLIST_LAYOUT_HANDLE_NAME = 'custom_cabinets_wishlist_index_configure';

    /**
     * @const CABINETS_WISHLIST_LAYOUT_HANDLE_NAME
     */
    public const CABINETS_WISHLIST_LAYOUT_HANDLE_NAME = 'cabinets_wishlist_index_configure';

    /**
     * @var Registry
     */
    private $registry;

    /**
     * Layout Update Constructor
     *
     * @param Registry      $registry
     */
    public function __construct(
        Registry    $registry
    ) {
        $this->registry     = $registry;
    }

    /**
     * Event Observer
     *
     * @param EventObserver $observer
     *
     * @return void
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @SuppressWarnings(PHPMD.NPathComplexity)
     */
    public function execute(EventObserver $observer)
    {
        /** @var Event $event */
        $event = $observer->getEvent();
        $actionName = $event->getData('full_action_name');
        $layoutHandle = $event->getLayout()->getUpdate();
        if ($actionName === self::CATALOG_CATEGORY_LAYOUT_HANDLE_NAME) {
            $category = $this->registry->registry('current_category');
            if (!empty($category)) {
                $pageLayout = $category->getPageLayout();
                switch ($pageLayout) {
                    case self::CABINETS_LAYOUT:
                        return $layoutHandle->addHandle(self::CABINETS_CATEGORY_LAYOUT_HANDLE_NAME);
                    case self::CUSTOM_CABINETS_LAYOUT:
                        return $layoutHandle->addHandle(self::CUSTOM_CABINETS_CATEGORY_LAYOUT_HANDLE_NAME);
                    case self::KITCHEN_CABINETS_LAYOUT:
                        return $layoutHandle->addHandle(self::KITCHEN_CABINETS_CATEGORY_LAYOUT_HANDLE_NAME);
                }
            }
        }
        if ($actionName == self::CATALOG_PRODUCT_LAYOUT_HANDLE_NAME) {
            $product = $this->registry->registry('current_product');
            if ($product) {
                $pageLayout = $product->getPageLayout();
                switch ($pageLayout) {
                    case self::CABINETS_LAYOUT:
                        return $layoutHandle->addHandle(self::CABINETS_PRODUCT_LAYOUT_HANDLE_NAME);
                    case self::CUSTOM_CABINETS_LAYOUT:
                        return $layoutHandle->addHandle(self::CUSTOM_CABINETS_PRODUCT_LAYOUT_HANDLE_NAME);
                }
            }
        }
        if ($actionName == self::WISHLIST_LAYOUT_HANDLE_NAME) {
            $product = $this->registry->registry('current_product');
            if ($product) {
                $pageLayout = $product->getPageLayout();
                switch ($pageLayout) {
                    case self::CABINETS_LAYOUT:
                        return $layoutHandle->addHandle(self::CABINETS_WISHLIST_LAYOUT_HANDLE_NAME);
                    case self::CUSTOM_CABINETS_LAYOUT:
                        return $layoutHandle->addHandle(self::CUSTOM_CABINETS_WISHLIST_LAYOUT_HANDLE_NAME);
                }
            }
        }
    }
}
