<?php
/**
 * Commercepundit
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Commercepundit.com license that is
 * available through the world-wide-web at this URL:
 * http://commercepundit.com/license
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category   Commercepundit
 * @package    Commercepundit_WebQuote
 * @copyright  Copyright (c) Commercepundit (http://www.commercepundit.com/)
 * @license    http://www.commercepundit.com/LICENSE-1.0.html
 */
namespace Commercepundit\WebQuote\Observer;

use Commercepundit\Checkout\Helper\Data as CheckoutHelper;
use Commercepundit\Customer\Helper\Import;
use Commercepundit\General\Model\Config\Source\Boolean;
use Commercepundit\Homemark\Helper\Data as HomemarkHelper;
use Commercepundit\WebQuote\Helper\Data as WebQuoteHelper;
use Magento\Framework\Event\Observer as EventObserver;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\App\RequestInterface;

class ApplyStyleForCabinets implements ObserverInterface
{
    /**
     * @var WebQuoteHelper
     */
    private $webQuoteHelper;

    /**
     * @var CheckoutHelper
     */
    private $checkoutHelper;

    /**
     * @var RequestInterface
     */
    private $request;

    /**
     * @var HomemarkHelper
     */
    protected $homemarkHelper;

    /**
     * @param WebQuoteHelper $webQuoteHelper
     * @param CheckoutHelper $checkoutHelper
     * @param RequestInterface $request
     * @param HomemarkHelper $homemarkHelper
     */
    public function __construct(
        WebQuoteHelper       $webQuoteHelper,
        CheckoutHelper       $checkoutHelper,
        RequestInterface     $request,
        HomemarkHelper $homemarkHelper
    ) {
        $this->webQuoteHelper = $webQuoteHelper;
        $this->checkoutHelper = $checkoutHelper;
        $this->request = $request;
        $this->homemarkHelper   = $homemarkHelper;
    }

    /**
     * Add Style Data to Quote Item
     *
     * @param EventObserver $observer
     */
    public function execute(EventObserver $observer)
    {
        $countertopPrice = $this->request->getPost('countertop_price') ?? Boolean::NO;
        $quoteItem = $observer->getEvent()->getQuoteItem();
        $product = $observer->getEvent()->getProduct();
        $quote = $quoteItem->getQuote();
        $this->checkoutHelper->updateQuoteShippingAddress($quote);
        if (!empty($product)) {
            if ($product->getIsSample() != Boolean::YES &&
                !in_array((string)$quoteItem->getSku(), $this->get2020ImportSkus())
            ) {
                $this->webQuoteHelper->setStyleDataItems($quoteItem, $product, $countertopPrice);
            }elseif ($product->getIsSample() && $this->homemarkHelper->isHomemark()){
                $this->webQuoteHelper->setStyleDataItems($quoteItem, $product, $countertopPrice);
            }
        }
        return $this;
    }

    /**
     * Get 2020 Import Skus
     *
     * @return array
     */
    private function get2020ImportSkus() {
        return [
            Import::SIGNATURE_PLUS_SKU,
            Import::CRAFTSMAN_SKU,
            Import::RTA_SKU
        ];
    }
}
