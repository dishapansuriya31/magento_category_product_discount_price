<?php
/**
 * Commercepundit
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Commercepundit.com license that is
 * available through the world-wide-web at this URL:
 * http://commercepundit.com/license
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category   Commercepundit
 * @package    Commercepundit_WebQuote
 * @copyright  Copyright (c) Commercepundit (http://www.commercepundit.com/)
 * @license    http://www.commercepundit.com/LICENSE-1.0.html
 */

namespace Commercepundit\WebQuote\Observer;

class Categoryattributes implements \Magento\Framework\Event\ObserverInterface
{
    private $category = null;
    protected $helper;

    public function __construct(
        \Commercepundit\WebQuote\Helper\Data $helper
    ){
        $this->helper = $helper;
    }

    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $this->category = $observer->getEvent()->getCategory();
        if($this->category->getIsNew() == true && !$this->category->getIsNewEndDate()){
            $endDate = $this->helper->getEndDateForNew();
            $this->category->setIsNewEndDate($endDate);
            $this->category->save();
        }
    }
}
