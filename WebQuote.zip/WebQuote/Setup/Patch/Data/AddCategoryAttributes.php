<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Commercepundit\WebQuote\Setup\Patch\Data;

use Commercepundit\WebQuote\Model\Category\Attribute\Source\Showmode;
use Commercepundit\WebQuote\Model\Config\Source\Color;
use Commercepundit\WebQuote\Model\Config\Source\Style;
use Magento\Catalog\Model\Category;
use Magento\Catalog\Model\Category\Attribute\Backend\Image;
use Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface;
use Magento\Eav\Model\Entity\Attribute\Source\Boolean;
use Magento\Eav\Setup\EavSetupFactory;
use Magento\Framework\Setup\Patch\DataPatchInterface;
use Magento\Framework\Setup\Patch\PatchRevertableInterface;

/**
 * AddCategoryAttributes Class for adding category attributes.
 *
 * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
 */
class AddCategoryAttributes implements DataPatchInterface, PatchRevertableInterface
{
    /**
     * @var \Magento\Framework\Setup\ModuleDataSetupInterface
     */
    private $moduleDataSetup;

    /**
     * @var EavSetupFactory
     */
    protected $eavSetupFactory;

    /**
     * @param \Magento\Framework\Setup\ModuleDataSetupInterface $moduleDataSetup
     * @param EavSetupFactory $eavSetupFactory
     */
    public function __construct(
        \Magento\Framework\Setup\ModuleDataSetupInterface $moduleDataSetup,
        EavSetupFactory $eavSetupFactory
    ) {
        /**
         * If before, we pass $setup as argument in install/upgrade function, from now we start
         * inject it with DI. If you want to use setup, you can inject it, with the same way as here
         */
        $this->moduleDataSetup = $moduleDataSetup;
        $this->eavSetupFactory = $eavSetupFactory;
    }

    /**
     * @inheritdoc
     */
    public function apply()
    {
        $eavSetup = $this->eavSetupFactory->create(['setup' => $this->moduleDataSetup]);

        $eavSetup->addAttribute(Category::ENTITY, 'heading_title', [
            'type' => 'text',
            'label' => 'H1 Title',
            'input' => 'text',
            'required' => 'false',
            'default' => '',
            'sort_order' => 3,
            'global' => ScopedAttributeInterface::SCOPE_STORE,
            'group' => 'Cp Custom',
        ]);
        $eavSetup->addAttribute(Category::ENTITY, 'shipping_time', [
            'type' => 'text',
            'label' => 'Shipping Time',
            'input' => 'text',
            'required' => 'false',
            'default' => '',
            'sort_order' => 3,
            'global' => ScopedAttributeInterface::SCOPE_STORE,
            'group' => 'Cp Custom',
        ]);
        $eavSetup->addAttribute(Category::ENTITY, 'sale_tag', [
            'type' => 'text',
            'label' => 'Sale Tag',
            'input' => 'text',
            'required' => 'false',
            'default' => '',
            'sort_order' => 3,
            'global' => ScopedAttributeInterface::SCOPE_STORE,
            'group' => 'Cp Custom',
        ]);
        $eavSetup->addAttribute(Category::ENTITY, 'specification', [
            'type' => 'text',
            'label' => 'Specification',
            'sort_order' => 4,
            'group' => 'Cp Custom',
            'input' => 'textarea',
            'required' => 'false',
            'global' => ScopedAttributeInterface::SCOPE_STORE,
            'wysiwyg_enabled' => true,
            'is_html_allowed_on_front' => true
        ]);
        $eavSetup->addAttribute(Category::ENTITY, 'about', [
            'type' => 'text',
            'label' => 'About',
            'sort_order' => 8,
            'group' => 'Cp Custom',
            'input' => 'textarea',
            'required' => 'false',
            'global' => ScopedAttributeInterface::SCOPE_STORE,
            'wysiwyg_enabled' => true,
            'is_html_allowed_on_front' => true
        ]);
        $eavSetup->addAttribute(Category::ENTITY, 'cabinet_terms', [
            'type' => 'text',
            'label' => 'CABINET TERMS',
            'sort_order' => 9,
            'group' => 'Cp Custom',
            'input' => 'textarea',
            'required' => 'false',
            'global' => ScopedAttributeInterface::SCOPE_STORE,
            'wysiwyg_enabled' => true,
            'is_html_allowed_on_front' => true
        ]);
        $eavSetup->addAttribute(Category::ENTITY, 'assembly', [
            'type' => 'text',
            'label' => 'ASSEMBLY',
            'sort_order' => 10,
            'group' => 'Cp Custom',
            'input' => 'textarea',
            'required' => 'false',
            'global' => ScopedAttributeInterface::SCOPE_STORE,
            'wysiwyg_enabled' => true,
            'is_html_allowed_on_front' => true
        ]);
        $eavSetup->addAttribute(Category::ENTITY, 'doorstyle_image', [
                'type' => 'varchar',
                'label' => 'Door Style Image',
                'input' => 'image',
                'sort_order' => 5,
                'source' => '',
                'global' => ScopedAttributeInterface::SCOPE_STORE,
                'visible' => true,
                'required' => false,
                'user_defined' => false,
                'default' => null,
                'group' => 'Cp Custom',
                'backend' => Image::class
        ]);
        $eavSetup->addAttribute(Category::ENTITY, 'sale_cat_image', [
            'type' => 'varchar',
            'label' => 'Sale Category Image',
            'input' => 'image',
            'sort_order' => 5,
            'source' => '',
            'global' => ScopedAttributeInterface::SCOPE_STORE,
            'visible' => true,
            'required' => false,
            'user_defined' => false,
            'default' => null,
            'group' => 'Cp Custom',
            'backend' => Image::class
        ]);
        $eavSetup->addAttribute(Category::ENTITY, 'is_sale_category', [
            'type' => 'int',
            'label' => 'Is Sale Category',
            'input' => 'select',
            'sort_order' => 333,
            'source' => Boolean::class,
            'global' => ScopedAttributeInterface::SCOPE_STORE,
            'visible' => true,
            'required' => false,
            'user_defined' => false,
            'default' => null,
            'group' => 'Cp Custom',
            'backend' => ''
        ]);
        $eavSetup->addAttribute(Category::ENTITY, 'show_mode', [
            'type' => 'varchar',
            'label' => 'Show Mode',
            'input' => 'select',
            'required' => false,
            'source' => Showmode::class,
            'sort_order' => 102,
            'visible' => true,
            'user_defined' => true,
            'default' => 'please_select',
            'global' => ScopedAttributeInterface::SCOPE_STORE,
            'group' => 'Display Settings',
        ]);
        $eavSetup->addAttribute(Category::ENTITY, 'color_id', [
            'type' => 'text',
            'label' => 'Color',
            'input' => 'select',
            'required' => 'false',
            'source' => Color::class,
            'default' => '',
            'sort_order' => 7,
            'global' => ScopedAttributeInterface::SCOPE_STORE,
            'group' => 'Cp Custom',
        ]);
        $eavSetup->addAttribute(Category::ENTITY, 'style_id', [
            'type' => 'text',
            'label' => 'Style',
            'input' => 'select',
            'required' => 'false',
            'source' => Style::class,
            'default' => '',
            'sort_order' => 7,
            'global' => ScopedAttributeInterface::SCOPE_STORE,
            'group' => 'Cp Custom',
        ]);
        $eavSetup->addAttribute(Category::ENTITY, 'style_code', [
            'type' => 'text',
            'label' => 'Style Code',
            'input' => 'text',
            'required' => 'false',
            'default' => '',
            'sort_order' => 8,
            'global' => ScopedAttributeInterface::SCOPE_STORE,
            'group' => 'Cp Custom',
        ]);
    }

    /**
     * @inheritdoc
     */
    public static function getDependencies()
    {
        /**
         * This is dependency to another patch. Dependency should be applied first
         * One patch can have few dependencies
         * Patches do not have versions, so if in old approach with Install/Ugrade data scripts you used
         * versions, right now you need to point from patch with higher version to patch with lower version
         * But please, note, that some of your patches can be independent and can be installed in any sequence
         * So use dependencies only if this important for you
         */
        return [];
    }

    /**
     * @inheritdoc
     */
    public function revert()
    {
        $this->moduleDataSetup->getConnection()->startSetup();
        //Here should go code that will revert all operations from `apply` method
        //Please note, that some operations, like removing data from column, that is in role of foreign key reference
        //is dangerous, because it can trigger ON DELETE statement
        $this->moduleDataSetup->getConnection()->endSetup();
    }

    /**
     * @inheritdoc
     */
    public function getAliases()
    {
        /**
         * This internal Magento method, that means that some patches with time can change their names,
         * but changing name should not affect installation process, that's why if we will change name of the patch
         * we will add alias here
         */
        return [];
    }
}
