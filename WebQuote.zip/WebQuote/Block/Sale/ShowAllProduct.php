<?php
/**
 * Commercepundit
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Commercepundit.com license that is
 * available through the world-wide-web at this URL:
 * http://commercepundit.com/license
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category   Commercepundit
 * @package    Commercepundit_WebQuote
 * @copyright  Copyright (c) Commercepundit (http://www.commercepundit.com/)
 * @license    http://www.commercepundit.com/LICENSE-1.0.html
 */

namespace Commercepundit\WebQuote\Block\Sale;

use Commercepundit\WebQuote\Model\CustomCabinetsCategory;
use Commercepundit\WebQuote\Helper\Data as WebQuoteHelper;
use Magento\Catalog\Model\ResourceModel\Category\StateDependentCollectionFactory;
use Magento\Customer\Model\Session as CustomerSession;
use Magento\Framework\App\Http\Context as AuthContext;
use Magento\Framework\Data\Collection;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\UrlInterface;
use Magento\Framework\View\Element\Template\Context;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Catalog\Model\CategoryFactory;
use Magento\Catalog\Block\Product\ImageBuilder;

/**
 * ShowAllProduct of category
 *
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class ShowAllProduct extends \Magento\Framework\View\Element\Template
{
    /**
     * PRODUCTS_PAGE_SIZE
     */
    public const PRODUCTS_PAGE_SIZE = 4;

    /**
     * @var StateDependentCollectionFactory
     */
    protected $collectionFactory;

    /**
     * @var StoreManagerInterface
     */
    protected $storeManager;

    /**
     * @var WebQuoteHelper
     */
    protected $_webQuoteHelper;

    /**
     * @var CategoryFactory
     */
    protected $_categoryFactory;

    /**
     * @var ImageBuilder
     */
    protected $imageBuilder;

    /**
     * @var CustomerSession
     */
    protected $customerSession;

    /**
     * @var AuthContext
     */
    protected $authContext;

    /**
     * @var CustomCabinetsCategory
     */
    protected $customCabinetsCategory;

    /**
     * @param Context $context
     * @param StateDependentCollectionFactory $collectionFactory
     * @param StoreManagerInterface $storeManager
     * @param WebQuoteHelper $webQuoteHelper
     * @param CategoryFactory $categoryFactory
     * @param ImageBuilder $imageBuilder
     * @param CustomerSession $customerSession
     * @param AuthContext $authContext
     * @param CustomCabinetsCategory $customCabinetsCategory
     * @param array $data
     * @SuppressWarnings(PHPMD.ExcessiveParameterList)
     */
    public function __construct(
        Context           $context,
        StateDependentCollectionFactory $collectionFactory,
        StoreManagerInterface           $storeManager,
        WebQuoteHelper                  $webQuoteHelper,
        CategoryFactory                 $categoryFactory,
        ImageBuilder                    $imageBuilder,
        CustomerSession                 $customerSession,
        AuthContext                     $authContext,
        CustomCabinetsCategory          $customCabinetsCategory,
        array             $data = []
    ) {
        $this->collectionFactory = $collectionFactory;
        $this->storeManager      = $storeManager;
        $this->_webQuoteHelper   = $webQuoteHelper;
        $this->_categoryFactory   = $categoryFactory;
        $this->imageBuilder       = $imageBuilder;
        $this->customerSession      = $customerSession;
        $this->authContext          = $authContext;
        $this->customCabinetsCategory   = $customCabinetsCategory;
        parent::__construct($context, $data);
    }

    /**
     * Get Media Url
     *
     * @return string
     */
    public function getMediaUrl()
    {
        return $this->storeManager->getStore()
            ->getBaseUrl(UrlInterface::URL_TYPE_MEDIA);
    }

    /**
     * @param $catId
     * @return Collection\AbstractDb
     */
    public function getCategoryById($catId)
    {
        return $this->_categoryFactory->create()->load($catId);
    }

    /**
     * Get Sale Category Data
     *
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     * @return array
     * @throws \Magento\Framework\Exception\LocalizedException
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Zend_Db_Select_Exception
     */
    public function getSaleCategoryDataById($catId,$page=1)
    {
        try {
            $categoryData = [];
            $finalData = [];
            $store = $this->storeManager->getStore();
            $storeId = $store->getStoreId();
            $mediaUrl = $this->getMediaUrl();
            $collection = $this->collectionFactory->create();
            $collection->setStoreId($storeId);
            $collection->addIsActiveFilter();
            $selectFields = [
                'name', 'image', 'shipping_time', 'color_id', 'style_id', 'cabinetline', 'woodspecies_id',
                'cabinet_subspecification', 'yotpo_product_id', 'ten_by_price_sku', 'sale_tag'
            ];
            $collection->addAttributeToSelect(
                $selectFields,
                'left'
            );
            $collection->addAttributeToFilter('include_in_menu', 1);
            $collection->addAttributeToFilter('is_sale_category', 1);
            $collection->addFieldToFilter('path', ['like' => '%' . $catId . '%']);
            $collection->addOrder('level', Collection::SORT_ORDER_ASC);
            $collection->getSelect()
                ->joinLeft(
                    ['cpl' => $collection->getTable('cp_cabinet_line')],
                    "IF(at_cabinetline.value_id > 0, at_cabinetline.value, at_cabinetline_default.value) = cpl.cabinet_line_id",
                    [
                        'cpl.cabinet_line_id',
                        'cpl.supplier',
                        'cpl.parent_cabinet_line_id',
                        'cabinet_shipping_time' => 'cpl.shipping_time'
                    ]
                )
                ->joinLeft(
                    ['cpc' => $collection->getTable('cp_color')],
                    "IF(at_color_id.value_id > 0, at_color_id.value, at_color_id_default.value)  = cpc.color_id",
                    [
                        'color_swatch_image' => new \Zend_Db_Expr("CONCAT('$mediaUrl',cpc.image)"),
                        'color_name' => 'cpc.name'
                    ]
                )->joinLeft(
                    ['cct' => $collection->getTable('cp_color_type')],
                    'cpc.type_id = cct.type_id',
                    ['color_type' => 'cct.name']
                )->joinLeft(
                    ['cpcc' => $collection->getTable('cp_color_category')],
                    'cpc.color_category_id = cpcc.color_category_id
                     AND cpcc.status = 1',
                    [
                        'color_category_name' => 'cpcc.name',
                        'cpcc.color_category_id'
                    ]
                )->joinLeft(
                    ['cps' => $collection->getTable('cp_style')],
                    "IF(at_style_id.value_id > 0, at_style_id.value, at_style_id_default.value) = cps.style_id",
                    ['style_shipping_time' => 'cps.shipping_time','cps.construction']
                )->joinLeft(
                    ['cpd' => $collection->getTable('cp_door')],
                    'cpd.door_id = cps.door_id',
                    [
                        'door_id' => 'cpd.door_id',
                        'door_name' => 'cpd.name'
                    ]
                )->joinLeft(
                    ['cwt' => $collection->getTable('cp_wood_type')],
                    "IF(at_woodspecies_id.value_id > 0, at_woodspecies_id.value, at_woodspecies_id_default.value) = cwt.type_id",
                    [
                        'cwt.type_id',
                        'wood_type_name' => 'cwt.type_name'
                    ]
                )->joinLeft(
                    ['ctbp' => $collection->getTable('cp_ten_by_ten_price')],
                    'e.entity_id = ctbp.entity_id',
                    [
                        'ten_by_special_price' => 'ctbp.discount_price'
                    ]
                );
            if ((int)$page > 0) {
                $page = (int)($page - 1);
            }
            $customerGroupId = 0;
            if ($this->isCustomerLogin() && !$customerGroupId) {
                $customerGroupId = $this->customerSession->getCustomerGroupId();
            }
            $collection->getSelect()->where('ctbp.all_groups = 1 OR ctbp.customer_group_id = ?', $customerGroupId);
            $collection->getSelect()->order('ctbp.discount_price ' . Collection::SORT_ORDER_ASC);
            $collection->getSelect()->order('cpc.sort_order ' . Collection::SORT_ORDER_ASC);
            $collection->getSelect()->order('e.position '.Collection::SORT_ORDER_ASC);
            $collection->getSelect()->group('e.entity_id');
            if ($collection->getSize()) {
                foreach ($collection as $_category) {
                    $_category->setShippingTime($this->customCabinetsCategory->getLeadTime($_category));
                    $categoryData[$_category->getParentId()]['category'][$_category->getColorType()][$_category->getId()] = $_category;
                }
            }
            $categoryData = array_chunk($categoryData,self::PRODUCTS_PAGE_SIZE,true);
            $finalData['products'] = [];
            $finalData['total_pages'] = count($categoryData);
            if (array_key_exists((int)$page,$categoryData)) {
                $finalData['products'] = $categoryData[(int)$page];
            }
            return $finalData;
        } catch (LocalizedException $ex) {
            throw new LocalizedException(__($ex->getMessage()));
        }
    }

    /**
     * Get category products.
     *
     * @param $catId
     * @param $page
     * @return mixed
     */
    public function getCategoryProducts($catId, $page=1){
        $category = $this->getCategoryById($catId);
        $categoryProducts = $category->getProductCollection()
            ->addAttributeToSelect('*')
            ->addAttributeToFilter('is_sale', true)
            ->setPageSize(self::PRODUCTS_PAGE_SIZE)
            ->setCurPage($page);
        return $categoryProducts;
    }

    /**
     * Get Currency Format.
     *
     * @return string
     */
    public function getCurrencyFormat(): string
    {
        $store = $this->storeManager->getStore();
        return $store->getCurrentCurrency()->getOutputFormat() ?? '';
    }

    /**
     * @param $product
     * @param $imageId
     * @param $attributes
     * @return \Magento\Catalog\Block\Product\Image
     */
    public function getImage($product, $imageId, $attributes = [])
    {
        return $this->imageBuilder->create($product, $imageId, $attributes);
    }

    /**
     * Get customer login status.
     *
     * @return bool
     */
    public function isCustomerLogin(): bool
    {
        return (bool)$this->authContext->getValue(\Magento\Customer\Model\Context::CONTEXT_AUTH);
    }
}
