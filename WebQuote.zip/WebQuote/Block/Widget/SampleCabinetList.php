<?php
/*
 * Commercepundit
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Commercepundit.com license that is
 * available through the world-wide-web at this URL:
 * http://commercepundit.com/license
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category   Commercepundit
 * @package    Commercepundit_WebQuote
 * @copyright  Copyright (c) Commercepundit (http://www.commercepundit.com/)
 * @license    http://www.commercepundit.com/LICENSE-1.0.html
 *
 *
 */

namespace Commercepundit\WebQuote\Block\Widget;

use Commercepundit\WebQuote\Block\Category\ListCabinets;
use Commercepundit\Checkout\Helper\Data as CheckoutHelper;
use Magento\Catalog\Model\Category;
use Magento\Catalog\Helper\Category as CategoryHelper;
use Magento\Framework\App\ResourceConnection;
use Magento\Framework\Data\Collection;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\UrlInterface;
use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;
use Magento\Widget\Block\BlockInterface;
use Commercepundit\Cabinets\Helper\Data as CabinetHelper;
use Magento\Framework\App\Http\Context as AuthContext;
use Commercepundit\Cabinets\Model\Style\Source\Construction;
use Commercepundit\General\Model\Config\Source\Boolean;
use Magento\Catalog\Model\Product\Attribute\Source\Status;
use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory as ProductCollectionFactory;
use Commercepundit\Ordersample\Model\GetSampleCabinetCategory;
use Commercepundit\Cabinets\Model\Color\Source\Status as ColorStatus;
use Magento\Catalog\Helper\Image as ProductImageHelper;

/**
 * class CabinetList
 *
 * Cabinet Lamding Widget Class.
 *
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 * @SuppressWarnings(PHPMD.ExcessiveClassComplexity)
 */
class SampleCabinetList extends Template implements BlockInterface
{
    /**
     * @const CATEGORY_OPTIONS_NUMBER_SHOW
     */
    public const CATEGORY_OPTIONS_NUMBER_SHOW = 6;

    /**
     * @const PAGE_SIZE
     */
    public const PAGE_SIZE = 12;

    /**
     * @var string
     */
    private $connection = '';

    /**
     * @var array
     */
    private $filter = [];

    /**
     * @var string
     */
    protected $_template = "Commercepundit_WebQuote::widget/samplecabinetLanding.phtml";

    /**
     * @var CategoryHelper
     */
    protected $categoryHelper;

    /**
     * @var ResourceConnection
     */
    protected $resourceConnection;

    /**
     * @var AuthContext
     */
    protected $authContext;

    /**
     * @var Construction
     */
    protected $constructionOptions;


    /**
     * @param Context $context
     * @param CategoryHelper $categoryHelper
     * @param ResourceConnection $resourceConnection
     * @param GeneralHelper $generalHelper
     * @param AuthContext $authContext
     * @param array $data
     */
    public function __construct(
        Template\Context   $context,
        CategoryHelper     $categoryHelper,
        ResourceConnection $resourceConnection,
        AuthContext        $authContext,
        Construction       $constructionOptions,
        Category           $category,
        ProductCollectionFactory $productCollectionFactory,
        ProductImageHelper       $productImageHelper,
        array              $data = []
    ) {
        parent::__construct($context, $data);
        $this->categoryHelper = $categoryHelper;
        $this->resourceConnection = $resourceConnection;
        $this->authContext   = $authContext;
        $this->constructionOptions = $constructionOptions;
        $this->category = $category;
        $this->productCollectionFactory = $productCollectionFactory;
        $this->productImageHelper = $productImageHelper;
    }


    /**
     * Get Collection.
     *
     * @return string
     *
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @SuppressWarnings(PHPMD.NPathComplexity)
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    public function getCategoryIds()
    {
        return $this->getData("categories_id")??$this->getData("categories_id");
    }

    /**
     * Get Collection.
     *
     * @return string
     *
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @SuppressWarnings(PHPMD.NPathComplexity)
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    public function getDoorIds()
    {
        return $this->getData("door_id")??$this->getData("door_id");
    }

    /**
     * Get Collection.
     *
     * @return string
     *
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @SuppressWarnings(PHPMD.NPathComplexity)
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    public function getCabinetLineIds()
    {
        return $this->getData("cabinet_line_id")??$this->getData("cabinet_line_id");
    }

    /**
     * Get Collection.
     *
     * @return string
     *
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @SuppressWarnings(PHPMD.NPathComplexity)
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    public function getTypeIds()
    {
        return $this->getData("type_id")??$this->getData("type_id");
    }

    /**
     * Get Collection.
     *
     * @return string
     *
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @SuppressWarnings(PHPMD.NPathComplexity)
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    public function getColorCategoryIds()
    {
        return $this->getData("color_category_id")??$this->getData("color_category_id");
    }

    /**
     * Get Collection.
     *
     * @return array
     *
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @SuppressWarnings(PHPMD.NPathComplexity)
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    public function getCategoryData(): array
    {
        $productData = [];
        try {

            if ($this->getData("categories_id") && $categoriesId = trim($this->getData("categories_id"))) {
                $categoriesId = explode(",", $categoriesId);
                $productData = $this->getSamplecategory($categoriesId, $this->getFilteredData());
            }
            
        } catch (NoSuchEntityException|\Exception $e) {
            $this->_logger->critical($e);
        }

        return $productData;
    }

    /**
     * Get connection.
     *
     * @return \Magento\Framework\DB\Adapter\AdapterInterface|string
     */
    protected function getConnection()
    {
        if (empty($this->connection)) {
            $this->connection = $this->resourceConnection->getConnection();
        }
        return $this->connection;
    }

    /**
     * Get Filter Request Url.
     *
     * @return string
     */
    public function getFilterRequestUrl(): string
    {
        return $this->getUrl("webquote/widget/samplecabinetfilterrequest");
    }

    /**
     * Get Widget Title.
     *
     * @return array|mixed|null
     */
    public function getTitle(): mixed
    {
        return $this->getData("title");
    }

    /**
     * Check Has filter or not.
     *
     * @return bool
     */
    public function hasFilter(): bool
    {
        return !empty($this->filter) && count($this->filter);
    }

    
    /**
     * Get Sample Cabinets Data
     *
     * @param int $categoryId
     * @param mixed $filterRequest
     * @return array
     * @throws \Magento\Framework\Exception\LocalizedException
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Zend_Db_Select_Exception
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @SuppressWarnings(PHPMD.NPathComplexity)
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    public function getSamplecategory($categoryIds, $filterRequest = [])
    {
        try
        {
            $categoryData = [];
            $allChildCategories = [];
            $childCategories = "";
            foreach ($categoryIds as $categoryId) {
                $categories = $this->category->load($categoryId);
                $childCategories.= "," . $categories->getAllChildren(false);
            }
            $childCategories = substr($childCategories,1);
            $allChildCategories = explode(",", $childCategories);
            
            if (!empty($allChildCategories)) {
                $mediaUrl = $this->_storeManager->getStore()->getBaseUrl(
                    UrlInterface::URL_TYPE_MEDIA
                );
                $productselectFields = [
                    'color_id',
                    'image',
                    'image_title',
                    'style_id',
                    'cabinet_line_id',
                    'woodspecies',
                    'sell_tag_name',
                    'is_sample',
                    'name'
                ];
                foreach ($allChildCategories as $categoryId) {
                    $category = $this->category->load($categoryId);
                    $_productCollection = $this->productCollectionFactory->create();
                    $_productCollection->addAttributeToSelect($productselectFields, 'left')
                        ->addCategoriesFilter(['in' => $category->getId()])
                        ->addAttributeToFilter([
                            ["attribute" =>'is_sample','eq' => 1]
                        ])
                        ->addAttributeToFilter('status', Status::STATUS_ENABLED);
                    $connection = $_productCollection->getConnection();
                    $_productCollection->getSelect()
                    ->joinLeft(
                        ['cpc' => $connection->getTableName('cp_color')],
                        "IF(at_color_id.value_id > 0, at_color_id.value, at_color_id_default.value)  = cpc.color_id",
                        [
                            'color_name' => 'cpc.name',
                            'color_image' => 'cpc.image'
                        ]
                    )->joinLeft(
                        ['cct' => $connection->getTableName('cp_color_type')],
                        'cpc.type_id = cct.type_id',
                        ['color_type' => 'cct.name']
                    )->joinLeft(
                        ['cpcc' => $connection->getTableName('cp_color_category')],
                        'cpc.color_category_id = cpcc.color_category_id
                         AND cpcc.status = ' . ColorStatus::STATUS_ENABLE,
                        [
                            'color_category_name' => 'cpcc.name',
                            'cpcc.color_category_id'
                        ]
                    )->joinLeft(
                        ['cpl' => $connection->getTableName('cp_cabinet_line')],
                        "IF(at_cabinet_line_id.value_id > 0, at_cabinet_line_id.value, at_cabinet_line_id_default.value) = cpl.cabinet_line_id",
                        [
                            'cabinet_line_id',
                            'cabinet_name' => 'cpl.cabinet_name',
                            'parent_cabinet_line_id',
                            'supplierCabinetName'=> 'cpl.supplier'
                        ]
                    )->joinLeft(
                        ['cps' => $connection->getTableName('cp_style')],
                        "IF(at_style_id.value_id > 0, at_style_id.value, at_style_id_default.value)  = cps.style_id",
                        [
                            'construction',
                            'style_name' => 'cps.name'
                        ]
                    )->joinLeft(
                        ['cpd' => $connection->getTableName('cp_door')],
                        'cpd.door_id = cps.door_id',
                        [
                            'door_id' => 'cpd.door_id',
                            'door_name' => 'cpd.name'
                        ]
                    )->joinLeft(
                        ['cwt' => $connection->getTableName('cp_wood_type')],
                        "IF(at_woodspecies.value_id > 0, at_woodspecies.value, at_woodspecies_default.value) = cwt.type_id",
                        ['wood_type_id' => 'cwt.type_id', 'wood_type_name' => 'cwt.type_name']
                    );
                    $isFilterRequest = (bool)$this->getData('is_filter_request');
                    $categoryData['filters']['selected_filters'] = [];
                    
                    if ($this->getData('door_id') && $doorStyle = trim($this->getData('door_id'))) {
                        $doorStyle = explode(",", $doorStyle);
                        $_productCollection->getSelect()->where('cpd.door_id IN (?)', $doorStyle);
                    }
                    if ($this->getData('cabinet_line_id') && $cabinet = trim($this->getData('cabinet_line_id'))) {
                        $cabinet = explode(",", $cabinet);
                        $_productCollection->getSelect()->where('cpl.cabinet_line_id IN (?)', $cabinet);
                    }
                    if ($this->getData('color_category_id') &&
                        $colorCategory = trim($this->getData('color_category_id'))) {
                        $colorCategory = explode(",", $colorCategory);
                        $_productCollection->getSelect()->where('cpcc.color_category_id IN (?)', $colorCategory);
                    }
                    if ($this->getData('type_id') && $typeId = trim($this->getData('type_id'))) {
                        $typeId = explode(",", $typeId);
                        $_productCollection->getSelect()->where('cwt.type_id IN (?)', $typeId);
                    }
                    if (isset($filterRequest['filterRequest'])
                        && !empty($filterRequest)) {
                        $this->getAllFilterOptions();
                    
                        $filterRequestOrig = $filterRequest['filterRequestOrig']?? [];
                        foreach ($filterRequest['filterRequest'] as $column => $filterValue) {
                            if (array_key_exists($column, GetSampleCabinetCategory::FILTER_PARAM)) {
                                $_productCollection->getSelect()->where(
                                    sprintf("%s%s IN (?)", GetSampleCabinetCategory::FILTER_PARAM[$column], $column),
                                    $filterValue
                                );
                            }
                            if (!isset($categoryData['filters']['selected_filters'][$column])) {
                                $categoryData['filters']['selected_filters'][$column] = [];
                                $categoryData['filters']['selected_filters'][$column]['label'] = '';
                                if ($column == GetSampleCabinetCategory::FILTER_STYLE) {
                                    $categoryData['filters']['selected_filters'][$column]['label'] = GetSampleCabinetCategory::FILTER_STYLE_LABEL;
                                } elseif ($column == GetSampleCabinetCategory::FILTER_CABINET_LINE) {
                                    $categoryData['filters']['selected_filters'][$column]['label'] = GetSampleCabinetCategory::FILTER_CABINET_LINE_LABEL;
                                } elseif ($column == GetSampleCabinetCategory::FILTER_FINISH) {
                                    $categoryData['filters']['selected_filters'][$column]['label'] = GetSampleCabinetCategory::FILTER_FINISH_LABEL;
                                } elseif ($column == GetSampleCabinetCategory::FILTER_WOOD_SPECIES) {
                                    $categoryData['filters']['selected_filters'][$column]['label'] = GetSampleCabinetCategory::FILTER_WOOD_SPECIES_LABEL;
                                } elseif ($column == GetSampleCabinetCategory::FILTER_CONSTRUCTION) {
                                    $categoryData['filters']['selected_filters'][$column]['label'] = GetSampleCabinetCategory::FILTER_CONSTRUCTION_LABEL;
                                }
                                $categoryData['filters']['selected_filters'][$column]['values'] = [];
                            }
                            if ($column == GetSampleCabinetCategory::FILTER_CABINET_LINE && isset($filterRequestOrig[$column]) && !empty($filterRequestOrig[$column])) {
                                $filterValue = $filterRequestOrig[$column];
                            }
                            $this->getSelectedFilters($categoryData,$column,$filterValue);
                        }
                    }

                    $_productCollection->getSelect()->order('cpc.sort_order '.Collection::SORT_ORDER_ASC);
                    $_productCollection->getSelect()->group('e.entity_id');
                    $_productCollection->setFlag('has_stock_status_filter', false);
                    if ($_productCollection->getSize()) {

                        $isFirst = true;
                        $categoryData[$category->getId()] = [
                            'style_data' => true,
                            'cat_id' => $category->getId(),
                            'name' => $category->getName(),
                            'shipping_time' => $category->getData('shipping_time'),
                            'cabinet_subspecification' => $category->getData('cabinet_subspecification') ?? '',
                            'sell_tag_name' => null,
                            'cat_url' => $category->getUrl(),
                            'heading_title' => $category->getHeadingTitle()
                        ];
                        $this->allFilterOptions[GetSampleCabinetCategory::FILTER_CONSTRUCTION] = $this->constructionOptions->getOptionsValues();
                        foreach ($_productCollection as $product) {
                            $_key = $product->getColorType() ?? '';
                        
                            $productImage = $this->productImageHelper
                           ->init($product, 'sample_category_list')
                           ->constrainOnly(TRUE)
                           ->keepAspectRatio(TRUE)
                           ->keepTransparency(TRUE)
                           ->keepFrame(FALSE)
                           ->resize('210','310');
                            if ($isFirst && !isset($categoryData[$category->getId()]['is_first'])) {
                                $categoryData[$category->getId()]['is_first'] = $isFirst;
                                $categoryData[$category->getId()]['product_url'] = $product->getProductUrl();
                                $categoryData[$category->getId()]['product_image'] = $productImage->getUrl() ?? null;
                                $categoryData[$category->getId()]['sell_tag_name'] = $product->getSellTagName() ?? null;
                            }
                            $colorData = [
                                'parent_cat_id' => $category->getId(),
                                'color_type' => $product->getColorType() ?? '',
                                'product_id' => $product->getId(),
                                'color_id' => $product->getColorId() ?? '',
                                'name' => $product->getColorName() ?? '',
                                'image' => $mediaUrl . $product->getColorImage() ?? '',
                                'title' => $product->getImageTitle() ?? $product->getColorName(),
                                'is_first' => $isFirst,
                                'product_url' => $product->getProductUrl(),
                                'product_image' => $productImage->getUrl() ?? null,
                                'style_id' => $product->getStyleId() ?? null,
                                'cabinet_line_id' => $product->getCabinetLineId() ?? null,
                                'woodspecies_id' => $product->getWoodspecies() ?? null,
                                'construction' => $product->getConstruction() ?? null,
                                'style_name' => $product->getStyleName() ?? null,
                                'wood_type_name' => $product->getWoodTypeName() ?? null,
                                'color_name' => $product->getColorName() ?? null,
                                'cabinetline' => $product->getCabinetName() ?? null,
                                'sell_tag_name' => $product->getSellTagName() ?? null,
                                'heading_title' => $product->getName()
                            ];
                            $categoryData[$category->getId()]['color_data'][$_key][] = $colorData;
                            if (isset($categoryData[$category->getId()]['color_data'])) {
                                $isFirst = false;
                            }
                            $this->getCabinetsStyleFilterOptions($product, $this->filterOptions);
                        }

                    }
                }
            }
            $this->getCabinetLineFilterOptions($this->filterOptions);
            $categoryData['is_filter_request'] = $isFilterRequest;
            $categoryData['filters']['filter_options'] = $this->filterOptions;
            return $categoryData;
        }catch (LocalizedException $ex) {
            throw new LocalizedException(__($ex->getMessage()));
        }
    }

    /**
     * Get Selected Filters
     *
     * @param  array &$categoryData
     * @param  string $column
     * @param  string $filterValue
     */
    public function getSelectedFilters(&$categoryData,$column,$filterValue) {
        if (is_array($filterValue)) {
            foreach ($filterValue as $values) {
                if (is_array($values)) {
                    $this->getSelectedFilters($categoryData,$column,$values);
                } else {
                    $this->getSelectedFilterValues($categoryData,$column,$values);
                }
            }
        } else {
            $this->getSelectedFilterValues($categoryData,$column,$filterValue);
        }
    }

    /**
     * Get All Filter Options
     */
    public function getAllFilterOptions() {
        $connection = $this->getConnection();
        if (!isset($this->allFilterOptions[GetSampleCabinetCategory::FILTER_STYLE])) {
            $select = $connection->select()
                ->from($connection->getTableName('cp_door'),['door_id','name']);
            $this->allFilterOptions[GetSampleCabinetCategory::FILTER_STYLE] = $connection->fetchPairs($select);
        }
        if (!isset($this->allFilterOptions[GetSampleCabinetCategory::FILTER_CABINET_LINE])) {
            $select = $connection->select()
                ->from($connection->getTableName('cp_cabinet_line'),['cabinet_line_id','supplier']);
            $this->allFilterOptions[GetSampleCabinetCategory::FILTER_CABINET_LINE] = $connection->fetchPairs($select);
        }
        if (!isset($this->allFilterOptions[GetSampleCabinetCategory::FILTER_WOOD_SPECIES])) {
            $select = $connection->select()
                ->from($connection->getTableName('cp_wood_type'),['type_id','type_name']);
            $this->allFilterOptions[GetSampleCabinetCategory::FILTER_WOOD_SPECIES] = $connection->fetchPairs($select);
        }
        if (!isset($this->allFilterOptions[GetSampleCabinetCategory::FILTER_FINISH])) {
            $select = $connection->select()
                ->from($connection->getTableName('cp_color_category'),['color_category_id','name']);
            $this->allFilterOptions[GetSampleCabinetCategory::FILTER_FINISH] = $connection->fetchPairs($select);
        }
        if (!isset($this->allFilterOptions[GetSampleCabinetCategory::FILTER_CONSTRUCTION])) {
            $this->allFilterOptions[GetSampleCabinetCategory::FILTER_CONSTRUCTION] = $this->constructionOptions->getOptionsValues();
        }
    }

    /**
     * Get Style Filter Options
     *
     * @param  [] $styleColorData
     * @param  [] $options
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @SuppressWarnings(PHPMD.NPathComplexity)
     * @return array
     */
    public function getCabinetsStyleFilterOptions($styleColorData, &$options)
    {
        if (isset($styleColorData[GetSampleCabinetCategory::FILTER_STYLE])
            && !empty($styleColorData[GetSampleCabinetCategory::FILTER_STYLE])) {
            $doorId = $styleColorData[GetSampleCabinetCategory::FILTER_STYLE];
            $options['door']['name'] = GetSampleCabinetCategory::FILTER_STYLE;
            $options['door']['label'] = GetSampleCabinetCategory::FILTER_STYLE_LABEL;
            $options['door']['values'][$doorId] = [
                'id' => $doorId,
                'name' => $styleColorData['door_name']
            ];
        }
        if (isset($styleColorData[GetSampleCabinetCategory::FILTER_CABINET_LINE])
            && !empty($styleColorData[GetSampleCabinetCategory::FILTER_CABINET_LINE])) {
            $options['cabinetline']['name'] = GetSampleCabinetCategory::FILTER_CABINET_LINE;
            $options['cabinetline']['label'] = GetSampleCabinetCategory::FILTER_CABINET_LINE_LABEL;
            $parentCabLineId = $styleColorData['parent_cabinet_line_id'];
            $styleCabId = $styleColorData['cabinet_line_id'];
            if ($parentCabLineId) {
                if ((!isset($options['cabinetline']['values'][$parentCabLineId]['options']) ||
                    !(
                        isset($options['cabinetline']['values'][$parentCabLineId]['options'])
                      && in_array($styleCabId, $options['cabinetline']['values'][$parentCabLineId]['options'])
                    ))
                ) {
                    $options['cabinetline']['values'][$parentCabLineId]['options'][] = $styleCabId;
                    $options['cabinetline']['values'][$parentCabLineId]['name'] = $styleColorData['supplierCabinetName'];
                }
            } else {
                if (!isset($options['cabinetline']['values'][$styleCabId]['options'])) {
                    $options['cabinetline']['values'][$styleCabId]['options'][] = $styleCabId;
                    $options['cabinetline']['values'][$styleCabId]['name'] = $styleColorData['supplierCabinetName'];
                }
            }
        }
        if (isset($styleColorData[GetSampleCabinetCategory::FILTER_FINISH])
            && !empty($styleColorData[GetSampleCabinetCategory::FILTER_FINISH])) {
            $colorCategoryId = $styleColorData[GetSampleCabinetCategory::FILTER_FINISH];
            $options['finish']['name'] = GetSampleCabinetCategory::FILTER_FINISH;
            $options['finish']['label'] = GetSampleCabinetCategory::FILTER_FINISH_LABEL;
            $options['finish']['values'][$colorCategoryId] = [
                'id' => $colorCategoryId,
                'name' => $styleColorData['color_category_name']
            ];
        }
        if (isset($styleColorData['wood_type_id'])
            && !empty($styleColorData['wood_type_id'])) {
            $woodtypeId = $styleColorData['wood_type_id'];
            $options['woodtype']['name'] = GetSampleCabinetCategory::FILTER_WOOD_SPECIES;
            $options['woodtype']['label'] = GetSampleCabinetCategory::FILTER_WOOD_SPECIES_LABEL;
            $options['woodtype']['values'][$woodtypeId] = [
                'id' => $woodtypeId,
                'name' => $styleColorData['wood_type_name']
            ];
        }
        if (isset($styleColorData[GetSampleCabinetCategory::FILTER_CONSTRUCTION])
            && !empty($styleColorData[GetSampleCabinetCategory::FILTER_CONSTRUCTION])) {
            $construction = $styleColorData[GetSampleCabinetCategory::FILTER_CONSTRUCTION];
            $constructionLabel = $construction;
            if (isset($this->allFilterOptions[GetSampleCabinetCategory::FILTER_CONSTRUCTION][$construction])) {
                $constructionLabel = $this->allFilterOptions[GetSampleCabinetCategory::FILTER_CONSTRUCTION][$construction];
            }
            $options[GetSampleCabinetCategory::FILTER_CONSTRUCTION]['name'] = GetSampleCabinetCategory::FILTER_CONSTRUCTION;
            $options[GetSampleCabinetCategory::FILTER_CONSTRUCTION]['label'] = GetSampleCabinetCategory::FILTER_CONSTRUCTION_LABEL;
            $options[GetSampleCabinetCategory::FILTER_CONSTRUCTION]['values'][$construction] = [
                'id' => $construction,
                'name' => $constructionLabel
            ];
        }
    }

    /**
     * Get Style Filter Options
     *
     * @param  [] $styleFilterOptions
     * @return array
     */
    public function getCabinetLineFilterOptions(&$styleFilterOptions)
    {
        if (isset($styleFilterOptions['cabinetline']['values'])) {
            foreach ($styleFilterOptions['cabinetline']['values'] as $parentId => &$style) {
                $options = $style['options'];
                $options[] = $parentId;
                $name = $style['name'];
                $style = [
                    'id' => implode(",", array_unique($options)),
                    'name' => $name
                ];
            }
        }
    }

    /**
     * Get Selected Filter Values
     *
     * @param  array &$categoryData
     * @param  string $column
     * @param  string $filterValue
     */
    public function getSelectedFilterValues(&$categoryData,$column,$filterValue) {
        $val = $filterValue;
        if ($column == GetSampleCabinetCategory::FILTER_CABINET_LINE) {
            $values = explode(",", $filterValue);
            if (!empty($values)) {
                $firstValue = reset($values);
                if (isset($this->allFilterOptions[$column][$firstValue])) {
                    $val = $this->allFilterOptions[$column][$firstValue];
                }
            }
        } else {
            if (isset($this->allFilterOptions[$column][$filterValue])) {
                $val = $this->allFilterOptions[$column][$filterValue];
            }
        }
        $categoryData['filters']['selected_filters'][$column]['values'][$filterValue] = $val;
    }
}
