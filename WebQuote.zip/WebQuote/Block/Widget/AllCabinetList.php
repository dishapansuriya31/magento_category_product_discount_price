<?php
/*
 * Commercepundit
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Commercepundit.com license that is
 * available through the world-wide-web at this URL:
 * http://commercepundit.com/license
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category   Commercepundit
 * @package    Commercepundit_WebQuote
 * @copyright  Copyright (c) Commercepundit (http://www.commercepundit.com/)
 * @license    http://www.commercepundit.com/LICENSE-1.0.html
 *
 *
 */

namespace Commercepundit\WebQuote\Block\Widget;

use Commercepundit\WebQuote\Block\Category\ListCabinets;
use Commercepundit\Checkout\Helper\Data as CheckoutHelper;
use Magento\Catalog\Model\Category;
use Magento\Catalog\Helper\Category as CategoryHelper;
use Magento\Framework\App\ResourceConnection;
use Magento\Framework\Data\Collection;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\UrlInterface;
use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;
use Magento\Widget\Block\BlockInterface;
use Commercepundit\General\Helper\Data as GeneralHelper;
use Commercepundit\Cabinets\Helper\Data as CabinetHelper;
use Magento\Customer\Model\Session as CustomerSession;
use Magento\Framework\App\Http\Context as AuthContext;
use Commercepundit\Cabinets\Model\Style\Source\Construction;
/**
 * class CabinetList
 *
 * Cabinet Lamding Widget Class.
 *
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 * @SuppressWarnings(PHPMD.ExcessiveClassComplexity)
 */
class AllCabinetList extends Template implements BlockInterface
{
    /**
     * @const CATEGORY_OPTIONS_NUMBER_SHOW
     */
    public const CATEGORY_OPTIONS_NUMBER_SHOW = 6;

    /**
     * @const PAGE_SIZE
     */
    public const PAGE_SIZE = 12;

    /**
     * @var string[]
     */
    private $filter_options = [
        'door_id' => 'Style',
        'cabinet_line_id' => 'Line',
        'type_id' => 'Wood Species',
        'color_category_id' => 'Finish',
        'construction' => 'Construction'
    ];

    /**
     * @var string[]
     */
    private $filter_name = [
        'door_id' => 'door_name',
        'cabinet_line_id' => 'supplier',
        'type_id' => 'wood_type_name',
        'color_category_id' => 'color_category_name',
        'construction' => 'construction'
    ];

    /**
     * @var string
     */
    private $connection = '';

    /**
     * @var array
     */
    private $filter = [];

    /**
     * @var string
     */
    protected $_template = "Commercepundit_WebQuote::widget/allcabinetLanding.phtml";

    /**
     * @var CategoryHelper
     */
    protected $categoryHelper;

    /**
     * @var ResourceConnection
     */
    protected $resourceConnection;

    /**
     * @var GeneralHelper
     */
    protected $generalHelper;

    /**
     * @var CustomerSession
     */
    protected $customerSession;

    /**
     * @var AuthContext
     */
    protected $authContext;

    /**
     * @var Construction
     */
    protected $constructionOptions;


    /**
     * @param Context $context
     * @param CategoryHelper $categoryHelper
     * @param ResourceConnection $resourceConnection
     * @param GeneralHelper $generalHelper
     * @param CustomerSession $customerSession
     * @param AuthContext $authContext
     * @param array $data
     */
    public function __construct(
        Template\Context   $context,
        CategoryHelper     $categoryHelper,
        ResourceConnection $resourceConnection,
        GeneralHelper      $generalHelper,
        CustomerSession    $customerSession,
        AuthContext        $authContext,
        Construction       $constructionOptions,
        array              $data = []
    ) {
        parent::__construct($context, $data);
        $this->categoryHelper = $categoryHelper;
        $this->resourceConnection = $resourceConnection;
        $this->customerSession = $customerSession;
        $this->generalHelper = $generalHelper;
        $this->authContext   = $authContext;
        $this->constructionOptions = $constructionOptions;
    }

    /**
     * Get Collection.
     *
     * @return array
     *
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @SuppressWarnings(PHPMD.NPathComplexity)
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    public function getCategoryCollection(): array
    {
        try {
            $finalData = [];
            $categoryData = [];
            $customData = [];
            $signatureData = [];
            $rtaData = [];
            $store = $this->_storeManager->getStore();
            $collection =  $this->categoryHelper->getStoreCategories(false, true, false);
            $collection->addIsActiveFilter();
            $collection->addAttributeToSelect(
                [
                    'name', 'image', 'shipping_time', 'color_id', 'style_id', 'cabinetline', 'woodspecies_id',
                    'cabinet_subspecification', 'yotpo_product_id', 'ten_by_price_sku', 'sale_tag','heading_title','is_new','is_new_end_date'
                ],
                'left'
            );
            $collection->addAttributeToFilter('include_in_menu', 1);
            $collection->addAttributeToFilter('level', ['in' => [ListCabinets::CATEGORY_LEVEL_5]]);
            $collection->addOrder('level', Collection::SORT_ORDER_ASC);

            $mediaUrl = $store->getBaseUrl(UrlInterface::URL_TYPE_MEDIA);
            $collection->getSelect()
                ->joinLeft(
                    ['cpl' => $collection->getTable('cp_cabinet_line')],
                    "IF(at_cabinetline.value_id > 0, at_cabinetline.value, at_cabinetline_default.value) = cpl.cabinet_line_id",
                    [
                        'cpl.cabinet_line_id',
                        'cpl.supplier',
                        'cpl.parent_cabinet_line_id',
                        'cabinet_shipping_time' => 'cpl.shipping_time'
                    ]
                )
                ->joinLeft(
                    ['cpc' => $collection->getTable('cp_color')],
                    "IF(at_color_id.value_id > 0, at_color_id.value, at_color_id_default.value)  = cpc.color_id",
                    [
                        'color_swatch_image' => new \Zend_Db_Expr("CONCAT('$mediaUrl',cpc.image)")
                    ]
                )->joinLeft(
                    ['cct' => $collection->getTable('cp_color_type')],
                    'cpc.type_id = cct.type_id',
                    ['color_type' => 'cct.name']
                )->joinLeft(
                    ['cpcc' => $collection->getTable('cp_color_category')],
                    'cpc.color_category_id = cpcc.color_category_id
                     AND cpcc.status = 1',
                    [
                        'color_category_name' => 'cpcc.name',
                        'cpcc.color_category_id'
                    ]
                )->joinLeft(
                    ['cps' => $collection->getTable('cp_style')],
                    "IF(at_style_id.value_id > 0, at_style_id.value, at_style_id_default.value) = cps.style_id",
                    ['style_shipping_time' => 'cps.shipping_time','cps.construction']
                )->joinLeft(
                    ['cpd' => $collection->getTable('cp_door')],
                    'cpd.door_id = cps.door_id',
                    [
                        'door_id' => 'cpd.door_id',
                        'door_name' => 'cpd.name'
                    ]
                )->joinLeft(
                    ['cwt' => $collection->getTable('cp_wood_type')],
                    "IF(at_woodspecies_id.value_id > 0, at_woodspecies_id.value, at_woodspecies_id_default.value) = cwt.type_id",
                    [
                        'cwt.type_id',
                        'wood_type_name' => 'cwt.type_name'
                    ]
                )->joinLeft(
                    ['ctbp' => $collection->getTable('cp_ten_by_ten_price')],
                    'e.entity_id = ctbp.entity_id',
                    [
                        'ten_by_regular_price' => 'ctbp.regular_price',
                        'ten_by_discount_price' => 'ctbp.discount_price',
                        'as_low_as_price' => 'ctbp.as_low_as_price',
                    ]
                );
            $isFilterRequest = (bool)$this->getData('is_filter_request');
            $filterReq = $this->getData("filter_request") ?? [];
            $page = $this->getData("page") ?? 0;
            if ((int)$page > 0) {
                $page = (int)($page - 1);
            }
            $customerGroupId = 0;
            if ($this->isCustomerLogin() && !$customerGroupId) {
                $customerGroupId = $this->customerSession->getCustomerGroupId();
            }
            $collection->getSelect()->where('ctbp.all_groups = 1 OR ctbp.customer_group_id = ?', $customerGroupId);
            if ($this->getData('door_id') && $doorStyle = trim($this->getData('door_id'))) {
                $doorStyle = explode(",", $doorStyle);
                $collection->getSelect()->where('cpd.door_id IN (?)', $doorStyle);
                if ($isFilterRequest && !empty($filterReq) && isset($filterReq["door_id"]) &&
                    !empty($filterReq["door_id"])) {
                    $this->prepareStyleSelectedFilter($doorStyle);
                }
            }
            if ($this->getData('cabinet_line_id') && $cabinet = trim($this->getData('cabinet_line_id'))) {
                $cabinet = explode(",", $cabinet);
                $collection->getSelect()->where('cpl.cabinet_line_id IN (?)', $cabinet);
                if ($isFilterRequest && !empty($filterReq) && isset($filterReq["cabinet_line_id"]) &&
                    !empty($filterReq["cabinet_line_id"])) {
                    $this->prepareCabinetSelectedFilter($cabinet);
                }
            }
            if ($this->getData('color_category_id') &&
                $colorCategory = trim($this->getData('color_category_id'))) {
                $colorCategory = explode(",", $colorCategory);
                $collection->getSelect()->where('cpcc.color_category_id IN (?)', $colorCategory);
                if ($isFilterRequest && !empty($filterReq) && isset($filterReq["color_category_id"]) &&
                    !empty($filterReq["color_category_id"])) {
                    $this->prepareFinishSelectedFilter($colorCategory);
                }
            }
            if ($this->getData('type_id') && $typeId = trim($this->getData('type_id'))) {
                $typeId = explode(",", $typeId);
                $collection->getSelect()->where('cwt.type_id IN (?)', $typeId);
                if ($isFilterRequest && !empty($filterReq) && isset($filterReq["type_id"]) &&
                    !empty($filterReq["type_id"])) {
                    $this->prepareWoodTypeSelectedFilter($typeId);
                }
            }
            if ($this->getData("categories_id") && $categoriesId = trim($this->getData("categories_id"))) {
                $categoriesId = explode(",", $categoriesId);
                $field_name = "e.path";
                $where = [];
                foreach ($categoriesId as $catId){
                    $where[] = "{$field_name} LIKE '%{$catId}%'";
                }
                $where = '(' . implode(' OR ', $where) . ')';
                $collection->getSelect()->where($where);
            }
            if ($this->getData('construction') && $construction = trim($this->getData('construction'))) {
                $construction = explode(",", $construction);
                $collection->getSelect()->where('cps.construction IN (?)', $construction);
                if ($isFilterRequest && !empty($filterReq) && isset($filterReq["construction"]) &&
                    !empty($filterReq["construction"])) {
                    $this->prepareConstructionSelectedFilter($construction);
                }
            }
            $collection->getSelect()->order('is_new '. Collection::SORT_ORDER_DESC);
            $collection->getSelect()->order('ctbp.discount_price ' . Collection::SORT_ORDER_ASC);
            $collection->getSelect()->order('cpc.sort_order ' . Collection::SORT_ORDER_ASC);

            $collection->getSelect()->group('e.entity_id');
            if ($collection->getSize()) {
                $allRtaIds = (string)$this->generalHelper->getCommonConfig(CabinetHelper::ALL_RTA_IDS, $store->getStoreId());
                $allSignatureIds = (string)$this->generalHelper->getCommonConfig(CabinetHelper::ALL_SIGNATURE_IDS, $store->getStoreId());
                $rtaIds = explode(",", $allRtaIds);
                $signatureIds = explode(",", $allSignatureIds);
                foreach ($collection as $_category) {
                    $_category->setShippingTime($this->getLeadTime($_category));
                    $this->setTenByData($_category);
                    if(!in_array($_category->getParentCabinetLineId(),$rtaIds) ){
                        if(in_array($_category->getCabinetLineId(),$signatureIds)){
                            $signatureData[$_category->getParentId()]['category'][$_category->getColorType()][$_category->getId()] = $_category;
                        }else{
                            $customData[$_category->getParentId()]['category'][$_category->getColorType()][$_category->getId()] = $_category;
                        }

                    }else{
                         $rtaData[$_category->getParentId()]['category'][$_category->getColorType()][$_category->getId()] = $_category;
                    }
                    if (!$isFilterRequest) {
                        $this->prepareFilterOptions($_category);
                    }
                }
            }
            if (!empty($customData)) {
                $categoryData = $customData;
            }
            if (!empty($rtaData)) {
                $categoryData += $rtaData;
            }
            if (!empty($signatureData)) {
                $categoryData += $signatureData;
            }
            $categoryData = array_chunk($categoryData,self::PAGE_SIZE,true);
            $finalData['products'] = [];
            $finalData['total_pages'] = count($categoryData);
            if (array_key_exists((int)$page,$categoryData)) {
                $finalData['products'] = $categoryData[(int)$page];
            }

            $finalData['filters']['filter_options'] = $this->filter;
            $finalData['is_filter_request'] = $isFilterRequest;
        } catch (NoSuchEntityException|\Exception $e) {
            $this->_logger->critical($e);
        }
        return $finalData;
    }

    /**
     * Set Ten By Data
     *
     * @param object &$category
     */
    public function setTenByData(&$category) {
        $origPrice = (float)$category['ten_by_regular_price'];
        $discountPrice = (float)$category['ten_by_discount_price'];
        $percentage = ($origPrice - $discountPrice) / $origPrice * 100;
        $savePrice = ($origPrice - $discountPrice);
        $category['ten_by_percentage'] = round($percentage, 2).'% off';
        $category['ten_by_save_price'] = $savePrice;
    }

    /**
     * Prepare Filter Data.
     *
     * @param Category $category
     * @return void
     *
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     */
    protected function prepareFilterOptions(Category $category): void
    {         
        foreach ($this->filter_options as $key => $option) {
            if (!isset($this->filter[$key])) {
                $this->filter[$key] = [
                    'name' => $key,
                    'label' => $option,
                    'orig_' . $key => $this->getData($key),
                    'values' => []
                ];
            }
            if ($key == "cabinet_line_id") {
                $parentCabinetId = $category->getParentCabinetLineId();
                $cabinetId = $category->getCabinetLineId();
                if ($parentCabinetId) {
                    if (!isset($this->filter[$key]['values'][$parentCabinetId])) {
                        $this->filter[$key]['values'][$parentCabinetId] = [
                            'id' => $cabinetId . "," . $parentCabinetId,
                            'name' => $category->getData($this->filter_name[$key])
                        ];
                    } elseif (isset($this->filter[$key]['values'][$parentCabinetId]) &&
                        !empty($this->filter[$key]['values'][$parentCabinetId])) {
                        $ids = explode(",", $this->filter[$key]['values'][$parentCabinetId]["id"]);
                        if (!in_array($cabinetId, $ids)) {
                            $ids = array_merge($ids, [$cabinetId]);
                            $this->filter[$key]['values'][$parentCabinetId] = [
                                'id' => implode(',', $ids),
                                'name' => $category->getData($this->filter_name[$key])
                            ];
                        }
                    }
                } else {
                    if (!isset($this->filter[$key]['values'][$cabinetId])) {
                        $this->filter[$key]['values'][$cabinetId] = [
                            'id' => $cabinetId,
                            'name' => $category->getData($this->filter_name[$key])
                        ];
                    }
                }
            }
            elseif ($key == "construction") {                
                $constructionOption = $this->constructionOptions->getOptionsValues();                
                if (!isset($this->filter[$key]['values'][$category->getData($key)]) && $category->getData($key) != '') {
                    $this->filter[$key]['values'][$category->getData($key)] = [
                        'id' => $category->getData($key),
                        'name' => $constructionOption[$category->getData($key)]
                    ];
                }
            }
             elseif ($category->getData($key)) {
                if (!isset($this->filter[$key]['values'][$category->getData($key)])) {
                    $this->filter[$key]['values'][$category->getData($key)] = [
                        'id' => $category->getData($key),
                        'name' => $category->getData($this->filter_name[$key])
                    ];
                }
            }
        }
    }

    /**
     * Get connection.
     *
     * @return \Magento\Framework\DB\Adapter\AdapterInterface|string
     */
    protected function getConnection()
    {
        if (empty($this->connection)) {
            $this->connection = $this->resourceConnection->getConnection();
        }
        return $this->connection;
    }

    /**
     * Prepare style selected filter.
     *
     * @param array $doorId
     * @return void
     */
    private function prepareStyleSelectedFilter(array $doorId): void
    {
        $connection = $this->getConnection();
        $select = $connection->select()
            ->from($connection->getTableName('cp_door'), ['door_id', 'name'])
            ->where("door_id IN (?)", $doorId);
        $doors = $connection->fetchAssoc($select);
        if ($doors) {
            if (!isset($this->filter["door_id"])) {
                $this->filter["door_id"] = [
                    'name' => "door_id",
                    'label' => $this->filter_options["door_id"],
                    'values' => []
                ];
            }
            foreach ($doors as $door) {
                $this->filter["door_id"]['values'][$door["door_id"]] = [
                    'id' => $door["door_id"],
                    'name' => $door["name"]
                ];
            }
        }
    }

    /**
     * Prepare Cabinet selected filter.
     *
     * @param array $cabinetId
     * @return void
     */
    private function prepareCabinetSelectedFilter(array $cabinetId): void
    {
        $connection = $this->getConnection();
        $select = $connection->select()
            ->from(
                $connection->getTableName('cp_cabinet_line'),
                ['cabinet_line_id', 'supplier', 'parent_cabinet_line_id']
            )
            ->where("cabinet_line_id IN (?)", $cabinetId);
        $cabinets = $connection->fetchAssoc($select);
        if ($cabinets) {
            $this->filter["cabinet_line_id"] = [
                'name' => "cabinet_line_id",
                'label' => $this->filter_options["cabinet_line_id"],
                'values' => []
            ];
            $cabinets = array_replace(array_flip($cabinetId), $cabinets);
            foreach ($cabinets as $_cabinet) {
                $parentCabinetId = $_cabinet["parent_cabinet_line_id"];
                $cabinetId = $_cabinet["cabinet_line_id"];
                if ($parentCabinetId) {
                    if (!isset($this->filter["cabinet_line_id"]['values'][$parentCabinetId])) {
                        $this->filter["cabinet_line_id"]['values'][$parentCabinetId] = [
                            'id' => $cabinetId . "," . $parentCabinetId,
                            'name' => $_cabinet["supplier"]
                        ];
                    } elseif (isset($this->filter["cabinet_line_id"]['values'][$parentCabinetId]) &&
                        !empty($this->filter["cabinet_line_id"]['values'][$parentCabinetId])) {
                        $ids = explode(",", $this->filter["cabinet_line_id"]['values'][$parentCabinetId]["id"]);
                        if (!in_array($cabinetId, $ids)) {
                            $ids = array_merge($ids, [$cabinetId]);
                            $this->filter["cabinet_line_id"]['values'][$parentCabinetId] = [
                                'id' => implode(',', $ids),
                                'name' => $_cabinet["supplier"]
                            ];
                        }
                    }
                } else {
                    if (!isset($this->filter["cabinet_line_id"]['values'][$cabinetId])) {
                        $this->filter["cabinet_line_id"]['values'][$cabinetId] = [
                            'id' => $cabinetId,
                            'name' => $_cabinet["supplier"]
                        ];
                    }
                }
            }
        }
    }

    /**
     * Prepare Finish selected filter.
     *
     * @param array $colorCategoryId
     * @return void
     */
    private function prepareFinishSelectedFilter(array $colorCategoryId): void
    {
        $connection = $this->getConnection();
        $select = $connection->select()
            ->from($connection->getTableName('cp_color_category'), ['color_category_id', 'name'])
            ->where("color_category_id IN (?)", $colorCategoryId);
        $colorCategory = $connection->fetchAssoc($select);
        if ($colorCategory) {
            if (!isset($this->filter["color_category_id"])) {
                $this->filter["color_category_id"] = [
                    'name' => "door_id",
                    'label' => $this->filter_options["color_category_id"],
                    'values' => []
                ];
            }
            foreach ($colorCategory as $value) {
                $this->filter["color_category_id"]['values'][$value["color_category_id"]] = [
                    'id' => $value["color_category_id"],
                    'name' => $value["name"]
                ];
            }
        }
    }

    /**
     * Prepare Finish selected filter.
     *
     * @param array $colorCategoryId
     * @return void
     */
    private function prepareConstructionSelectedFilter(array $construction): void
    {
        $connection = $this->getConnection();
        $select = $connection->select()
            ->from($connection->getTableName('cp_style'), ['construction'])
            ->where("construction IN (?) ", $construction);
        $doors = $connection->fetchAssoc($select);
        if ($doors) {
            if (!isset($this->filter["construction"])) {
                $this->filter["construction"] = [
                    'name' => "construction",
                    'label' => $this->filter_options["construction"],
                    'values' => []
                ];
            }
            foreach ($doors as $door) {
                $this->filter["construction"]['values'][$door["construction"]] = [
                    'id' => $door["construction"],
                    'name' => $door["construction"]
                ];
            }
        }
    }

    /**
     * Prepare wood Type selected filter.
     *
     * @param array $typeId
     * @return void
     */
    private function prepareWoodTypeSelectedFilter(array $typeId): void
    {
        $connection = $this->getConnection();
        $select = $connection->select()
            ->from($connection->getTableName('cp_wood_type'), ['type_id', 'type_name'])
            ->where("type_id IN (?)", $typeId);
        $woodTypes = $connection->fetchAssoc($select);
        if ($woodTypes) {
            if (!isset($this->filter["type_id"])) {
                $this->filter["type_id"] = [
                    'name' => "type_id",
                    'label' => $this->filter_options["type_id"],
                    'values' => []
                ];
            }
            foreach ($woodTypes as $value) {
                $this->filter["type_id"]['values'][$value["type_id"]] = [
                    'id' => $value["type_id"],
                    'name' => $value["type_name"]
                ];
            }
        }
    }

    /**
     * Get Filter Request Url.
     *
     * @return string
     */
    public function getFilterRequestUrl(): string
    {
        return $this->getUrl("webquote/widget/allcabinetfilterrequest");
    }

    /**
     * Get Widget Title.
     *
     * @return array|mixed|null
     */
    public function getTitle(): mixed
    {
        return $this->getData("title");
    }

    /**
     * Check Has filter or not.
     *
     * @return bool
     */
    public function hasFilter(): bool
    {
        return !empty($this->filter) && count($this->filter);
    }

    /**
     * Get Currency Format.
     *
     * @return string
     */
    public function getCurrencyFormat(): string
    {
        try {
            $store = $this->_storeManager->getStore();
            return $store->getCurrentCurrency()->getOutputFormat();
        } catch (LocalizedException $e) {
            $this->_logger->critical($e);
        }
        return '';
    }

    /**
     * Get Lead Time
     *
     * @param  object $category
     * @return string
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     */
    public function getLeadTime($category) {
        $shippingTime = $category->getShippingTime();
        if(empty($shippingTime) || !$shippingTime || !trim($shippingTime)) {
            $shippingTime = $category->getStyleShippingTime();
            if(empty($shippingTime) || !$shippingTime || !trim($shippingTime)) {
                $shippingTime = $category->getCabinetShippingTime();
                if(empty($shippingTime) || !$shippingTime || !trim($shippingTime)) {
                    $shippingTime = CheckoutHelper::MINIMUM_LEAD_TIME.' - '.CheckoutHelper::MAXIMUM_LEAD_TIME. ' '.CheckoutHelper::LEAD_TIME_LABEL;
                }
            }
        }
        return $shippingTime;
    }
    /**
     * Get customer login status.
     *
     * @return bool
     */
    public function isCustomerLogin(): bool
    {
        return (bool)$this->authContext->getValue(\Magento\Customer\Model\Context::CONTEXT_AUTH);
    }
}
