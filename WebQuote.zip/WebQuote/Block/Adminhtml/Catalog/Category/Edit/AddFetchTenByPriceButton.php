<?php
/*
 *  Commercepundit
 *
 *  NOTICE OF LICENSE
 *
 * This source file is subject to the Commercepundit.com license that is
 * available through the world-wide-web at this URL:
 * http://commercepundit.com/license
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category   Commercepundit
 * @package    Commercepundit_Customer
 * @copyright  Copyright (c) Commercepundit (http://www.commercepundit.com/)
 * @license    http://www.commercepundit.com/LICENSE-1.0.html
 *
 */

namespace Commercepundit\WebQuote\Block\Adminhtml\Catalog\Category\Edit;

use Magento\Catalog\Block\Adminhtml\Category\AbstractCategory;
use Magento\Framework\View\Element\UiComponent\Control\ButtonProviderInterface;

/**
 * class AddFetchTenByPriceButton
 *
 * Add ten by price data fetch button in category edit.
 */
class AddFetchTenByPriceButton extends AbstractCategory implements ButtonProviderInterface
{

    /**
     * Get button data.
     *
     * @return array
     */
    public function getButtonData(): array
    {
        $category = $this->getCategory();
        if ($category && $category->getId() && !empty($category->getData('ten_by_price_sku')) &&
            $category->getIsShowTenByTenAddToCartButton()) {
            return $this->getButton();
        }
        return [];
    }

    /**
     * Get button
     *
     * @return array
     */
    public function getButton(): array
    {
        return [
            'id' => 'fetch_ten_by_price',
            'label' => __('Fetch 10x10 Price'),
            'on_click' => "setLocation('" . $this->getFetTenByPriceUrl() . "')",
            'class' => 'action-secondary action-event-edit',
            'sort_order' => 20
        ];
    }

    /**
     * Get Url
     *
     * @return string
     */
    public function getFetTenByPriceUrl(): string
    {
        return $this->getUrl(
            'cpwebquote/category/fetchtenbyprice/',
            [
                '_current' => false,
                '_query' => ['isAjax' => null],
                'category' => 1,
                'category_id' => (int)$this->getCategory()->getId(),
            ]
        );
    }
}
