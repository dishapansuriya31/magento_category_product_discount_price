<?php
/*
 *  Commercepundit
 *
 *  NOTICE OF LICENSE
 *
 * This source file is subject to the Commercepundit.com license that is
 * available through the world-wide-web at this URL:
 * http://commercepundit.com/license
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category   Commercepundit
 * @package    Commercepundit_WebQuote
 * @copyright  Copyright (c) Commercepundit (http://www.commercepundit.com/)
 * @license    http://www.commercepundit.com/LICENSE-1.0.html
 *
 */

namespace Commercepundit\WebQuote\Block\Adminhtml\Catalog\Category\Edit;

use Magento\Catalog\Block\Adminhtml\Category\AbstractCategory;
use Magento\Framework\View\Element\UiComponent\Control\ButtonProviderInterface;

/**
 * class AddFetchAsLowAsPriceButton
 *
 * Add ten by price data fetch button in category edit.
 */
class AddFetchAsLowAsPriceButton extends AbstractCategory implements ButtonProviderInterface
{
    /**
     * Get button data.
     *
     * @return array
     */
    public function getButtonData(): array
    {
        $category = $this->getCategory();
        if ($category && $category->getId()) {
            return $this->getButton();
        }
        return [];
    }

    /**
     * Get button
     *
     * @return array
     */
    public function getButton(): array
    {
        return [
            'id' => 'fetch_as_low_as_price',
            'label' => __('Fetch As Low As Price'),
            'on_click' => "setLocation('" . $this->getAsLowAsPriceUrl() . "')",
            'class' => 'action-secondary action-event-edit',
            'sort_order' => 20
        ];
    }

    /**
     * Get AsLowAs Price Url
     *
     * @return string
     */
    public function getAsLowAsPriceUrl(): string
    {
        return $this->getUrl(
            'cpwebquote/category/fetchAsLowAsPrice/',
            [
                '_current' => true,
                '_query' => ['isAjax' => null],
                'category_id' => (int)$this->getCategory()->getId(),
            ]
        );
    }
}
