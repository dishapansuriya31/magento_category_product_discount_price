<?php

namespace Commercepundit\WebQuote\Block\Adminhtml\Catalog\Category;

use Magento\Backend\Block\Template;
use Magento\Customer\Model\ResourceModel\Group\Collection as CustomerGroupCollection;
use Magento\Framework\App\RequestInterface;

class ShowSelected extends Template
{
    protected $request;
    protected $customerGroupCollection;

    public function __construct(
        Template\Context $context,
        RequestInterface $request,
        CustomerGroupCollection $customerGroupCollection,
        array $data = []
    ) {
        $this->request = $request;
        $this->customerGroupCollection = $customerGroupCollection;
        parent::__construct($context, $data);
    }

    /**
     * Get selected category IDs from form submission
     *
     * @return array
     */
    public function getSelectedCategoryIds()
    {
        $selectedCategoryIds = [];
        $postData = $this->request->getPostValue();
        if (isset($postData['categories']) && is_array($postData['categories'])) {
            $selectedCategoryIds = $postData['categories'];
        }
        return $selectedCategoryIds;
    }

    /**
     * Get customer groups
     *
     * @return array
     */
    public function getCustomerGroups()
    {
        return $this->customerGroupCollection->toOptionArray();
    }
   
   
}
