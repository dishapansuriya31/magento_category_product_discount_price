<?php
/**
 * Commercepundit
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Commercepundit.com license that is
 * available through the world-wide-web at this URL:
 * http://commercepundit.com/license
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category   Commercepundit
 * @package    Commercepundit_WebQuote
 * @copyright  Copyright (c) Commercepundit (http://www.commercepundit.com/)
 * @license    http://www.commercepundit.com/LICENSE-1.0.html
 */
namespace Commercepundit\WebQuote\Block;

use Commercepundit\Cabinets\Model\Color\Source\Group;
use Commercepundit\Cabinets\Model\Color\Source\Status as ColorStatus;
use Commercepundit\Cabinets\Model\Style\Source\Status;
use Magento\Framework\UrlInterface;

class Style extends \Magento\Framework\View\Element\Template
{
    /**
     * @var \Magento\Framework\App\ResourceConnection
     */
    protected $resourceConnection;

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $storeManager;

    /**
     * @var \Magento\Framework\Json\EncoderInterface
     */
    protected $jsonEncoder;

    /**
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param \Magento\Framework\App\ResourceConnection $resourceConnection
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Magento\Framework\Json\EncoderInterface $jsonEncoder
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Framework\App\ResourceConnection $resourceConnection,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\Json\EncoderInterface $jsonEncoder
    ) {
        $this->resourceConnection = $resourceConnection;
        $this->storeManager = $storeManager;
        $this->jsonEncoder = $jsonEncoder;
        parent::__construct($context);
    }

    /**
     * Get Media Url
     *
     * @return string
     */
    public function getMediaUrl()
    {
        return $this->storeManager->getStore()
            ->getBaseUrl(UrlInterface::URL_TYPE_MEDIA);
    }

    /**
     * Get Style Color Data
     *
     * @return array
     */
    public function getStyleColorData()
    {
        $connection = $this->resourceConnection->getConnection();
        $select = $connection->select()
            ->from(['CS' => $connection->getTableName('cp_style')])
            ->join(
                ['CSC' => $connection->getTableName('cp_style_color')],
                'CS.style_id = CSC.style_id',
                ['mapping_image'=>'CSC.image','price_id']
            )
            ->join(
                ['CC' => $connection->getTableName('cp_color')],
                'CSC.color_id = CC.color_id AND CC.status = ' . ColorStatus::STATUS_ENABLE,
                ['CC.color_id','color_image'=>'CC.image','color_name'=>'CC.name','color_group'=>'CC.group','CC.sort_order'] //phpcs:ignore
            )
            ->where('CS.status = ?', Status::STATUS_ENABLE)
            ->where('CS.cabinet_line_id IN(?)', [1])
            ->order('CC.sort_order ASC');
        $allData = $connection->fetchAll($select);
        $styleColorData = [];
        if (count($allData)) {
            $mediaUrl = $this->getMediaUrl();
            $defaultStyleId = 0;
            foreach ($allData as $data) {
                if ($defaultStyleId == 0) {
                    $defaultStyleId = $data['style_id'];
                }
                $data['defaultStyleId'] = $defaultStyleId;
                $this->formatStyleColorData($styleColorData, $data, $mediaUrl);
            }
        }
        return $styleColorData;
    }

    /**
     * Format Style Color Data
     *
     * @param  array  &$styleColorData
     * @param  array   $data
     * @param  string  $mediaUrl
     * @return void
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @SuppressWarnings(PHPMD.NPathComplexity)
     */
    protected function formatStyleColorData(&$styleColorData, $data, $mediaUrl)
    {
        if (isset($data['color_image']) && $data['color_image']) {
            $data['color_image'] = $mediaUrl . $data['color_image'];
        }
        if (isset($data['image']) && $data['image']) {
            $data['image'] = $mediaUrl . $data['image'];
        }
        if (isset($data['mapping_image']) && $data['mapping_image']) {
            $data['mapping_image'] = $mediaUrl . $data['mapping_image'];
        }
        if (!isset($styleColorData[$data['style_id']])) {
            $styleColorData[$data['style_id']] = $data;
        }
        if ($data['color_group'] == Group::STANDARD) {
            $styleColorData[$data['style_id']]['colors']['standard'][$data['color_id']] = $data;
        }
        if ($data['color_group'] == Group::DESIGNER) {
            $styleColorData[$data['style_id']]['colors']['designer'][$data['color_id']] = $data;
        }
    }

    /**
     * Json Encode data
     *
     * @param  array|string $data
     * @return string
     */
    public function jsonEncode($data)
    {
        return $this->jsonEncoder->encode($data);
    }
}
