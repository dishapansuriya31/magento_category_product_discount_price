<?php
/**
 * Commercepundit
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Commercepundit.com license that is
 * available through the world-wide-web at this URL:
 * http://commercepundit.com/license
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category   Commercepundit
 * @package    Commercepundit_WebQuote
 * @copyright  Copyright (c) Commercepundit (http://www.commercepundit.com/)
 * @license    http://www.commercepundit.com/LICENSE-1.0.html
 */

namespace Commercepundit\WebQuote\Block\Category;

use Magento\Framework\Pricing\Helper\Data as PriceHelper;

/**
 * ListCabinets files for category
 *
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class CabinetsSales extends \Magento\Framework\View\Element\Template
{
    /**
     * @var \Magento\Framework\Json\EncoderInterface
     */
    protected $jsonEncoder;

    /**
     * @var \Commercepundit\WebQuote\Api\CustomCabinetsCategoryInterface
     */
    protected $customCabinets;

    /**
     * @var \Commercepundit\WebQuote\Helper\Data
     */
    protected $webQuoteHelper;

    /**
     * @var PriceHelper
     */
    protected $priceHelper;

    /**
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param \Magento\Framework\Json\EncoderInterface $jsonEncoder
     * @param \Commercepundit\WebQuote\Api\CustomCabinetsCategoryInterface $customCabinets
     * @param \Commercepundit\WebQuote\Helper\Data $webQuoteHelper
     * @param PriceHelper $priceHelper,
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Framework\Json\EncoderInterface $jsonEncoder,
        \Commercepundit\WebQuote\Api\CustomCabinetsCategoryInterface $customCabinets,
        \Commercepundit\WebQuote\Helper\Data $webQuoteHelper,
        PriceHelper $priceHelper,
        array $data = []
    ) {
        $this->jsonEncoder = $jsonEncoder;
        $this->customCabinets = $customCabinets;
        $this->webQuoteHelper = $webQuoteHelper;
        $this->priceHelper = $priceHelper;
        parent::__construct($context, $data);
    }

    /**
     * Fetch sub categories based on category id
     *
     * @param int $categoryId
     * @return array
     * @throws LocalizedException
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    public function getSaleCategoryData()
    {
        try {
            return $this->customCabinets->getSaleCategoryData();
        } catch (LocalizedException $ex) {
            throw new LocalizedException(__($ex->getMessage()));
        }
    }

    /**
     * Get fomatted price
     *
     * @param float $price
     * @return float|string
     */
    public function getFormattedPrice(float $price)
    {
        return $this->priceHelper->currency($price, true, false);
    }

    /**
     * Json Encode data
     *
     * @param array|string $data
     * @return string
     */
    public function jsonEncode($data)
    {
        return $this->jsonEncoder->encode($data);
    }

    /**
     * Get Style Specifications
     *
     * @param  int $styleId
     * @return array
     */
    public function getStyleSpecifications($styleId) {
        return $this->webQuoteHelper->getStyleSpecifications($styleId);
    }
}
