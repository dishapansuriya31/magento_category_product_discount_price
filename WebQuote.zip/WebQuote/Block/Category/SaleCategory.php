<?php
/**
 * Commercepundit
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Commercepundit.com license that is
 * available through the world-wide-web at this URL:
 * http://commercepundit.com/license
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category   Commercepundit
 * @package    Commercepundit_WebQuote
 * @copyright  Copyright (c) Commercepundit (http://www.commercepundit.com/)
 * @license    http://www.commercepundit.com/LICENSE-1.0.html
 */

namespace Commercepundit\WebQuote\Block\Category;

use Commercepundit\WebQuote\Helper\Data as WebQuoteHelper;
use Magento\Catalog\Model\ResourceModel\Category\CollectionFactory;
use Magento\Customer\Model\Session as CustomerSession;
use Magento\Framework\Pricing\Helper\Data as PriceHelper;
use Magento\Framework\View\Element\Template\Context;

/**
 * SaleCategory files for category
 *
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class SaleCategory extends \Magento\Framework\View\Element\Template
{
    /**
     * @var CollectionFactory
     */
    protected $categoryCollectionFactory;

    /**
     * @var WebQuoteHelper
     */
    protected $_webQuoteHelper;

    /**
     * @var CustomerSession
     */
    protected $_customerSession;

    /**
     * @var PriceHelper
     */
    protected $_priceHelper;

    /**
     * @param Context $context
     * @param CollectionFactory $categoryCollectionFactory
     * @param WebQuoteHelper $webQuoteHelper
     * @param CustomerSession $customerSession
     * @param PriceHelper $priceHelper
     * @param array $data
     */
    public function __construct(
        Context           $context,
        CollectionFactory $categoryCollectionFactory,
        WebQuoteHelper    $webQuoteHelper,
        CustomerSession   $customerSession,
        PriceHelper       $priceHelper,
        array             $data = []
    ) {
        $this->collectionFactory = $categoryCollectionFactory;
        $this->_webQuoteHelper = $webQuoteHelper;
        $this->_customerSession = $customerSession;
        $this->_priceHelper = $priceHelper;
        parent::__construct($context, $data);
    }

    /**
     * GetSaleCategories
     *
     * @return object
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @SuppressWarnings(PHPMD.NPathComplexity)
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    public function getSaleCategories()
    {
        $collection = $this->collectionFactory->create();
        /*$customerGroupId = 0;
        if ($this->_webQuoteHelper->isCustomerLogin()) {
            $customerGroupId = $this->_customerSession->getCustomerGroupId();
        }*/
        $collection->addAttributeToSelect('*')
            ->addAttributeToFilter('is_sale_category', '1')
            ->addAttributeToFilter('is_active', '1');
        //->setPageSize(10)
        //->setCurPage(1);

        return $collection;
    }

    /**
     * Get ten by price discount data.
     *
     * @param float $regularPrice
     * @param float $discountPrice
     * @return float[]|null
     */
    public function getTenByPriceDiscount(float $regularPrice, float $discountPrice): ?array
    {
        if ($regularPrice > 0 && $discountPrice > 0) {
            $percentage = ($regularPrice - $discountPrice) / $regularPrice * 100;
            $savePrice = ($regularPrice - $discountPrice);
            return [
                'percentage' => (float)$percentage,
                'save_price' => $savePrice
            ];
        }
        return null;
    }

    /**
     * Get formatted price
     *
     * @param float $price
     * @return float|string
     */
    public function getFormattedPrice(float $price)
    {
        return $this->_priceHelper->currency($price, true, false);
    }

    /**
     * Get ten by price data.
     *
     * @param int $categoryId
     * @return mixed|null
     * @throws \Magento\Framework\Exception\LocalizedException
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getTenByPriceDiscountData($categoryId)
    {
        return $this->_webQuoteHelper->getTenByPriceDiscountData($categoryId);
    }
}
