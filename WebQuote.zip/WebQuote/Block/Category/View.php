<?php
/*
 * Commercepundit
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Commercepundit.com license that is
 * available through the world-wide-web at this URL:
 * http://commercepundit.com/license
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category   Commercepundit
 * @package    Commercepundit_WebQuote
 * @copyright  Copyright (c) Commercepundit (http://www.commercepundit.com/)
 * @license    http://www.commercepundit.com/LICENSE-1.0.html
 *
 *
 */

namespace Commercepundit\WebQuote\Block\Category;

class View extends \Magento\Catalog\Block\Category\View
{
    /**
     * @return View
     * @throws \Magento\Framework\Exception\LocalizedException
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @SuppressWarnings(PHPMD.NPathComplexity)
     */
    protected function _prepareLayout()
    {
        $this->getLayout()->createBlock(\Commercepundit\WebQuote\Block\Category\Breadcrumbs::class);
        $category = $this->getCurrentCategory();
        if ($category) {
            $title = $category->getMetaTitle();
            if ($title) {
                $this->pageConfig->getTitle()->set($title);
            }
            $description = $category->getMetaDescription();
            if ($description) {
                $this->pageConfig->setDescription($description);
            }
            $keywords = $category->getMetaKeywords();
            if ($keywords) {
                $this->pageConfig->setKeywords($keywords);
            }
            if ($category->getData("robot_index")) {
                $this->pageConfig->setRobots($category->getData("robot_index"));
            }
            if ($this->_categoryHelper->canUseCanonicalTag()) {
                $this->pageConfig->addRemotePageAsset(
                    $category->getUrl(),
                    'canonical',
                    ['attributes' => ['rel' => 'canonical']]
                );
            }

            $pageMainTitle = $this->getLayout()->getBlock('page.main.title');
            if ($pageMainTitle) {
                $pageMainTitle->setPageTitle($this->getCurrentCategory()->getName());
            }
        }
        return $this;
    }
}
