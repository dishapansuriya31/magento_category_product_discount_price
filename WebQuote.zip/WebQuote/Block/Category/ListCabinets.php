<?php
/**
 * Commercepundit
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Commercepundit.com license that is
 * available through the world-wide-web at this URL:
 * http://commercepundit.com/license
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category   Commercepundit
 * @package    Commercepundit_WebQuote
 * @copyright  Copyright (c) Commercepundit (http://www.commercepundit.com/)
 * @license    http://www.commercepundit.com/LICENSE-1.0.html
 */

namespace Commercepundit\WebQuote\Block\Category;

use Commercepundit\Cabinets\Api\Data\StylecolorInterface;
use Commercepundit\Cabinets\Model\Color\Source\Status as ColorStatus;
use Commercepundit\Cabinets\Model\SCSProductsManagement as SampleProductLoad;
use Commercepundit\Checkout\Helper\Data as CheckoutHelper;
use Commercepundit\General\Helper\Data as CoreHelper;
use Commercepundit\General\Model\Config\Source\Boolean;
use Commercepundit\Product\Helper\Data as ProductHelper;
use Commercepundit\WebQuote\Helper\Data as WebQuoteHelper;
use Commercepundit\WebQuote\Observer\AddCabinetsLayoutUpdateHandleObserver;
use Magento\Catalog\Model\CategoryFactory;
use Magento\Catalog\Model\Product\Attribute\Source\Status;
use Magento\Catalog\Model\ResourceModel\Category\StateDependentCollectionFactory;
use Magento\Framework\Data\Collection;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Json\EncoderInterface;
use Commercepundit\WebQuote\Api\CustomCabinetsCategoryInterface;
use Magento\Framework\Pricing\PriceCurrencyInterface;
use Magento\Framework\Registry;
use Magento\Framework\UrlInterface;
use Magento\Framework\View\Element\Template\Context;
use Commercepundit\Blog\Model\Config\Source\PostType;
use Magefan\Blog\Model\PostFactory;
use Magento\Framework\Pricing\Helper\Data as PriceHelper;
use Magento\Framework\App\ResourceConnection;
use Laminas\Filter\FilterInterface;

/**
 * ListCabinets files for category
 *
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 * @SuppressWarnings(PHPMD.ExcessiveClassComplexity)
 * @SuppressWarnings(PHPMD.TooManyFields)
 */
class ListCabinets extends \Magento\Framework\View\Element\Template
{
    /**
     * @const CATEGORY_LEVEL_4
     */
    public const CATEGORY_LEVEL_4 = '4';

    /**
     * @const CATEGORY_LEVEL_5
     */
    public const CATEGORY_LEVEL_5 = '5';

    /**
     * @const CATEGORY_LEVEL_6
     */
    public const CATEGORY_LEVEL_6 = '6';

    /**
     * @const CATEGORY_LEVEL_2
     */
    public const CATEGORY_LEVEL_2 = '2';

    /**
     * @const CATEGORY_LEVEL_3
     */
    public const CATEGORY_LEVEL_3 = '3';

    /**
     * @const DEFAULT_CATALOG_CATEGORY_ENTITY
     */
    public const DEFAULT_CATALOG_CATEGORY_ENTITY = 'catalog_category';

    /**
     * @const QUICK_QUOTE_URL
     */
    public const QUICK_QUOTE_URL = 'quick-quote-2';

    /**
     * @var Registry
     */
    protected $coreRegistry = null;

    /**
     * @var EncoderInterface
     */
    protected $jsonEncoder;

    /**
     * @var ProductHelper
     */
    protected $productHelper;

    /**
     * @var CategoryFactory
     */
    protected $_categoryFactory;

    /**
     * @var StateDependentCollectionFactory
     */
    protected $collectionFactory;

    /**
     * @var CoreHelper
     */
    protected $coreHelper;

    /**
     * @var CheckoutHelper
     */
    protected $checkoutHelper;

    /**
     * @var CustomCabinetsCategoryInterface
     */
    protected $customCabinets;

    /**
     * @var SampleProductLoad
     */
    protected $sampleproductload;

    /**
     * @var WebQuoteHelper
     */
    protected $_webQuoteHelper;

    /**
     * @var PostFactory
     */
    protected $postFactory;

    /**
     * @var PriceHelper
     */
    protected $priceHelper;

    /**
     * @var PriceCurrencyInterface
     */
    protected $priceCurrency;

    /**
     * @var FilterInterface
     */
    protected $templateProcessor;

    /**
     * @var ResourceConnection
     */
    protected $resourceConnection;

    /**
     * @var Magento\Catalog\Helper\Output
     */
    public $output;

    /**
     * @param Context $context
     * @param Registry $registry
     * @param EncoderInterface $jsonEncoder
     * @param ProductHelper $productHelper
     * @param CategoryFactory $categoryFactory
     * @param StateDependentCollectionFactory $categoryCollectionFactory
     * @param CoreHelper $coreHelper
     * @param CheckoutHelper $checkoutHelper
     * @param CustomCabinetsCategoryInterface $customCabinets
     * @param SampleProductLoad $sampleproductload
     * @param WebQuoteHelper $webQuoteHelper
     * @param PostFactory $postFactory
     * @param PriceHelper $priceHelper
     * @param ResourceConnection $resourceConnection
     * @param FilterInterface $templateProcessor
     * @param \Magento\Catalog\Helper\Output $output
     * @param array $data
     * @SuppressWarnings(PHPMD.ExcessiveParameterList)
     */
    public function __construct(
        Context                         $context,
        Registry                        $registry,
        EncoderInterface                $jsonEncoder,
        ProductHelper                   $productHelper,
        CategoryFactory                 $categoryFactory,
        StateDependentCollectionFactory $categoryCollectionFactory,
        CoreHelper                      $coreHelper,
        CheckoutHelper                  $checkoutHelper,
        CustomCabinetsCategoryInterface $customCabinets,
        SampleProductLoad               $sampleproductload,
        WebQuoteHelper                  $webQuoteHelper,
        PostFactory                     $postFactory,
        PriceHelper                     $priceHelper,
        ResourceConnection              $resourceConnection,
        FilterInterface $templateProcessor,
        \Magento\Catalog\Helper\Output $output,
        PriceCurrencyInterface $priceCurrency,
        array                           $data = []
    ) {
        $this->coreRegistry = $registry;
        $this->jsonEncoder = $jsonEncoder;
        $this->_categoryFactory = $categoryFactory;
        $this->productHelper = $productHelper;
        $this->collectionFactory = $categoryCollectionFactory;
        $this->coreHelper = $coreHelper;
        $this->checkoutHelper = $checkoutHelper;
        $this->customCabinets = $customCabinets;
        $this->sampleproductload = $sampleproductload;
        $this->_webQuoteHelper = $webQuoteHelper;
        $this->postFactory = $postFactory;
        $this->priceHelper = $priceHelper;
        $this->priceCurrency = $priceCurrency;
        $this->resourceConnection = $resourceConnection;
        $this->templateProcessor = $templateProcessor;
        $this->output = $output;
        parent::__construct($context, $data);
    }

    /**
     * Get Style Data by style id
     *
     * @param int $colorId
     * @param int $cabinetLineId
     * @param int|null $styleId
     * @return array
     */
    public function getSampleItemData($colorId, $cabinetLineId, $styleId)
    {
        $sampleProductData = $this->sampleproductload
            ->getSampleproductsByStylecolor($colorId, $cabinetLineId, $styleId);
        return end($sampleProductData);
    }

    /**
     * Retrieve current category model object
     *
     * @return \Magento\Catalog\Model\Category
     */
    public function getCurrentCategory()
    {
        if (!$this->hasData('current_category')) {
            $this->setData('current_category', $this->coreRegistry->registry('current_category'));
        }
        if(empty($this->getData('current_category'))
            && !empty($this->getCategoryId())){
            $this->setData('current_category', $this->_categoryFactory->create()->load($this->getCategoryId()));
        }
        return $this->getData('current_category');
    }

    /**
     * Retrieve current category model object
     *
     * @return \Magento\Catalog\Model\Category
     */
    public function getCabinetsCategoryList()
    {
        try {
            $category = $this->getCurrentCategory();
            $categoryLevel = $category->getLevel();
            $subcategories = [];
            if ($this->isCabinetCategory() || $this->isCustomCabinetCategory()
                && ($categoryLevel == self::CATEGORY_LEVEL_2
                    || $categoryLevel == self::CATEGORY_LEVEL_3
                    || $categoryLevel == self::CATEGORY_LEVEL_4)
            ) {
                //$categoryId = $category->getId();
                /*if ($categoryLevel == self::CATEGORY_LEVEL_4) {
                    $categoryId = $category->getParentId();
                }*/
                $subcategories = $this->getSubCategories();
            }
            return $subcategories;
        } catch (LocalizedException $ex) {
            throw new LocalizedException(__($ex->getMessage()));
        }
    }

    /**
     * Retrieve current category model object
     *
     * @return \Magento\Catalog\Model\Category
     */
    public function getCustomCabinetsCategoryList()
    {
        try {
            $category = $this->getCurrentCategory();
            $categoryLevel = $category->getLevel();
            $subcategories = [];
            if ($this->isCustomCabinetCategory()
                && ($categoryLevel == self::CATEGORY_LEVEL_3
                    || $categoryLevel == self::CATEGORY_LEVEL_4
                    || $categoryLevel == self::CATEGORY_LEVEL_5)
            ) {
                //$categoryId = $category->getId();
                /*if ($categoryLevel == self::CATEGORY_LEVEL_4) {
                    $categoryId = $category->getParentId();
                }*/
                $subcategories = $this->getSubCategories();
            }
            return $subcategories;
        } catch (LocalizedException $ex) {
            throw new LocalizedException(__($ex->getMessage()));
        }
    }

    /**
     * Retrieve current category model object
     *
     * @return \Magento\Catalog\Model\Category
     */
    public function getKitchenCabinetsLandingList()
    {
        try {
            $category = $this->getCurrentCategory();
            $categoryLevel = $category->getLevel();
            $subcategories = [];
            if ($this->isKitchenCabinetCategory()
                && ($categoryLevel == self::CATEGORY_LEVEL_2)
            ) {
                //$categoryId = $category->getId();
                $subcategories = $this->getSubCategories();
            }
            return $subcategories;
        } catch (LocalizedException $ex) {
            throw new LocalizedException(__($ex->getMessage()));
        }
    }

    /**
     * Retrieve current category model object
     *
     * @return \Magento\Catalog\Model\Category
     */
    public function isCabinetCategory()
    {
        $category = $this->getCurrentCategory();
        if ($category->getPageLayout() == AddCabinetsLayoutUpdateHandleObserver::CABINETS_LAYOUT
            && $category->getIsActive() == Status::STATUS_ENABLED) {
            return true;
        }
        return false;
    }

    /**
     * Retrieve current category model object
     *
     * @return \Magento\Catalog\Model\Category
     */
    public function isCustomCabinetCategory()
    {
        $category = $this->getCurrentCategory();
        if ($category->getPageLayout() == AddCabinetsLayoutUpdateHandleObserver::CUSTOM_CABINETS_LAYOUT
            && $category->getIsActive() == Status::STATUS_ENABLED) {
            return true;
        }
        return false;
    }

    /**
     * Retrieve current category model object
     *
     * @return \Magento\Catalog\Model\Category
     */
    public function getCustomCabinetsCategory()
    {
        try {
            $category = $this->getCurrentCategory();
            $categoryLevel = $category->getLevel();
            $subcategories = [];
            if ($this->isCustomCabinetCategory()
                && ($categoryLevel == self::CATEGORY_LEVEL_3)
            ) {
                $subcategories = $this->getCabinetSubCategories($category->getId());
            }
            return $subcategories;
        } catch (LocalizedException $ex) {
            throw new LocalizedException(__($ex->getMessage()));
        }
    }

    /**
     * Fetch sub categories based on category id
     *
     * @param int $categoryId
     * @return array
     * @throws LocalizedException
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    public function getCabinetSubCategories($categoryId)
    {
        try {
            $category = $this->customCabinets
                ->getCustomcabinetscategory($categoryId,$this->getFilteredData());
            return $category;
        } catch (LocalizedException $ex) {
            throw new LocalizedException(__($ex->getMessage()));
        }
    }

    /**
     * Retrieve current category model object
     *
     * @return \Magento\Catalog\Model\Category
     */
    public function isKitchenCabinetCategory()
    {
        $category = $this->getCurrentCategory();
        if ($category->getPageLayout() == AddCabinetsLayoutUpdateHandleObserver::KITCHEN_CABINETS_LAYOUT
            && $category->getIsActive() == Status::STATUS_ENABLED) {
            return true;
        }
        return false;
    }

    /**
     * Fetch sub categories based on category id
     *
     * @param int $categoryId
     * @return array
     * @throws LocalizedException
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @SuppressWarnings(PHPMD.NPathComplexity)
     * @SuppressWarnings(PHPMD.UnusedLocalVariable)
     */
    public function getSubCategories()
    {
        try {
            $categoryData = [];
            $currentcategory = $this->getCurrentCategory();
            if ($currentcategory && $currentcategory->getId()) {
                if ($currentcategory->getChildrenCount() > Boolean::NO) {
                    $childcategory = $currentcategory->getChildrenCategories()->addAttributeToSelect([
                        'image',
                        'shipping_time',
                        'doorstyle_image',
                        'style_id',
                        'color_id',
                        'cabinetline',
                        'yotpo_product_id',
                        'description']);
                    $baseUrl = $this->getBaseUrl();
                    foreach ($childcategory as $category) {
                        $imageUrl = $category->getImageUrl() ? $baseUrl. $category->getImageUrl() : null;
                        $shippingTime = $category->getShippingTime();
                        $subcategoriesDescription = $category->getDescription() ? $category->getDescription() : null;
                        $doorstyleImgUrl = $category->getDoorstyleImage()
                            ? $baseUrl . $category->getDoorstyleImage() : null;
                        $categoryData[] = [
                            'id' => $category->getId(),
                            'name' => $category->getName(),
                            'url' => $category->getUrl(),
                            'parent_cat_url' => $currentcategory->getUrl(),
                            'image_url' => $imageUrl,
                            'shipping_time' => $shippingTime,
                            'doorstyle_image' => $doorstyleImgUrl,
                            'description' => $subcategoriesDescription,
                            'style_id' => $category->getStyleId(),
                            'color_id' => $category->getColorId(),
                            'cabinetline' => $category->getCabinetline(),
                            'yotpo_product_id' => $category->getYotpoProductId()
                        ];
                    }
                }
            }
            return $categoryData;
        } catch (LocalizedException $ex) {
            throw new LocalizedException(__($ex->getMessage()));
        }
    }

    /**
     * Fetch sub categories based on category id
     *
     * @param int $categoryId
     * @return array
     * @throws LocalizedException
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @SuppressWarnings(PHPMD.NPathComplexity)
     * @SuppressWarnings(PHPMD.UnusedLocalVariable)
     */
    public function getSubCategoriesByCategoryId($categoryId)
    {
        try {
            $categoryData = [];
            $currentcategory = $this->_categoryFactory->create()->load($categoryId);
            if ($currentcategory && $currentcategory->getId()) {
                if ($currentcategory->getChildrenCount() > Boolean::NO) {
                    $childcategory = $currentcategory->getChildrenCategories()->addAttributeToSelect([
                        'image',
                        'shipping_time',
                        'doorstyle_image',
                        'include_in_menu',
                        'description']);
                    $baseUrl = $this->getBaseUrl();
                    foreach ($childcategory as $category) {
                        $imageUrl = $category->getImageUrl() ? $baseUrl. $category->getImageUrl() : null;
                        $shippingTime = $category->getShippingTime();
                        $doorstyleImg = $category->getDoorstyleImage();
                        $subcategoriesDescription = $category->getDescription() ? $category->getDescription() : null;
                        $doorstyleImgUrl =
                            $category->getDoorstyleImage() ? $baseUrl. $category->getDoorstyleImage() : null;
                        $categoryData[] = [
                            'id' => $category->getId(),
                            'include_in_menu' => $category->getIncludeInMenu(),
                            'name' => $category->getName(),
                            'url' => $category->getUrl(),
                            'parent_cat_url' => $currentcategory->getUrl(),
                            'image_url' => $imageUrl,
                            'shipping_time' => $shippingTime,
                            'doorstyle_image' => $doorstyleImgUrl,
                            'description' => $subcategoriesDescription
                        ];
                    }
                }
            }
            return $categoryData;
        } catch (LocalizedException $ex) {
            throw new LocalizedException(__($ex->getMessage()));
        }
    }

    /**
     * Fetch current categories based on category id
     *
     * @param int $categoryId
     * @return array
     * @throws LocalizedException
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @SuppressWarnings(PHPMD.NPathComplexity)
     * @SuppressWarnings(PHPMD.UnusedLocalVariable)
     */
    public function getCategoryDataByCategoryId($categoryId)
    {
        try {
            $categoryData = [];
            $currentcategory = $this->_categoryFactory->create()->load($categoryId);
            if ($currentcategory && $currentcategory->getId()) {
                $baseUrl = $this->getBaseUrl();
                foreach ($currentcategory as $category) {
                    $imageUrl = isset($category['image']) ? $baseUrl. $category['image'] : null;
                    $shippingTime = array_key_exists('shipping_time', $category) ? $category['shipping_time'] : null;
                    $doorstyleImgUrl = array_key_exists('doorstyle_image', $category) ? $baseUrl. $category['doorstyle_image'] : null;
                    $subcategoriesDescription = array_key_exists('description', $category) ? $category['description'] : null;
                    $categoryUrl = $category['url_key'] ? $baseUrl. $category['url_key'] . ".html" : null;
                    $categorySpecification = array_key_exists('specification', $category) ?
                        $category['specification'] : null;
                    $categoryAbout = array_key_exists('about', $category) ? $category['about'] : null;
                    $CabinetTerms = array_key_exists('cabinet_terms', $category) ? $category['cabinet_terms'] : null;
                    $CabinetAssembly = array_key_exists('assembly', $category) ? $category['assembly'] : null;
                    $H1Title = array_key_exists('heading_title', $category) ? $category['heading_title'] : null;
                    $cabinetline = array_key_exists('cabinetline', $category) ? $category['cabinetline'] : null;
                    $colorId = array_key_exists('color_id', $category) ? $category['color_id'] : null;
                    $styleId = array_key_exists('style_id', $category) ? $category['style_id'] : null;
                    $categoryData[] = [
                        'id' => $category['entity_id'],
                        'name' => $category['name'],
                        'url' => $categoryUrl,
                        'parent_cat_url' => $currentcategory->getUrl(),
                        'parent_cat_id' => $currentcategory->getParentId(),
                        'level' => $currentcategory->getLevel(),
                        'hmc_cat_url_key' => $currentcategory->getHmcCatUrlKey(),
                        'hmc_par_cat_url_key' => $currentcategory->getParentCategory()->getHmcCatUrlKey(),
                        'image_url' => $imageUrl,
                        'shipping_time' => $shippingTime,
                        'doorstyle_image' => $doorstyleImgUrl,
                        'description' => $subcategoriesDescription,
                        'specification' => $categorySpecification,
                        'about' => $categoryAbout,
                        'cabinet_terms' => $CabinetTerms,
                        'assembly' => $CabinetAssembly,
                        'heading_title' => $H1Title,
                        'cabinetline' => $cabinetline,
                        'colorId' => $colorId,
                        'styleId' => $styleId
                    ];
                }
            }
            return $categoryData;
        } catch (LocalizedException $ex) {
            throw new LocalizedException(__($ex->getMessage()));
        }
    }

    /**
     * Json Encode data
     *
     * @param array|string $data
     * @return string
     */
    public function jsonEncode($data)
    {
        return $this->jsonEncoder->encode($data);
    }

    /**
     * Get ten by price.
     *
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getTenByPrice()
    {
        if ($this->isCustomCabinetCategory()) {
            $category = $this->getCurrentCategory();
            $categoryId = $category->getLevel() == self::CATEGORY_LEVEL_6 ? $category->getParentId() :
                $category->getId();
            if ($category && $category->getId()) {
                return $this->_webQuoteHelper->getTenByPriceDiscountData($categoryId);
            }
        }
        if ($this->isCabinetCategory()) {
            $category = $this->getCurrentCategory();
            $categoryId = $category->getLevel() == self::CATEGORY_LEVEL_5 ? $category->getParentId() :
                $category->getId();
            if ($category && $category->getId()) {
                return $this->_webQuoteHelper->getTenByPriceDiscountData($categoryId);
            }
        }
        return '';
    }

    /**
     * Get fomatted price
     *
     * @param float $price
     * @return float|string
     */
    public function getFormattedPrice(float $price)
    {
        return $this->priceHelper->currency($price, true, false);
    }

    /**
     * Get ten by products skus.
     *
     * @return mixed|string
     */
    public function getTenByProductSku()
    {
        $category = $this->getCurrentCategory();
        if ($this->isCustomCabinetCategory()) {
            $categoryId = $category->getLevel() == self::CATEGORY_LEVEL_6 ? $category->getParentId() :
                $category->getId();
            $category = $this->_categoryFactory->create()->load($categoryId);
            if ($category && $category->getId()) {
                return $category->getData('ten_by_price_sku') ?? '';
            }
        }
        if ($this->isCabinetCategory()) {
            $categoryId = $category->getLevel() == self::CATEGORY_LEVEL_5 ? $category->getParentId() :
                $category->getId();
            $category = $this->_categoryFactory->create()->load($categoryId);
            if ($category && $category->getId()) {
                return $category->getData('ten_by_price_sku') ?? '';
            }
        }
        return '';
    }

    public function getTenByProductData()
    {
        $tenByData = [];
        $category = $this->getCurrentCategory();
        if ($this->isCustomCabinetCategory()) {
            $categoryId = $category->getLevel() == self::CATEGORY_LEVEL_6 ? $category->getParentId() :
                $category->getId();
            $category = $this->_categoryFactory->create()->load($categoryId);
            if ($category && $category->getId()) {
                $tenByData['sku'] = $category->getData('ten_by_price_sku') ?? null;
                $tenByData['price'] = $this->_webQuoteHelper->getTenByPriceDiscountData($categoryId);
                $tenByData['cart_btn'] = $category->getIsShowTenByTenAddToCartButton() ?? false;
            }
        }
        if ($this->isCabinetCategory()) {
            $categoryId = $category->getLevel() == self::CATEGORY_LEVEL_5 ? $category->getParentId() :
                $category->getId();
            $category = $this->_categoryFactory->create()->load($categoryId);
            if ($category && $category->getId()) {
                $tenByData['sku'] = $category->getData('ten_by_price_sku') ?? null;
                $tenByData['price'] = $this->_webQuoteHelper->getTenByPriceDiscountData($categoryId);
                $tenByData['cart_btn'] = $category->getIsShowTenByTenAddToCartButton() ?? false;
            }
        }
        return $tenByData;
    }
    /**
     * Get ten by price data.
     *
     * @param int $categoryId
     * @return mixed|null
     * @throws \Magento\Framework\Exception\LocalizedException
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getTenByPriceDiscountData($categoryId)
    {
        return $this->_webQuoteHelper->getTenByPriceDiscountData($categoryId);
    }

    /**
     * Get Gallery data
     *
     * @return object
     */
    public function getGalleryData($categoryId)
    {
        $categoryData = [];
        $collection = $this->postFactory->create()->getCollection();
        $collection->getSelect()->joinLeft(
            ['blog_category' => $collection->getTable('cp_blog_category')],
            'main_table.post_id = blog_category.post_id',
            [
                'blog_category_category_id' => 'blog_category.category_id',
                'blog_category_post_id' => 'blog_category.post_id'
            ]
        );

        //$collection->addFieldToFilter('main_table.post_type', PostType::POST_TYPE_CATEGORY);
        //$collection->addFieldToFilter('main_table.is_active', Boolean::NO);
        $collection->addFieldToFilter('main_table.post_type', PostType::POST_TYPE_GALLERY);
        //$collection->addFieldToFilter('main_table.is_active', Boolean::YES);
        $collection->addFieldToFilter('blog_category.category_id', ['eq' => $categoryId]);

        $collection->setOrder('main_table.update_time', 'DESC');
        if ($collection->getSize() > 0) {
            foreach ($collection as $data) {
                $_imageData = json_decode((string) $data['media_gallery'], true);
                if (!$_imageData || !is_array($_imageData) || empty($_imageData)) {
                    $_imageData = explode(";", (string) $data['media_gallery']);
                }
                if (!empty($_imageData) && count($_imageData) > 0) {
                    $categoryData[] = $_imageData;
                }
            }
        }
        return $categoryData;
    }

    /**
     * Get Media Url
     *
     * @return string
     */
    public function getMediaUrl()
    {
        return $this->_storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);
    }

    /**
     * Get Cabinet Line Data
     *
     * @param string $cabinetId
     * @return string|null
     */

    public function getCabinetLineData($cabinetId)
    {
        $connection = $this->resourceConnection->getConnection();
        $select = $connection->select()
                ->from(
                    $connection->getTableName('cp_cabinet_line'),
                    ['pdf_attachment','badge_images','cabinet_name']
                )->where('cabinet_line_id = ?', $cabinetId);
        return $connection->fetchRow($select);

    }
    /**
     * Define if the 10*10 special price should be shown
     *
     * @return bool
     */
    public function hasTenBySpecialPrice()
    {
        $tenByPriceData      = $this->getTenByPrice();
        $displayRegularPrice = isset($tenByPriceData['regular_price']) ? $tenByPriceData['regular_price'] : false;
        $displayFinalPrice   = isset($tenByPriceData['discount_price']) ? $tenByPriceData['discount_price'] : false ;
        return $displayFinalPrice < $displayRegularPrice;
    }

    /**
     * Get Style Specifications
     *
     * @param  int $styleId
     * @return array
     */
    public function getStyleSpecifications($styleId) {
        return $this->_webQuoteHelper->getStyleSpecifications($styleId);
    }

    /**
     * Get Wysiwyg Content.
     *
     * @param $content
     * @return false|mixed
     */
    public function getWysiwygContent($content): mixed
    {
        try {
            return $this->templateProcessor->filter($content);
        } catch (\Exception $e) {
            return false;
        }
    }

    /**
     * Get subcategories data.
     *
     * @return array|null
     *
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    public function getSubCategoryStyleColor(): ?array
    {
        $category = $this->getCurrentCategory();
        if (!$category?->getId()) {
            return null;
        }
        try {
            $collection = $category->getChildrenCategories();
            if ($collection->getSize() <= 0) {
                return null;
            }
            $store = $this->_storeManager->getStore();
            $mediaUrl = $store->getBaseUrl(UrlInterface::URL_TYPE_MEDIA);
            $collection->setStoreId($store->getId());
            $selectFields = [
                'name',
                'image',
                'color_id',
                'style_id',
                'cabinetline',
                'woodspecies_id',
                'description'
            ];
            $collection->addAttributeToSelect($selectFields, 'left');
            $collection->addAttributeToFilter('include_in_menu', 1);
            $collection->addAttributeToFilter('level', ['in' => [ListCabinets::CATEGORY_LEVEL_5]]);
            $collection->addAttributeToFilter(
                'page_layout',
                AddCabinetsLayoutUpdateHandleObserver::CUSTOM_CABINETS_LAYOUT
            );
            $collection->addIsActiveFilter();
            $collection->addOrder('level', Collection::SORT_ORDER_ASC);
            $collection->getSelect()->joinLeft(
                ['cpc' => $collection->getTable('cp_color')],
                "IF(at_color_id.value_id > 0, at_color_id.value, at_color_id_default.value)  = cpc.color_id",
                [
                    'color_swatch_image' => new \Zend_Db_Expr("CONCAT('$mediaUrl',cpc.image)")
                ]
            )->joinLeft(
                ['cct' => $collection->getTable('cp_color_type')],
                'cpc.type_id = cct.type_id',
                ['color_type' => 'cct.name']
            );
            $collection->getSelect()->order('cpc.sort_order ' . Collection::SORT_ORDER_ASC);
            $collection->getSelect()->order('e.position ' . Collection::SORT_ORDER_ASC);
            $collection->getSelect()->group('e.entity_id');
            $categoryData = [];
            $baseUrl = $this->getBaseUrl();
            if ($collection->getSize()) {
                foreach ($collection as $_category) {
                    if (!isset($categoryData['child'])) {
                        $categoryData['image_url'] = $_category->getImageUrl();
                        $categoryData['name'] = $_category->getName();
                        $categoryData['description'] = $_category->getDescription();
                    }
                    $categoryData['child'][$_category->getColorType()][] = [
                        'cat_id' => $_category->getId(),
                        'name' => $_category->getName(),
                        'url' => $_category->getUrl(),
                        'image_url' => $baseUrl . $_category->getImageUrl(),
                        'swatch_image' => $_category->getColorSwatchImage() ?? null,
                        'color_type' => $_category->getColorType(),
                        'style_id' => $_category->getStyleId() ?? null,
                        'color_id' => $_category->getColorId() ?? null,
                        'cabinetline' => $_category->getCabinetline() ?? null,
                        'woodspecies_id' => $_category->getWoodspeciesId() ?? null,
                        'description' => $this->output->categoryAttribute(
                            $_category,
                            $_category->getDescription(),
                            'description'
                        )
                    ];
                }
                return $categoryData;
            }
        } catch (\Exception|NoSuchEntityException|LocalizedException $exception) {
            $this->_logger->critical($exception);
        }
        return null;
    }

    public function getDisplayCurrencyCode()
    {
        return $this->priceCurrency->getCurrency()->getCurrencyCode();
    }

    /**
     * @param $category
     * @return int[]
     */
    public function getShippingMinMaxTime($category)
    {
        // Initialize shipping time info
        $shippingInfo = [
            'min' => 0,
            'max' => 0,
            'time_line' => ""
        ];

        // Define the pattern to split shipping time
        $pattern = '/[to,-]/';

        // Get shipping time
        $shippingTime = strtolower($this->customCabinets->getLeadTime($category));

        if (!empty($shippingTime)) {
            // Split the shipping time into min and max
            $shippingTimes = preg_split($pattern, $shippingTime, -1, PREG_SPLIT_NO_EMPTY);
            if (!empty($shippingTimes)) {
                // Assign min and max shipping time
                $shippingInfo['min'] = (int) reset($shippingTimes);// Get the array first value.
                $shippingInfo['max'] = (int) end($shippingTimes);// Get the array last value.
            }

            // Determine the timeline (week or day)
            if (strpos($shippingTime, 'week') !== false || strpos($shippingTime, 'weeks') !== false) {
                $shippingInfo['time_line'] = 'WEEK';
            } elseif (strpos($shippingTime, 'day') !== false) {
                $shippingInfo['time_line'] = 'DAY';
            }
        }
        return $shippingInfo;
    }

    /**
     * Get Available Sort Orders.
     *
     * @return array
     */
    public function getAvailableOrders() {
        $availableSortBy = $this->getCurrentCategory()->getAvailableSortByOptions();
        if ($availableSortBy) {
            if (array_key_exists('price', $availableSortBy)) {
                $availableSortBy['low_to_high'] = "Price Low to High";
                $availableSortBy['high_to_low'] = "Price High to Low";
                unset($availableSortBy['price']);
            }
            if (array_key_exists('position', $availableSortBy)) {
                $availableSortBy['position'] = 'Default';
            }
        }
        return $availableSortBy;
    }
}
