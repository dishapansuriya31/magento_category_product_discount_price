<?php
/*
 * Commercepundit
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Commercepundit.com license that is
 * available through the world-wide-web at this URL:
 * http://commercepundit.com/license
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category   Commercepundit
 * @package    Commercepundit_Customer
 * @copyright  Copyright (c) Commercepundit (http://www.commercepundit.com/)
 * @license    http://www.commercepundit.com/LICENSE-1.0.html
 *
 *
 */

namespace Commercepundit\WebQuote\Block\Category;

use Magento\Catalog\Helper\Data;
use Magento\Catalog\Model\CategoryRepository;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\View\Element\Template\Context;

/**
 * class Breadcrumbs
 *
 * Category breadcrumbs customizations.
 */
class Breadcrumbs extends \Magento\Theme\Block\Html\Breadcrumbs
{
    /**
     * Catalog data
     *
     * @var Data
     */
    protected $catalogData;

    /**
     * @var CategoryRepository
     */
    protected $categoryRepository;

    /**
     * @param Context $context
     * @param Data $catalogData
     * @param CategoryRepository $categoryRepository
     * @param array $data
     */
    public function __construct(
        Context            $context,
        Data               $catalogData,
        CategoryRepository $categoryRepository,
        array              $data = []
    ) {
        $this->catalogData = $catalogData;
        $this->categoryRepository = $categoryRepository;
        parent::__construct($context, $data);
    }

    /**
     * Preparing layout
     *
     * @return $this
     */
    protected function _prepareLayout(): static
    {
        try {
            if ($breadcrumbsBlock = $this->getLayout()->getBlock('breadcrumbs')) {
                try {
                    $breadcrumbsBlock->addCrumb(
                        'home',
                        [
                            'label' => __('Home'),
                            'title' => __('Go to Home Page'),
                            'link' => $this->_storeManager->getStore()->getBaseUrl()
                        ]
                    );
                } catch (NoSuchEntityException $e) {
                }

                //$title = [];
                $path = $this->catalogData->getBreadcrumbPath();
                $isUsedInBreadCrumb = true;

                foreach ($path as $name => $breadcrumb) {
                    $categoryId = explode('category', $name);
                    if (!empty($categoryId) && is_array($categoryId)) {
                        $categoryId = implode('', array_filter($categoryId));
                    }
                    if (is_numeric($categoryId)) {
                        $isUsedInBreadCrumb = (bool)$this->categoryRepository->get($categoryId)->getIsUsedInBreadcrumb()
                            ?? $isUsedInBreadCrumb;
                    }
                    if ($isUsedInBreadCrumb) {
                        $breadcrumbsBlock->addCrumb($name, $breadcrumb);
                        //$title[] = $breadcrumb['label'];
                    }
                }
                //$this->pageConfig->getTitle()->set(join($this->getTitleSeparator(), array_reverse($title)));
            }
        } catch (NoSuchEntityException|LocalizedException $e) {
            $this->_logger->critical($e);
        }
        return parent::_prepareLayout();
    }
}

