<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_ProductOptions
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Commercepundit\WebQuote\Block\Product\View\Options\Type;

use Commercepundit\Homemark\Helper\Data as HomemarkHelper;
use Exception;
use Magento\Catalog\Block\Product\View\Options\AbstractOptions;
use Magento\Catalog\Helper\Data as CatalogHelper;
use Magento\Catalog\Model\Product\Option;
use Magento\Catalog\Model\Product\Option\Value;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Pricing\Helper\Data as PricingHelper;
use Magento\Framework\View\Element\Template\Context;
use Mageplaza\ProductOptions\Block\Product\View\Options\Tooltip;
use Mageplaza\ProductOptions\Helper\Data as HelperData;
use Mageplaza\ProductOptions\Helper\Image as HelperImage;
use Mageplaza\ProductOptions\Model\Option\Value as MpValue;
use Mageplaza\ProductOptions\Ui\DataProvider\AbstractCustomOptions;
use Commercepundit\Product\Model\Option as ProductOption;

/**
 * Class Swatch
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 * Mageplaza\ProductOptions\Block\Product\View\Options\Type
 */
class Swatch extends AbstractOptions
{
    /**
     * @var HelperData
     */
    public $_helperData;

    /**
     * @var HelperImage
     */
    protected $_helperImage;

    /**
     * @var Tooltip
     */
    protected $_mpOptions;

    /**
     * @var HomemarkHelper
     */
    protected $homemarkHelper;

    /**
     * Swatch constructor.
     *
     * @param Context $context
     * @param PricingHelper $pricingHelper
     * @param CatalogHelper $catalogData
     * @param Tooltip $mpOptions
     * @param HelperData $helperData
     * @param HelperImage $helperImage
     * @param array $data
     */
    public function __construct(
        Context $context,
        PricingHelper $pricingHelper,
        CatalogHelper $catalogData,
        Tooltip $mpOptions,
        HelperData $helperData,
        HelperImage $helperImage,
        HomemarkHelper $homemarkHelper,
        array $data = []
    ) {
        $this->_mpOptions = $mpOptions;
        $this->_helperData = $helperData;
        $this->_helperImage = $helperImage;
        $this->homemarkHelper   = $homemarkHelper;

        parent::__construct(
            $context,
            $pricingHelper,
            $catalogData,
            $data
        );
    }

    /**
     * Get Value Html for swatch
     *
     * @param bool $isFront
     * @throws LocalizedException
     * @throws NoSuchEntityException
     * @SuppressWarnings(Unused)
     */
    public function getValuesHtml($isFront = false)
    {
        $_option = $this->getOption();

        /** Remove inline prototype onclick and onchange events */
        $optionType = $_option->getType();
        if ($optionType === AbstractCustomOptions::FIELD_TEXT_SWATCH
            || $optionType === AbstractCustomOptions::FIELD_VISUAL_SWATCH) {
            return $this->getSwatchesHtml($_option, $isFront);
        }

        return '';
    }

    /**
     * GetSwatchesHtml
     *
     * @param Option $option
     * @param bool $isFront
     * @return string
     * @throws NoSuchEntityException
     * @throws LocalizedException
     * @throws Exception
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @SuppressWarnings(PHPMD.NPathComplexity)
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    public function getSwatchesHtml($option, $isFront)
    {
        $optionId = $option->getId();
        $configValue = $this->getProduct()->getPreconfiguredValues()->getData('options/' . $optionId);
        if (is_array($configValue)) {
            $configValue = $configValue[0];
        }
        $store = $this->getProduct()->getStore();
        $selectHtml = $isFront ? '<div class="mp-swatch-attribute mp-swatch-attribute-' . $optionId . '"
        data-mage-init=\'{"mpBPO/swatches":{"priceFormat": ' . $this->_helperData->getJsonPriceFormat() . ',
            "optionConfig" : ' . $this->_mpOptions->getJsonConfig() . '
            }}\'>'
            : '<div class="mp-swatch-attribute mp-swatch-attribute-' . $optionId . '">';
        $selectHtml .= '<div class="mp-swatches mp-swatch-attribute-options clearfix" id="options-' .
                       $optionId . '-list">';
        if ($option->getIsRequire()) {
            $_textValidate['required'] = true;
            $requiredClass = ' required-entry';
        } else {
            $_textValidate = null;
            $requiredClass = '';
        }

        $count = 1;
        $defaultValue = '';
        $priceValue = '';
        foreach ($option->getValues() as $_value) {
            /* to check value to show on front or not */
            if ($_value->getMpHideOnFront() == 0) {
                /** @var Value|MpValue $_value */
                $count++;
                $htmlValue = $_value->getOptionTypeId();
                if (($configValue === '' || $configValue === null) && $_value->getData('mp_is_default')) {
                    $configValue = $_value->getOptionTypeId();
                }

                $selected = $configValue === $htmlValue ? 'selected' : '';
                $price = $_value->getPriceType() === Value::TYPE_PERCENT
                    ? $_value->getPrice(true)
                    : $this->pricingHelper->currencyByStore($_value->getPrice(true), $store, false);
                $specialPriceAttr = '';
                if ($this->_helperData->isSpecialPrice($_value)) {
                    $specialPriceAttr = 'regular-price="' . $price . '"';

                    $price = $this->pricingHelper->currencyByStore($_value->getMpSpecialPrice(), $store, false);
                }
                if ($configValue) {
                    $defaultValue = $configValue;
                    $priceValue = $this->pricingHelper->currencyByStore($_value->getPrice(true), $store, false);
                }
                if ($option->getType() === AbstractCustomOptions::FIELD_TEXT_SWATCH) {
                    $selectHtml .= '<div class="mp-img-tooltip-wrapper" title="' . $_value->getTitle() . '"
                    data-option-type-id="' . $htmlValue . '">
                    <div class="mp-swatch-option mp-swatch-option-' . $option->getId() . ' text ' . $selected . '"
                        id="options_' . $option->getId() . '_' . $count . '"
                        data-option-id="' . $option->getId() . '"
                        data-option-sku="' . $_value->getSku() . '"
                        data-option-type-id="' . $htmlValue . '"
                        value="' . $htmlValue . '"
                        data-option-title="' . $_value->getTitle() . '"
                        price="' . $price . '" ' . $specialPriceAttr . '
                        data-role="select-swatch">' . $_value->getMpTextSwatch() . '</div></div>';
                } else {
                    $swatchImage = $this->_helperImage->isFile($_value->getMpVisualSwatch(), HelperImage::TEMPLATE_IMAGE_TYPE_SWATCH);
                    $backGroundImage = $swatchImage
                        ? 'background: url(' . $this->_helperImage->resizeImage(
                            $_value->getMpVisualSwatch(),
                            '30',
                            HelperImage::TEMPLATE_IMAGE_TYPE_SWATCH
                        ) . ') no-repeat center; background-size: initial'
                        : 'background: ' . $_value->getMpVisualSwatch()
                        . ' no-repeat center; background-size: initial;"';
                    if ($this->homemarkHelper->isHomemark()) {
                        $proOptImg = $_value->getMpVisualSwatch();
                        $staticSwatchImage = $this->getHomeMarkStaticProductOptImg($option, $_value);
                        $backGroundImage = $staticSwatchImage
                            ? 'background: url(' . $staticSwatchImage . ') no-repeat center; background-size: initial'
                            : 'background: ' . $proOptImg
                            . ' no-repeat center; background-size: initial;"';
                    }
                    $selectHtml .= '<div class="mp-img-tooltip-wrapper" title="' . $_value->getTitle() . '"
                    data-option-type-id="' . $htmlValue . '">
                    <div class="mp-swatch-option mp-swatch-option-' . $option->getId() . ' ' . $selected . '"
                        id="options_' . $option->getId() . '_' . $count . '"
                        style="' . $backGroundImage . '"
                        data-option-id="' . $option->getId() . '"
                        data-option-sku="' . $_value->getSku() . '"
                        data-option-type-id="' . $htmlValue . '"
                        value="' . $htmlValue . '"
                        data-option-title="' . $_value->getTitle() . '"
                        price="' . $price . '" ' . $specialPriceAttr . '
                        data-role="select-swatch"></div>';
                    if ($price > 0) {
                        $selectHtml .= '<span class="mp_swatch_options_label">' . $_value->getTitle() . ' +
                        ' . $this->pricingHelper->currencyByStore($price) . '
                        </span></div>';
                    } else {
                        $selectHtml .= '<span class="mp_swatch_options_label">' . $_value->getTitle() . '
                        </span></div>';
                    }
                }
            }
        }
        $selectHtml .= $isFront ? '</div><input class="admin__control-swatch mp-swatch-input product-custom-option"
                               type="text"
                               id="options_' . $option->getId() . '"
                               data-role="mp-swatches"
                               data-validate="' . $this->escapeHtml(HelperData::jsonEncode($_textValidate)) . '"
                               name="options[' . $option->getId() . ']"
                               value="' . $defaultValue . '"></div>'
            : '</div><input class="admin__control-swatch mp-swatch-input product-custom-option ' . $requiredClass . '"
                               type="text"
                               id="options_' . $option->getId() . '"
                               name="options[' . $option->getId() . ']"
                               price="' . $priceValue . '"
                               value="' . $defaultValue . '"></div>';

        return $selectHtml;
    }

    /**
     * Get product option static image for homemark
     *
     * @param $option
     * @param $_value
     * @return string|null
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @throws NoSuchEntityException
     */
    private function getHomeMarkStaticProductOptImg($option, $_value){
        $oriSwatchImage = null;
        if (!$this->homemarkHelper->isHomemark()) {
            return $oriSwatchImage;
        }
        $opTitle    = $option->getTitle();
        $valueTitle = $_value->getTitle();
        $type       = HelperImage::TEMPLATE_IMAGE_TYPE_SWATCH;
        if ($opTitle == 'Hinge' && $valueTitle == ProductOption::VALUE_LABEL_FINISHED_END_LEFT){
            $oriSwatchImage = $this->_helperImage->getImageMediaUrl('homemark/left_hinge_img.png', $type);
        } elseif ($opTitle == 'Hinge' && $valueTitle == ProductOption::VALUE_LABEL_FINISHED_END_RIGHT){
            $oriSwatchImage = $this->_helperImage->getImageMediaUrl('homemark/right_hinge_img.png', $type);
        }elseif ($opTitle == 'Hinge' && $valueTitle == ProductOption::VALUE_LABEL_FINISHED_END_BOTH){
            $oriSwatchImage = $this->_helperImage->getImageMediaUrl('homemark/both_hinge_icon.png', $type);
        }elseif ($opTitle == 'Finished End' && $valueTitle == 'Normal'){
            $oriSwatchImage = $this->_helperImage->getImageMediaUrl('homemark/finished_end_normal.png', $type);
        }elseif ($opTitle == 'Finished End' && $valueTitle == 'Beaded'){
            $oriSwatchImage = $this->_helperImage->getImageMediaUrl('homemark/finished_end_beaded.png', $type);
        }elseif ($opTitle == 'Normal Finish Side/s' && $valueTitle == ProductOption::VALUE_LABEL_FINISHED_END_LEFT){
            $oriSwatchImage = $this->_helperImage->getImageMediaUrl('homemark/left_finish_img.png', $type);
        }elseif ($opTitle == 'Normal Finish Side/s' && $valueTitle == ProductOption::VALUE_LABEL_FINISHED_END_RIGHT){
            $oriSwatchImage = $this->_helperImage->getImageMediaUrl('homemark/right_finish_img.png', $type);
        }elseif ($opTitle == 'Normal Finish Side/s' && $valueTitle == ProductOption::VALUE_LABEL_FINISHED_END_BOTH){
            $oriSwatchImage = $this->_helperImage->getImageMediaUrl('homemark/both_finish_img.png', $type);
        }elseif ($opTitle == 'Normal Finish Side/s' && $valueTitle == 'None'){
            $oriSwatchImage = $this->_helperImage->getImageMediaUrl('homemark/none_finish_img.png', $type);
        }elseif ($opTitle == 'Beaded Finish Side/s' && $valueTitle == ProductOption::VALUE_LABEL_FINISHED_END_LEFT){
            $oriSwatchImage = $this->_helperImage->getImageMediaUrl('homemark/left_finish_img.png', $type);
        }elseif ($opTitle == 'Beaded Finish Side/s' && $valueTitle == ProductOption::VALUE_LABEL_FINISHED_END_RIGHT){
            $oriSwatchImage = $this->_helperImage->getImageMediaUrl('homemark/right_finish_img.png', $type);
        }elseif ($opTitle == 'Beaded Finish Side/s' && $valueTitle == ProductOption::VALUE_LABEL_FINISHED_END_BOTH){
            $oriSwatchImage = $this->_helperImage->getImageMediaUrl('homemark/both_finish_img.png', $type);
        }elseif ($opTitle == 'Beaded Finish Side/s' && $valueTitle == 'None'){
            $oriSwatchImage = $this->_helperImage->getImageMediaUrl('homemark/none_finish_img.png', $type);
        }elseif ($opTitle == 'Finished End' && $valueTitle == ProductOption::VALUE_LABEL_FINISHED_END_LEFT){
            $oriSwatchImage = $this->_helperImage->getImageMediaUrl('homemark/left_finish_img.png', $type);
        }elseif ($opTitle == 'Finished End' && $valueTitle == ProductOption::VALUE_LABEL_FINISHED_END_RIGHT){
            $oriSwatchImage = $this->_helperImage->getImageMediaUrl('homemark/right_finish_img.png', $type);
        }elseif ($opTitle == 'Finished End' && $valueTitle == ProductOption::VALUE_LABEL_FINISHED_END_BOTH){
            $oriSwatchImage = $this->_helperImage->getImageMediaUrl('homemark/both_finish_img.png', $type);
        }elseif ($opTitle == 'Finished End' && $valueTitle == 'None'){
            $oriSwatchImage = $this->_helperImage->getImageMediaUrl('homemark/none_finish_img.png', $type);
        }
        return $oriSwatchImage;
    }
}
