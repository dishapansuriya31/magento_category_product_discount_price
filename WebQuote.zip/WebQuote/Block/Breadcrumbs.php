<?php
namespace Commercepundit\WebQuote\Block;

use Magento\Catalog\Helper\Data;
use Magento\Catalog\Model\CategoryRepository;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Registry;
use Magento\Framework\View\Element\Template\Context;
use Magento\Store\Model\Store;
use Magento\Framework\Data\Collection;
class Breadcrumbs extends \Magento\Theme\Block\Html\Breadcrumbs
{
    /**
     * Catalog data
     *
     * @var Data
     */
    protected $_catalogData = null;

    /**
     * @var Registry
     */
    protected $registry;

    /**
     * @var CategoryRepository
     */
    protected $categoryRepository;

    /**
     * @var \Magento\Catalog\Model\ResourceModel\Category\CollectionFactory
     */
    protected $_categoryCollectionFactory;

    /**
     * @param Context $context
     * @param Data $catalogData
     * @param Registry $registry
     * @param array $data
     */
    public function __construct(
        Context $context,
        Data $catalogData,
        Registry $registry,
        CategoryRepository $categoryRepository,
        \Magento\Catalog\Model\ResourceModel\Category\CollectionFactory $categoryCollectionFactory,
        array $data = []
    ) {
        $this->_catalogData = $catalogData;
        $this->registry = $registry;
        $this->categoryRepository = $categoryRepository;
        $this->_categoryCollectionFactory = $categoryCollectionFactory;
        parent::__construct($context, $data);
    }

    /**
     * Retrieve HTML title value separator (with space)
     *
     * @param null|string|bool|int|Store $store
     * @return string
     */
    public function getTitleSeparator($store = null)
    {
        $separator = (string)$this->_scopeConfig
                    ->getValue('catalog/seo/title_separator', \Magento\Store\Model\ScopeInterface::SCOPE_STORE, $store);
        return ' ' . $separator . ' ';
    }

    /**
     * Retrieve Crumbs
     *
     * @return string
     */
    public function getCrumbs()
    {
        return $this->_crumbs;
    }

    /**
     * Preparing layout
     *
     * @return \Magento\Catalog\Block\Breadcrumbs
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     */
    protected function _prepareLayout()
    {
        $title = [];
        if ($breadcrumbsBlock = $this->getLayout()->getBlock('breadcrumbs')) {
            $breadcrumbsBlock->addCrumb(
                'home',
                [
                'label' => __('Home'),
                'title' => __('Go to Home Page'),
                'link' => $this->_storeManager->getStore()->getBaseUrl()
                    ]
            );
            $path = $this->_catalogData->getBreadcrumbPath();
            $product = $this->registry->registry('current_product');
            if ($product && count($path) == 1) {
                $categoryCollection = clone $product->getCategoryCollection();
                $categoryCollection->clear();
                $categoryCollection->addAttributeToSort('level', $categoryCollection::SORT_ORDER_DESC)
                    //->addAttributeToFilter('is_used_in_breadcrumb', true)
                    ->addAttributeToFilter('path', ['like' => "1/" .
                $this->_storeManager->getStore()->getRootCategoryId() . "/%"]);
                $categoryCollection->setPageSize(1);
                $productCategory = $categoryCollection->getFirstItem();
                $breadcrumbCategories = $this->getParentCategories($productCategory);
                foreach ($breadcrumbCategories as $category) {
                    //if (!in_array($category->getId(), $product->getCategoryIds())) {
                            $catbreadcrumb = ["label" => $category->getName(), "link" => $category->getUrl()];
                            $breadcrumbsBlock->addCrumb("category" . $category->getId(), $catbreadcrumb);
                            $title[] = $category->getName();
                    //}
                }
                //add current product to breadcrumb
                $prodbreadcrumb = ["label" => $product->getName(), "link" => ""];
                $breadcrumbsBlock->addCrumb("product-name-bread", $prodbreadcrumb);
                $title[] = $product->getName();
            } else {
                foreach ($path as $name => $breadcrumb) {
                    $categoryData = explode("category", $name);
                    if (count($categoryData) == 2) {
                        $categoryId = $categoryData[1];
                        if ($categoryId) {
                            try {
                                $isUsedInBreadCrumb = (bool)$this->categoryRepository->get($categoryId)
                                        ->getIsUsedInBreadcrumb() ?? true;
                            } catch (NoSuchEntityException $e) {
                                $this->_logger->critical($e);
                            }
                        }
                        if ($isUsedInBreadCrumb) {
                            $breadcrumbsBlock->addCrumb($name, $breadcrumb);
                            $title[] = $breadcrumb['label'];
                        }
                    }
                }

                //add current product to breadcrumb
                /*if ($product) {
                    $prodbreadcrumb = ["label" => $product->getName(), "link" => ""];
                    $breadcrumbsBlock->addCrumb("product-name-bread", $prodbreadcrumb);
                    $title[] = $product->getName();
                }*/
            }
            //$this->pageConfig->getTitle()->set(join($this->getTitleSeparator(), array_reverse($title)));
            return parent::_prepareLayout();
        }
        $path = $this->_catalogData->getBreadcrumbPath();
        foreach ($path as $name => $breadcrumb) {
            $title[] = $breadcrumb['label'];
        }
        //$this->pageConfig->getTitle()->set(join($this->getTitleSeparator(), array_reverse($title)));
        return parent::_prepareLayout();
    }

    /**
     * Return parent categories of category
     *
     * @param \Magento\Catalog\Model\Category $category
     * @return \Magento\Framework\DataObject[]
     */
    public function getParentCategories($category)
    {
        $pathIds = array_reverse(explode(',', (string)$category->getPathInStore()));
        /** @var \Magento\Catalog\Model\ResourceModel\Category\Collection $categories */
        $categories = $this->_categoryCollectionFactory->create();
        return $categories->setStore(
            $this->_storeManager->getStore()
        )->addAttributeToSelect(
            'name'
        )->addAttributeToSelect(
            'url_key'
        )->addFieldToFilter(
            'entity_id',
            ['in' => $pathIds]
        )->addFieldToFilter(
            'is_active',
            1
        )->addFieldToFilter(
            'is_used_in_breadcrumb',
             array('neq' => 0)
        )->addAttributeToSort('level', Collection::SORT_ORDER_ASC)
        ->load()->getItems();
    }
}
