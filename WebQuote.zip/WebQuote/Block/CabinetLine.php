<?php
/**
 * Commercepundit
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Commercepundit.com license that is
 * available through the world-wide-web at this URL:
 * http://commercepundit.com/license
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category   Commercepundit
 * @package    Commercepundit_WebQuote
 * @copyright  Copyright (c) Commercepundit (http://www.commercepundit.com/)
 * @license    http://www.commercepundit.com/LICENSE-1.0.html
 */
namespace Commercepundit\WebQuote\Block;

use Commercepundit\Cabinets\Model\Door\Source\Status;
use Commercepundit\General\Model\Config\Source\Boolean;
use Commercepundit\WebQuote\Api\GetstylebycabinetidManagementInterface;
use Magento\Framework\UrlInterface;

class CabinetLine extends \Magento\Framework\View\Element\Template
{
    /**
     * @var \Magento\Framework\App\ResourceConnection
     */
    protected $resourceConnection;

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $storeManager;

    /**
     * @var \Magento\Framework\Json\EncoderInterface
     */
    protected $jsonEncoder;

    /**
     * @var \Commercepundit\Cabinets\Helper\Data
     */
    protected $cabinetHelper;

    /**
     * @var GetstylebycabinetidManagementInterface
     */
    protected $webQuoteStyle;


    /**
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param \Magento\Framework\App\ResourceConnection        $resourceConnection
     * @param \Magento\Store\Model\StoreManagerInterface       $storeManager
     * @param \Magento\Framework\Json\EncoderInterface         $jsonEncoder
     * @param \Commercepundit\Cabinets\Helper\Data             $cabinetHelper
     * @param GetstylebycabinetidManagementInterface           $webQuoteStyle
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Framework\App\ResourceConnection $resourceConnection,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\Json\EncoderInterface $jsonEncoder,
        \Commercepundit\Cabinets\Helper\Data $cabinetHelper,
        GetstylebycabinetidManagementInterface $webQuoteStyle
    ) {
        $this->resourceConnection = $resourceConnection;
        $this->storeManager = $storeManager;
        $this->jsonEncoder = $jsonEncoder;
        $this->cabinetHelper = $cabinetHelper;
        $this->webQuoteStyle = $webQuoteStyle;
        parent::__construct($context);
    }

    /**
     * Get Media Url
     *
     * @return string
     */
    public function getMediaUrl()
    {
        return $this->storeManager->getStore()
            ->getBaseUrl(UrlInterface::URL_TYPE_MEDIA);
    }

    /**
     * Get Door Listing Color Data
     *
     * @return array
     */
    public function getCabinetLineCollection()
    {
        $connection = $this->resourceConnection->getConnection();
        $select = $connection->select()
            ->distinct(true)
            ->from(['CCL' => $connection->getTableName('cp_cabinet_line')])
            ->join(
                ['CS' => $connection->getTableName('cp_style')],
                'CCL.cabinet_line_id = CS.cabinet_line_id',
                ['']
            );

        //Exclude CabinetLine collection query for restriction
        $select = $this->cabinetHelper->isRestrictCabinetLine($select, $connection);

        $select->where('CCL.status = ?', Boolean::YES);
        $collection = $connection->fetchAll($select);
        $cabinetLineData      = [];
        if (count($collection)) {
            foreach ($collection as $cabinetLine) {
                $parentCabinetLine = $cabinetLine['parent_cabinet_line_id']??$cabinetLine['cabinet_line_id'];
                if ($parentCabinetLine && !array_key_exists($parentCabinetLine, $cabinetLineData)
                ) {
                    $cabinetLineData[$parentCabinetLine]= $this->getParentCabinetLineRow($parentCabinetLine);
                }
            }
        }
        return array_filter($cabinetLineData);
    }

    /**
     * Get parent cabinetline Data
     *
     * @param int $cabinetLineId
     * @return array
     */
    public function getParentCabinetLineRow($cabinetLineId = null)
    {
        $connection = $this->resourceConnection->getConnection();
        $select = $connection->select()
            ->from(['CS' => $connection->getTableName('cp_cabinet_line')])
            ->where('CS.status =  ? ', Status::STATUS_ENABLE)
            ->where('CS.cabinet_line_id = ? ', $cabinetLineId);
        return $connection->fetchRow($select);
    }

    /**
     * Get first item
     *
     * @return \Magento\Framework\DataObject
     */
    public function getCabinetFirstItem()
    {
        $data = $this->getCabinetLineCollection();
        return reset($data);
    }

    /**
     * Json Encode data
     *
     * @param  array|string $data
     * @return string
     */
    public function jsonEncode($data)
    {
        return $this->jsonEncoder->encode($data);
    }

    /**
     * Get Style Listing Color Data
     *
     * @return array
     */
    public function getWebQuoteStyle()
    {
        return $this->webQuoteStyle->stylebycabinetid();
    }
}
