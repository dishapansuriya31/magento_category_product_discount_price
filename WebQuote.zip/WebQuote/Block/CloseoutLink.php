<?php
/*
 *  Commercepundit
 *
 *  NOTICE OF LICENSE
 *
 * This source file is subject to the Commercepundit.com license that is
 * available through the world-wide-web at this URL:
 * http://commercepundit.com/license
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category   Commercepundit
 * @package    Commercepundit_Customer
 * @copyright  Copyright (c) Commercepundit (http://www.commercepundit.com/)
 * @license    http://www.commercepundit.com/LICENSE-1.0.html
 *
 */

namespace Commercepundit\WebQuote\Block;

use Commercepundit\Ordersample\Helper\Data as SampleHelper;
use Magento\Framework\View\Element\Template;

/**
 * class CloseOutLink
 *
 * Hide close out link for the COW states.
 */
class CloseoutLink extends Template
{
    /**
     * Current template name
     *
     * @var string
     */
    protected $_template = 'Commercepundit_WebQuote::html/closeoutLink.phtml';

    /**
     * @var string[]
     */
    private $cow_state = [
        'washington',
        'california',
        'oregon'
    ];

    /**
     * @var SampleHelper
     */
    protected $_helper;

    /**
     * @param Template\Context $context
     * @param SampleHelper $sampleHelper
     * @param array $data
     */
    public function __construct(
        Template\Context $context,
        SampleHelper     $sampleHelper,
        array            $data = []
    ) {
        parent::__construct($context, $data);
        $this->_helper = $sampleHelper;
    }

    /**
     * Check COW states.
     *
     * @return bool
     */
    public function isCOWState(): bool
    {
        if (!empty($location) && isset($location['region_name']) &&
            !empty($location['region_name'])) {
            return in_array(trim(strtolower($location['region_name'])), $this->cow_state);
        }
        return false;
    }
}
