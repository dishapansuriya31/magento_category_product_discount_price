<?php
/**
 * Commercepundit
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Commercepundit.com license that is
 * available through the world-wide-web at this URL:
 * http://commercepundit.com/license
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category   Commercepundit
 * @package    Commercepundit_WebQuote
 * @copyright  Copyright (c) Commercepundit (http://www.commercepundit.com/)
 * @license    http://www.commercepundit.com/LICENSE-1.0.html
 */
namespace Commercepundit\WebQuote\Block;

use Commercepundit\General\Model\Config\Source\Boolean;
use Commercepundit\Product\Model\Option;
use Magento\Framework\UrlInterface;

/**
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 * @SuppressWarnings(PHPMD.ExcessiveParameterList)
 */
class Index extends \Magento\Framework\View\Element\Template
{
    /**
     * @var \Magento\Catalog\Model\ResourceModel\Category\CollectionFactory
     */
    protected $_categoryCollectionFactory;

    /**
     * @var \Magento\Catalog\Helper\Category
     */
    protected $categoryHelper;

    /**
     * @var \Magento\Catalog\Model\CategoryFactory
     */
    protected $categoryFactory;

    /**
     * @var \Commercepundit\Product\Model\Option
     */
    protected $optionModel;

    /**
     * @var \Magento\Framework\Data\Form\FormKey
     */
    protected $formKey;

    /**
     * @var \Magento\Framework\App\ResourceConnection
     */
    protected $resourceConnection;

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $storeManager;

    /**
     * @var \Magento\Catalog\Helper\Image
     */
    protected $catalogImageHelper;

    /**
     * @var \Magento\Catalog\Model\Category
     */
    protected $categoryView;

    /**
     * @var \Magento\Catalog\Model\CategoryRepository
     */
    protected $categoryRepository;

    /**
     * @var null
     */
    protected $cabinetLineImage = null;

    /**
     * @var \Magento\Cms\Model\Template\FilterProvider
     */
    protected $_filterProvider;

    /**
     * @var \Commercepundit\General\Helper\Price
     */
    protected $wquPriceHelper;

    /**
     * @var \Commercepundit\Product\Helper\Price
     */
    protected $cpProductPriceHelper;

    /**
     * @var \Magento\Framework\Pricing\Helper\Data
     */
    protected $priceHelper;

    /**
     * @param \Magento\Framework\View\Element\Template\Context                $context
     * @param \Magento\Catalog\Helper\Category                                $categoryHelper
     * @param \Magento\Catalog\Model\ResourceModel\Category\CollectionFactory $categoryCollectionFactory
     * @param \Magento\Catalog\Model\CategoryFactory                          $categoryFactory
     * @param Option                                                          $optionModel
     * @param \Magento\Framework\Data\Form\FormKey                            $formKey
     * @param \Magento\Framework\App\ResourceConnection                       $resourceConnection
     * @param \Magento\Store\Model\StoreManagerInterface                      $storeManager
     * @param \Magento\Catalog\Helper\Image                                   $catalogImageHelper
     * @param \Magento\Catalog\Model\CategoryRepository                       $categoryRepository
     * @param \Magento\Catalog\Model\Category                                 $categoryView
     * @param \Magento\Cms\Model\Template\FilterProvider                      $filterProvider
     * @param \Commercepundit\Product\Helper\Price                            $cpProductPriceHelper
     * @param \Magento\Framework\Pricing\Helper\Data                          $priceHelper
     * @param \Commercepundit\General\Helper\Price                            $wquPriceHelper
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Catalog\Helper\Category $categoryHelper,
        \Magento\Catalog\Model\ResourceModel\Category\CollectionFactory $categoryCollectionFactory,
        \Magento\Catalog\Model\CategoryFactory $categoryFactory,
        Option $optionModel,
        \Magento\Framework\Data\Form\FormKey $formKey,
        \Magento\Framework\App\ResourceConnection $resourceConnection,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Catalog\Helper\Image $catalogImageHelper,
        \Magento\Catalog\Model\CategoryRepository $categoryRepository,
        \Magento\Catalog\Model\Category $categoryView,
        \Magento\Cms\Model\Template\FilterProvider $filterProvider,
        \Commercepundit\Product\Helper\Price $cpProductPriceHelper,
        \Magento\Framework\Pricing\Helper\Data $priceHelper,
        \Commercepundit\General\Helper\Price $wquPriceHelper
    ) {
        $this->categoryHelper = $categoryHelper;
        $this->_categoryCollectionFactory = $categoryCollectionFactory;
        $this->categoryFactory = $categoryFactory;
        $this->optionModel = $optionModel;
        $this->formKey = $formKey;
        $this->resourceConnection = $resourceConnection;
        $this->storeManager = $storeManager;
        $this->catalogImageHelper = $catalogImageHelper;
        $this->categoryRepository = $categoryRepository;
        $this->categoryView = $categoryView;
        $this->_filterProvider = $filterProvider;
        $this->cpProductPriceHelper = $cpProductPriceHelper;
        $this->priceHelper  = $priceHelper;
        $this->wquPriceHelper = $wquPriceHelper;
        parent::__construct($context);
    }

    /**
     * Get Category Collection
     *
     * @param bool $isActive
     * @param bool|int $level
     * @param bool|string $sortBy
     * @param bool|int $pageSize
     * @param int $attributeid
     * @return array|object
     */
    public function getCategoryCollection($isActive, $level, $sortBy, $pageSize, $attributeid)
    {
        $collection = $this->_categoryCollectionFactory->create();
        $collection->addAttributeToSelect('*');

        // select only active categories
        if ($isActive) {
            $collection->addIsActiveFilter();
        }

        // sort categories by some value
        if ($sortBy) {
            $collection->addOrderField($sortBy);
        }

        // select certain number of categories
        if ($pageSize) {
            $collection->setPageSize($pageSize);
        }

        $collection->addAttributeToFilter('level', $level);

        $attribute_id = explode(",", $attributeid);

        $cabinetline0 = $cabinetline1 = null;
        if (isset($attribute_id[0])) {
            $cabinetline0 = $attribute_id[0];
        }
        if (isset($attribute_id[1])) {
            $cabinetline1 = $attribute_id[1];
        }

        $collection->addAttributeToFilter([
            [
                'attribute' => 'cabinetline',
                'eq' => $cabinetline0],
            [
                'attribute' => 'cabinetline',
                'eq' => $cabinetline1]
        ]);

        return $collection;
    }

    /**
     * Retrieve current store categories
     *
     * @param bool|string $sorted
     * @param bool $asCollection
     * @param bool $toLoad
     * @return \Magento\Framework\Data\Tree\Node\Collection or
     * \Magento\Catalog\Model\ResourceModel\Category\Collection or array
     */
    public function getStoreCategories($sorted = false, $asCollection = false, $toLoad = true)
    {
        return $this->categoryHelper->getStoreCategories($sorted = false, $asCollection = false, $toLoad = true);
    }

    /**
     * Get Child Categories By Id
     *
     * @param  object $categoryId
     * @return array|object
     */
    public function getChildCategoriesById($categoryId)
    {
        $category = [];
        $categoryies = $this->categoryRepository->get($categoryId);
        $category['parentcategoryname'] = $categoryies->getName();
        $category['childcategorydata'] = $categoryies->getChildrenCategories();
        return $category;
    }

    /**
     * Get Media Url
     *
     * @return string
     */
    public function getMediaUrl()
    {
        return $this->storeManager->getStore()
            ->getBaseUrl(UrlInterface::URL_TYPE_MEDIA);
    }

    /**
     * Get Base Url
     *
     * @return string
     */
    public function getBaseUrl()
    {
        return $this->storeManager->getStore()
            ->getBaseUrl();
    }

    /**
     * Retrieve Session Form Key
     *
     * @return string
     */
    public function getFormKey()
    {
        return $this->formKey->getFormKey();
    }

    /**
     * Get Child Categories
     *
     * @param  object $category
     * @return array|object
     */
    public function getChildCategories($category)
    {
        if ($category->getUseFlatResource()) {
            return (array)$category->getChildrenNodes();
        }
        return $category->getChildren();
    }

    /**
     * Get Category And Products
     *
     * @param  int $categoryId
     * @return array
     * phpcs:disable Generic.Metrics.NestingLevel
     */
    public function getCategoryAndProducts($categoryId)
    {
        $category = $this->categoryFactory->create()->load($categoryId);
        $finalData = [];
        if ($category && $category->getId()) {
            $childCategories = $category->getChildrenCategories();
            $childCategories->addAttributeToSelect(
                'description'
            )->addAttributeToSelect(
                'image'
            );
            if ($childCategories) {
                foreach ($childCategories as $childCategory) {
                    $productCollection = $childCategory->getProductCollection();
                    $productCollection->addAttributeToSelect('*');
                    if ($productCollection->getSize()) {
                        $finalData[$childCategory->getId()] = $childCategory->getData();
                        if ($childCategory->getImage()) {
                            $imageUrl = $childCategory->getImageUrl();
                            if (substr($childCategory->getImage(), 0, 4) === '/pub') {
                                $imageUrl = $this->getBaseUrl() . ltrim($childCategory->getImage(), '/');
                            }
                        } else {
                            $imageUrl = $this->catalogImageHelper->getDefaultPlaceholderUrl('image');
                        }
                        $finalData[$childCategory->getId()]['parentcategory_name'] = $category->getName();
                        $finalData[$childCategory->getId()]['image_url'] = $imageUrl;
                        $finalData[$childCategory->getId()]['finishOptions']['measurement'] = [
                            'label' => 'Measurement',
                            'options' => []
                        ];
                        $finalData[$childCategory->getId()]['finishOptions']['hinge'] = [
                            'label' => 'Hinge',
                            'options' => []
                        ];
                        $finalData[$childCategory->getId()]['measurementLabel'] = [];
                        $finalData[$childCategory->getId()]['defaultMeasurementLabel'] = 'N/A';
                        $this->setProductData($childCategory, $productCollection, $finalData);
                    }
                }
            }
        }

        return $finalData;
    }

    /**
     * Set Product Data
     *
     * @param object $childCategory
     * @param object $productCollection
     * @param array &$finalData
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @SuppressWarnings(PHPMD.NPathComplexity)
     * phpcs:disable Generic.Files.LineLength
     */
    protected function setProductData($childCategory, $productCollection, &$finalData)
    {
        $styleId   = $this->getRequest()->getParam('style_id', 0);
        $colorId   = $this->getRequest()->getParam('color_id', 0);
        $priceId   = $this->getRequest()->getParam('price_id', 0);
        $cabinetLineId   = $this->getRequest()->getParam('style_color_cabinetline_id', 0);
        if ($productCollection->getSize()) {
            $measurementLabel = [];
            $all_child_options_code = [];
            foreach ($productCollection as $product) {
                $product->setStyleId($styleId);
                $product->setColorId($colorId);
                $product->setPriceId($priceId);
                $product->setCabinetLineId($cabinetLineId);
                $finalData[$childCategory->getId()]['products'][$product->getId()] = $product->getData();
                if (trim((string)$product->getMeasurement())) {
                    $finalData[$childCategory->getId()]['finishOptions']['measurement']
                    ['options'][$product->getMeasurement()] = $product->getMeasurement();
                    $measurementLabel[$product->getMeasurement()] = $product->getMeasurementLabel();
                }
                if (trim((string)$product->getHinge())) {
                    $finalData[$childCategory->getId()]['finishOptions']['hinge']
                    ['options'][$product->getHinge()] = ucfirst($product->getHinge());
                }

                $productPrice = $this->cpProductPriceHelper->getProductPrice(
                    $product->getSku(),
                    $product->getPriceId()
                );

                $productCustomPrice = $this->cpProductPriceHelper->applyPriceLogic(
                    $productPrice,
                    $product->getCabinetLineId()
                );

                $finalData[$childCategory->getId()]['finishOptions']['option_price'][$product->getMeasurement()] = [
                    'base_price'         => $productCustomPrice
                ];

                $this->setProductOptions(
                    $product,
                    $finalData[$childCategory->getId()]['finishOptions'],
                    $all_child_options_code
                );

                if (isset($finalData[$childCategory->getId()]['finishOptions']['option_price'][$product->getMeasurement()]['base_price'])
                    && isset($all_child_options_code['all_child_options_code'])
                ) {
                    $productPrice = $finalData[$childCategory->getId()]['finishOptions']['option_price'][$product->getMeasurement()]['base_price'];

                    $child_options_code = array_unique($all_child_options_code['all_child_options_code']);

                    foreach ($child_options_code as $value) {
                        $optionPrice = $this->cpProductPriceHelper->getOptionValuePrice(
                            $value,
                            $product->getPriceId(),
                            $productPrice
                        );
                        $optionPriceByCabinet = $this->cpProductPriceHelper->applyPriceLogic(
                            $optionPrice,
                            $product->getCabinetLineId()
                        );
                        $finalData[$childCategory->getId()]['finishOptions'][$value] = $optionPriceByCabinet;
                    }
                }
            }
            if (isset($finalData[$childCategory->getId()]['finishOptions']['measurement']['options'])
                && empty($finalData[$childCategory->getId()]['finishOptions']['measurement']['options'])
            ) {
                unset($finalData[$childCategory->getId()]);
                return $this;
            }
            if (!isset($finalData[$childCategory->getId()]['finishOptions'][Option::OPTION_CODE_FINISHED_END])) {
                $finalData[$childCategory->getId()]['finishOptions'][Option::OPTION_CODE_FINISHED_END] = [
                    'label' => Option::OPTION_LABEL_FINISHED_END,
                    'options' => []
                ];
            }
            if (isset($finalData[$childCategory->getId()]['finishOptions'][Option::OPTION_CODE_FINISHED_END]['options'])
                && !empty($finalData[$childCategory->getId()]['finishOptions'][Option::OPTION_CODE_FINISHED_END]['options'])
            ) {
                $finalData[$childCategory->getId()]['finishOptions'][Option::OPTION_CODE_FINISHED_END]['options'][Option::VALUE_CODE_FINISHED_END_BOTH] = Option::VALUE_LABEL_FINISHED_END_BOTH;
            }
            $finalData[$childCategory->getId()]['measurementLabel'] = $measurementLabel;
            $finalData[$childCategory->getId()]['defaultMeasurementLabel'] = $measurementLabel[reset(
                $finalData[$childCategory->getId()]['finishOptions']['measurement']['options']
            )] ?? 'N/A';
        }
        return $this;
    }

    /**
     * Get Category Id
     *
     * @return int
     */
    public function getCategoryId()
    {
        return $this->getRequest()->getParam('category_id', 0);
    }

    /**
     * Get Level
     *
     * @return int
     */
    public function getlevel()
    {
        return $this->getRequest()->getParam('level', 0);
    }
    /**
     * Get Category Attr Id
     *
     * @return int
     */
    public function getCategoryAttrId()
    {
        return $this->getRequest()->getParam('category_attr_id', 0);
    }

    /**
     * Set Product Options
     *
     * @param string $product
     * @param array &$finaldata
     * @param array &$all_child_options_code
     */
    public function setProductOptions($product, &$finaldata, &$all_child_options_code)
    {
        $productOptions = $this->getProductOptions();
        foreach ($productOptions as $product_Options) {
            $options = $this->optionModel->getOptionAndValues($product->getSku(), $product_Options['option_code']);
            if (!empty($options)) {
                foreach ($options as $option) {
                    $finaldata[$option['option_code']]['label'] = $option['option_label'] ?? $option['default_label'];
                    if (!empty($option['values'])) {
                        $finaldata[$option['option_code']]['options'][''] = 'None';
                        foreach ($option['values'] as $value) {
                            $finaldata[$option['option_code']]['options'][$value['value_code']] = $value['default_label'];
                            $all_child_options_code['all_child_options_code'][] = $value['value_code'];
                        }
                    }
                }
            }
        }
        return $this;
    }

    /**
     * Get Product Options
     *
     * @return array
     */
    public function getProductOptions()
    {
        $connection = $this->resourceConnection->getConnection();
        $select = $connection->select()
            ->from(['CO' => $connection->getTableName('cp_option')], ['option_code'])
            ->where('CO.status = ?', Boolean::YES)
            ->where('CO.is_display_modification = ?', Boolean::YES)
            ->where('CO.is_display_in_front = ?', Boolean::YES);
        return $connection->fetchAll($select);
    }

    /**
     * Get Cabinet Lines
     *
     * @return array
     */
    public function getCabinetLines()
    {
        $connection = $this->resourceConnection->getConnection();
        $select = $connection->select()
            ->from(['CCL' => $connection->getTableName('cp_cabinet_line')])
            ->where('CCL.status = ?', Boolean::YES);
        $cabinetLines = $connection->fetchAll($select);
        if (!empty($cabinetLines)) {
            $mediaUrl = $this->getMediaUrl();
            foreach ($cabinetLines as &$cabinetLine) {
                $image = null;
                if (isset($cabinetLine['image']) && trim($cabinetLine['image'])) {
                    $image = $mediaUrl . $cabinetLine['image'];
                }
                $cabinetLine['image'] = $image;
            }
            $this->cabinetLineImage = reset($cabinetLines)['image'];
        }
        return $cabinetLines;
    }

    /**
     * Get Cabinet Line Image
     *
     * @return string|null
     */
    public function getCabinetLineImage()
    {
        return $this->cabinetLineImage;
    }

    /**
     * Get Category View
     *
     * @return string|null
     */
    public function getCategoryView()
    {
        return $this->categoryView;
    }

    /**
     * Get Content From Static Block
     *
     * @param string $content
     * @return html
     */
    public function getContentFromStaticBlock($content)
    {
        $storeId = $this->storeManager->getStore()->getId();
        return $this->_filterProvider->getBlockFilter()->setStoreId($storeId)->filter($content);
    }

    /**
     * Get cp custom product price with format
     *
     * @param  int $productPrice
     * @return float
     */
    public function getFormatedPrice($productPrice)
    {
        return $this->priceHelper->currency($productPrice, true, false);
    }
}
