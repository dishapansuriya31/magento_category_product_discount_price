<?php

/**
 * Commercepundit
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Commercepundit.com license that is
 * available through the world-wide-web at this URL:
 * http://commercepundit.com/license
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category   Commercepundit
 * @package    Commercepundit_WebQuote
 * @copyright  Copyright (c)Commercepundit (http://www.commercepundit.com/)
 * @license    http://www.commercepundit.com/LICENSE-1.0.html
 */

namespace Commercepundit\WebQuote\Model;

use Commercepundit\WebQuote\Block\Category\ListCabinets;
use Commercepundit\WebQuote\Observer\AddCabinetsLayoutUpdateHandleObserver;
use Magento\Catalog\Model\ResourceModel\Category\StateDependentCollectionFactory;
use Magento\Framework\Data\Collection;
use Magento\Framework\UrlInterface;
use Commercepundit\WebQuote\Helper\Data as WebQuoteHelper;
use Magento\Store\Model\StoreManagerInterface;
use Commercepundit\Cabinets\Model\Color\Source\Status as ColorStatus;
use Magento\Framework\Pricing\Helper\Data as PriceHelper;
use Magento\Cms\Block\Block as CmsBlock;
use Magento\Framework\View\LayoutInterface;
use Commercepundit\General\Helper\CommonCache;
use Magento\Customer\Model\SessionFactory as CustomerSession;
use Commercepundit\General\Model\Config\Source\Boolean;
use Magento\Framework\App\ResourceConnection;
use Commercepundit\Cabinets\Model\Style\Source\Construction;
use Commercepundit\Checkout\Helper\Data as CheckoutHelper;

/**
 * AddPromotionalProduct observer
 *
 * @SuppressWarnings(PHPMD.CyclomaticComplexity)
 * @SuppressWarnings(PHPMD.NPathComplexity)
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
 * @SuppressWarnings(PHPMD.ExcessiveClassComplexity)
 */
class CustomCabinetsCategory implements \Commercepundit\WebQuote\Api\CustomCabinetsCategoryInterface
{
    public const FILTER_PARAM = [
        'door_id' => 'cpd.',
        'color_category_id' => 'cpcc.',
        'cabinet_line_id' => 'cpl.',
        'type_id' => 'cwt.',
        'construction' => 'cps.',
    ];

    public const CABINET_ID = 'cabinetline';

    public const CUSTOMCABINETSECTION = 'customcabinets_section';

    public const FILTER_STYLE = 'door_id';
    public const FILTER_CABINET_LINE = 'cabinet_line_id';
    public const FILTER_WOOD_SPECIES = 'type_id';
    public const FILTER_FINISH = 'color_category_id';
    public const FILTER_CONSTRUCTION = 'construction';
    public const FILTER_STYLE_LABEL = 'Style';
    public const FILTER_CABINET_LINE_LABEL = 'Line';
    public const FILTER_WOOD_SPECIES_LABEL = 'Wood Species';
    public const FILTER_FINISH_LABEL = 'Finish';
    public const FILTER_CONSTRUCTION_LABEL = 'Construction';

    /**
     * @var StateDependentCollectionFactory
     */
    protected $collectionFactory;

    /**
     * @var StoreManagerInterface
     */
    protected $storeManager;

    /**
     * @var WebQuoteHelper
     */
    protected $_webQuoteHelper;

    /**
     * @var PriceHelper
     */
    protected $_priceHelper;

    /**
     * @var LayoutInterface
     */
    protected $_layout;

    /**
     * @var CommonCache
     */
    protected $commonCacheHelper;

    /**
     * @var CustomerSession
     */
    protected $customerSession;

    /**
     * @var ResourceConnection
     */
    protected $resourceConnection;

    /**
     * @var Construction
     */
    protected $constructionOptions;

    /**
     * @var array
     */
    protected $filterOptions = [];

    /**
     * @var array
     */
    protected $allFilterOptions = [];

    /**
     * @param StateDependentCollectionFactory $collectionFactory
     * @param StoreManagerInterface           $storeManager
     * @param WebQuoteHelper                  $webQuoteHelper
     * @param PriceHelper                     $priceHelper
     * @param LayoutInterface                 $layout
     * @param CommonCache                     $commonCacheHelper
     * @param CustomerSession                 $customerSession
     * @param ResourceConnection              $resourceConnection
     * @param Construction                    $constructionOptions
     */
    public function __construct(
        StateDependentCollectionFactory $collectionFactory,
        StoreManagerInterface           $storeManager,
        WebQuoteHelper                  $webQuoteHelper,
        PriceHelper                     $priceHelper,
        LayoutInterface                 $layout,
        CommonCache                     $commonCacheHelper,
        CustomerSession                 $customerSession,
        ResourceConnection              $resourceConnection,
        Construction                    $constructionOptions
    )
    {
        $this->collectionFactory = $collectionFactory;
        $this->storeManager      = $storeManager;
        $this->_webQuoteHelper   = $webQuoteHelper;
        $this->_priceHelper      = $priceHelper;
        $this->_layout           = $layout;
        $this->commonCacheHelper = $commonCacheHelper;
        $this->customerSession   = $customerSession;
        $this->resourceConnection = $resourceConnection;
        $this->constructionOptions = $constructionOptions;
    }

    /**
     * Get Media Url
     *
     * @return string
     */
    public function getMediaUrl()
    {
        return $this->storeManager->getStore()
            ->getBaseUrl(UrlInterface::URL_TYPE_MEDIA);
    }

    /**
     * Get Door Listing Color Data
     *
     * @param int $categoryId
     * @param mixed $filterRequest
     * @return array
     * @throws \Magento\Framework\Exception\LocalizedException
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Zend_Db_Select_Exception
     */
    public function getCustomcabinetscategory(int $categoryId, $filterRequest = [])
    {
        try {
            $customer = $this->customerSession->create();
            $customerGroupId = Boolean::NO;
            if($customer->isLoggedIn()){
                $customerGroupId = $customer->getCustomer()->getGroupId();
            }
            $cacheKey = 'CUSTOM_CABINET_DATA_'.$categoryId.$customerGroupId.json_encode($filterRequest);
            $categoryData = $this->commonCacheHelper->loadData($cacheKey);
            if(empty($categoryData)){
                $categoryData = [];
                $level = [ListCabinets::CATEGORY_LEVEL_4, ListCabinets::CATEGORY_LEVEL_5];
                $store = $this->storeManager->getStore();
                $storeId = $store->getStoreId();
                $mediaUrl = $this->getMediaUrl();
                $collection = $this->collectionFactory->create();
                $collection->setStoreId($storeId);
                $selectFields = [
                    'name',
                    'heading_title',
                    'image',
                    'shipping_time',
                    'color_id',
                    'style_id',
                    'cabinetline',
                    'woodspecies_id',
                    'cabinet_subspecification',
                    'yotpo_product_id',
                    'ten_by_price_sku',
                    'sale_tag',
                    'is_new',
                    'is_new_end_date'
                ];
                $collection->addAttributeToSelect($selectFields, 'left');
                $collection->addFieldToFilter('path', ['like' => '%' . $categoryId . '%']); //load only from store root
                $collection->addAttributeToFilter('include_in_menu', 1);
                $collection->addAttributeToFilter('level', ['in' => $level]);
                $collection->addAttributeToFilter(
                    'page_layout',
                    AddCabinetsLayoutUpdateHandleObserver::CUSTOM_CABINETS_LAYOUT
                );
                $collection->addIsActiveFilter();
                $collection->addOrder('level', Collection::SORT_ORDER_ASC);
                $connection = $collection->getConnection();
                $collection->getSelect()
                    ->joinLeft(
                        ['cpl' => $connection->getTableName('cp_cabinet_line')],
                        "IF(at_cabinetline.value_id > 0, at_cabinetline.value, at_cabinetline_default.value) = cpl.cabinet_line_id",
                        [
                            'cabinet_line_id',
                            'cabinet_name' => 'cpl.cabinet_name',
                            'parent_cabinet_line_id',
                            'supplierCabinetName'=> 'cpl.supplier',
                            'cabinet_shipping_time' => 'cpl.shipping_time'
                        ]
                    )->joinLeft(
                        ['cpc' => $connection->getTableName('cp_color')],
                        "IF(at_color_id.value_id > 0, at_color_id.value, at_color_id_default.value) = cpc.color_id",
                        [
                            'color_swatch_image' => new \Zend_Db_Expr("CONCAT('$mediaUrl',cpc.image)"),
                            'color_name' => 'cpc.name'
                        ]
                    )->joinLeft(
                        ['cct' => $connection->getTableName('cp_color_type')],
                        'cpc.type_id = cct.type_id',
                        ['color_type' => 'cct.name']
                    )->joinLeft(
                        ['cpcc' => $connection->getTableName('cp_color_category')],
                        'cpc.color_category_id = cpcc.color_category_id
                     AND cpcc.status = ' . ColorStatus::STATUS_ENABLE,
                        [
                            'color_category_name' => 'cpcc.name',
                            'cpcc.color_category_id'
                        ]
                    )->joinLeft(
                        ['cps' => $connection->getTableName('cp_style')],
                        "IF(at_style_id.value_id > 0, at_style_id.value, at_style_id_default.value) = cps.style_id",
                        [
                            'style_yotpo_product_id' => 'cps.yotpo_product_id',
                            'construction',
                            'style_shipping_time' => 'cps.shipping_time',
                            'style_name' => 'cps.name'
                        ]
                    )->joinLeft(
                        ['cpd' => $connection->getTableName('cp_door')],
                        'cpd.door_id = cps.door_id',
                        [
                            'door_id' => 'cpd.door_id',
                            'door_name' => 'cpd.name'
                        ]
                    )->joinLeft(
                        ['cwt' => $connection->getTableName('cp_wood_type')],
                        "IF(at_woodspecies_id.value_id > 0, at_woodspecies_id.value, at_woodspecies_id_default.value) = cwt.type_id",
                        ['wood_type_id' => 'cwt.type_id', 'wood_type_name' => 'cwt.type_name']
                    )->joinLeft(
                        ['ctbp' => $connection->getTableName('cp_ten_by_ten_price')],
                        'ctbp.entity_id = e.entity_id AND (ctbp.website_id = 0)
                        AND (
                            ctbp.all_groups = 1
                            OR ctbp.customer_group_id = ' .$customerGroupId .'
                        )',
                        [
                            'discount_price'
                        ]
                    );
                $filterApplied = false;
                $sortApplied = false;
                $categoryData['filters']['selected_filters'] = [];

                if (isset($filterRequest['filterRequest']) && !empty($filterRequest)) {
                    $this->getAllFilterOptions();
                    $filterRequestOrig = $filterRequest['filterRequestOrig']?? [];
                    foreach ($filterRequest['filterRequest'] as $column => $filterValue) {
                        if (array_key_exists($column, self::FILTER_PARAM)) {
                            $collection->getSelect()->where(
                                sprintf("%s%s IN (?)", self::FILTER_PARAM[$column], $column),
                                $filterValue
                            );
                            $filterApplied = true;
                        }
                        if (!isset($categoryData['filters']['selected_filters'][$column])) {
                            $categoryData['filters']['selected_filters'][$column] = [];
                            $categoryData['filters']['selected_filters'][$column]['label'] = '';
                            if ($column == self::FILTER_STYLE) {
                                $categoryData['filters']['selected_filters'][$column]['label'] = self::FILTER_STYLE_LABEL;
                            } elseif ($column == self::FILTER_CABINET_LINE) {
                                $categoryData['filters']['selected_filters'][$column]['label'] = self::FILTER_CABINET_LINE_LABEL;
                            } elseif ($column == self::FILTER_FINISH) {
                                $categoryData['filters']['selected_filters'][$column]['label'] = self::FILTER_FINISH_LABEL;
                            } elseif ($column == self::FILTER_WOOD_SPECIES) {
                                $categoryData['filters']['selected_filters'][$column]['label'] = self::FILTER_WOOD_SPECIES_LABEL;
                            } elseif ($column == self::FILTER_CONSTRUCTION) {
                                $categoryData['filters']['selected_filters'][$column]['label'] = self::FILTER_CONSTRUCTION_LABEL;
                            }
                            $categoryData['filters']['selected_filters'][$column]['values'] = [];
                        }
                        if ($column == self::FILTER_CABINET_LINE && isset($filterRequestOrig[$column]) && !empty($filterRequestOrig[$column])) {
                            $filterValue = $filterRequestOrig[$column];
                        }
                        $this->getSelectedFilters($categoryData,$column,$filterValue);
                    }
                }

                if (!empty($filterRequest['filterRequest']['sort_by']) && $filterRequest['filterRequest']['sort_by'] != 'position'){
                    $sortBy = ($filterRequest['filterRequest']['sort_by'] == 'name') ? 'style_name' : $filterRequest['filterRequest']['sort_by'];
                    if($sortBy == 'high_to_low') {
                        $sortApplied = true;
                        $collection->getSelect()->order(sprintf("ctbp.discount_price %s", Collection::SORT_ORDER_DESC));
                    } elseif ($sortBy == 'low_to_high') {
                        $sortApplied = true;
                        $collection->getSelect()->order(sprintf("ctbp.discount_price %s", Collection::SORT_ORDER_ASC));
                    }else{
                        $sortApplied = true;
                        $collection->getSelect()->order(sprintf("%s %s", $sortBy, Collection::SORT_ORDER_ASC));
                    }
                    $collection->getSelect()->order('cpc.sort_order '.Collection::SORT_ORDER_ASC);
                }else {
                    //$sortApplied = true;
                    $collection->getSelect()->order('is_new '. Collection::SORT_ORDER_DESC);
                    $collection->getSelect()->order('cpc.sort_order '.Collection::SORT_ORDER_ASC);
                    $collection->getSelect()->order('e.position '.Collection::SORT_ORDER_ASC);
                }

                $collection->getSelect()->group('e.entity_id');
                /*$sectionsCount = 0;
                $TotalSections = $this->showTotalSectionCount($connection);
                $eachSectionCount = 4;
                $showSection = 1;*/
                $this->allFilterOptions[self::FILTER_CONSTRUCTION] = $this->constructionOptions->getOptionsValues();
                foreach ($collection as $category) {
                    if ($category->getLevel() == ListCabinets::CATEGORY_LEVEL_4 && !$sortApplied) {
                        $yotpoProductId = $category->getStyleYotpoProductId() ?
                            $category->getStyleYotpoProductId() :
                            $category->getYotpoProductId();
                        $categoryData[$category->getId()] = [
                            'style_data' => true,
                            'name' => $category->getName(),
                            'is_cabinet_parent' => 'yes',
                            'cat_id' => $category->getId(),
                            'image_url' => null,
                            'supplierCabinetName' => $category->getData("supplierCabinetName"),
                            'cabinetline' => $category->getCabinetline() ?? null,
                            'cabinet_subspecification' => $category->getCabinetSubspecification() ?? null,
                            'yotpo_product_id' => $yotpoProductId
                        ];
                        /*$sectionsCount++;
                        $section = $sectionsCount % $eachSectionCount;
                        if($section == 0 && isset($categoryData[$category->getId()]) &&
                            !isset($categoryData[$category->getId()][self::CUSTOMCABINETSECTION])){
                            $categoryData[$category->getId()][self::CUSTOMCABINETSECTION] = $this->_layout
                                ->createBlock(CmsBlock::class)
                                ->setBlockId(self::CUSTOMCABINETSECTION.'_'.$showSection)
                                ->toHtml();
                            $showSection++;
                        }
                        if($showSection > $TotalSections){
                            $showSection = 1;
                        }*/
                    } else {
                        if (!isset($categoryData[$category->getParentId()])) {
                            if ($filterApplied || $sortApplied) {
                                $parentCategory = $category->getParentCategory();
                                $yotpoProductId = $parentCategory->getStyleYotpoProductId() ?
                                    $parentCategory->getStyleYotpoProductId() :
                                    $parentCategory->getYotpoProductId();
                                $categoryData[$parentCategory->getId()] = [
                                    'style_data' => true,
                                    'name' => $parentCategory->getName(),
                                    'is_cabinet_parent' => 'yes',
                                    'cat_id' => $parentCategory->getId(),
                                    'image_url' => null,
                                    'supplierCabinetName' => $category->getData("supplierCabinetName"),
                                    'cabinetline' => $category->getCabinetline() ?? null,
                                    'cabinet_subspecification' => $parentCategory->getCabinetSubspecification() ?? null,
                                    'yotpo_product_id' => $yotpoProductId
                                ];
                                /*$sectionsCount++;
                                $section = $sectionsCount % $eachSectionCount;
                                if($section == 0
                                    && isset($categoryData[$parentCategory->getId()])
                                    && !isset($categoryData[$parentCategory->getId()][self::CUSTOMCABINETSECTION])){

                                    $categoryData[$parentCategory->getId()][self::CUSTOMCABINETSECTION] = $this->_layout->createBlock(CmsBlock::class)
                                            ->setBlockId(self::CUSTOMCABINETSECTION.'_'.$showSection)
                                            ->toHtml();
                                    $showSection++;
                                }
                                 if($showSection > $TotalSections){
                                    $showSection = 1;
                                 }*/
                            } else {
                                continue;
                            }
                        }
                        $imageUrl = null;
                        if ($category->getImageUrl()) {
                            $imageUrl = $category->getImageUrl();
                            if (!str_contains($category->getImageUrl(), $store->getBaseUrl())) {
                                $imageUrl = $store->getBaseUrl() . $category->getImageUrl();
                            }
                        }
                        if($category->getColorType()){
                            $tenBypriceData = $this->_webQuoteHelper->getTenByPriceDiscountData($category->getId()) ?? null;
                            $discountPrice = null;
                            $regularPrice = null;
                            $savePrice = null;
                            $percentage = null;
                            $asLowAsPrice = null;
                            if (!empty($tenBypriceData)) {
                                $discountPrice = (float)$tenBypriceData['discount_price'];
                                $regularPrice = (float)$tenBypriceData['regular_price'];
                                $savePrice = (float)$tenBypriceData['save_price'];
                                $asLowAsPrice = (float)$tenBypriceData['as_low_as_price'];
                                $percentage = $tenBypriceData['percentage'];
                            }
                            if(!isset($categoryData[$category->getParentId()]['child'])){
                                $isFirst = 1;
                            }
                            if ($isFirst) {
                                $categoryData[$category->getParentId()]['image_url'] = $imageUrl;
                                $categoryData[$category->getParentId()]['url'] = $category->getUrl();
                            }
                            $categoryData[$category->getParentId()]['child'][$category->getColorType()][] = [
                                'name' => $category->getName(),
                                'heading_title' => $category->getHeadingTitle(),
                                'url' => $category->getUrl(),
                                'image_url' => $imageUrl,
                                'parent_cat_id' => $category->getParentId(),
                                'cat_id' => $category->getId(),
                                'swatch_image' => $category->getColorSwatchImage() ?? null,
                                'shipping_time' => $this->getLeadTime($category),
                                'color_type' => $category->getColorType(),
                                'discount_price' => $discountPrice,
                                'regular_price' => $regularPrice,
                                'as_low_as_price' => $asLowAsPrice,
                                'save_price' => $savePrice,
                                'percentage' => $percentage,
                                'style_id' => $category->getStyleId() ?? null,
                                'color_id' => $category->getColorId() ?? null,
                                'supplierCabinetName' => $category->getData("supplierCabinetName"),
                                'style_name' => $category->getStyleName() ?? null,
                                'wood_type_name' => $category->getWoodTypeName() ?? null,
                                'color_name' => $category->getColorName() ?? null,
                                'cabinetline' => $category->getCabinetline() ?? null,
                                'woodspecies_id' => $category->getWoodspeciesId() ?? null,
                                'construction' => $category->getConstruction() ?? null,
                                'sale_tag' => $category->getSaleTag() ?? null,
                                'is_first' => $isFirst,
                                'is_new' => $category->getIsNew() ?? 0,
                                'is_new_end_date' => $category->getIsNewEndDate() ?? NULL,
                            ];
                            if(isset($categoryData[$category->getParentId()]['child'])){
                                $isFirst = 0;
                            }
                        }
                    }
                    $this->getCabinetsStyleFilterOptions($category, $this->filterOptions);
                }
                if (isset($categoryData['filters']['selected_filters']['sort_by'])){
                    unset($categoryData['filters']['selected_filters']['sort_by']);//Remove sort by selected from filter option showing.
                }
                $this->getCabinetLineFilterOptions($this->filterOptions);
                $categoryData['filters']['filter_options'] = $this->filterOptions;
                if (!empty($categoryData)) {
                    $categoryData = $this->commonCacheHelper->cacheData(
                        $categoryData,
                        $cacheKey,
                        ['BLOCK_HTML'],
                        172800
                    );
                }
            }
            return $categoryData;
        } catch (LocalizedException $ex) {
            throw new LocalizedException(__($ex->getMessage()));
        }
    }

    /**
     * Get Selected Filters
     *
     * @param  array &$categoryData
     * @param  string $column
     * @param  string $filterValue
     */
    public function getSelectedFilters(&$categoryData,$column,$filterValue) {
        if (is_array($filterValue)) {
            foreach ($filterValue as $values) {
                if (is_array($values)) {
                    $this->getSelectedFilters($categoryData,$column,$values);
                } else {
                    $this->getSelectedFilterValues($categoryData,$column,$values);
                }
            }
        } else {
            $this->getSelectedFilterValues($categoryData,$column,$filterValue);
        }
    }

    /**
     * Get Selected Filter Values
     *
     * @param  array &$categoryData
     * @param  string $column
     * @param  string $filterValue
     */
    public function getSelectedFilterValues(&$categoryData,$column,$filterValue) {
        $val = $filterValue;
        if ($column == self::FILTER_CABINET_LINE) {
            $values = explode(",", $filterValue);
            if (!empty($values)) {
                $firstValue = reset($values);
                if (isset($this->allFilterOptions[$column][$firstValue])) {
                    $val = $this->allFilterOptions[$column][$firstValue];
                }
            }
        } else {
            if (isset($this->allFilterOptions[$column][$filterValue])) {
                $val = $this->allFilterOptions[$column][$filterValue];
            }
        }
        $categoryData['filters']['selected_filters'][$column]['values'][$filterValue] = $val;
    }

    /**
     * Get All Filter Options
     */
    public function getAllFilterOptions() {
        $connection = $this->resourceConnection->getConnection();
        if (!isset($this->allFilterOptions[self::FILTER_STYLE])) {
            $select = $connection->select()
                ->from($connection->getTableName('cp_door'),['door_id','name']);
            $this->allFilterOptions[self::FILTER_STYLE] = $connection->fetchPairs($select);
        }
        if (!isset($this->allFilterOptions[self::FILTER_CABINET_LINE])) {
            $select = $connection->select()
                ->from($connection->getTableName('cp_cabinet_line'),['cabinet_line_id','supplier']);
            $this->allFilterOptions[self::FILTER_CABINET_LINE] = $connection->fetchPairs($select);
        }
        if (!isset($this->allFilterOptions[self::FILTER_WOOD_SPECIES])) {
            $select = $connection->select()
                ->from($connection->getTableName('cp_wood_type'),['type_id','type_name']);
            $this->allFilterOptions[self::FILTER_WOOD_SPECIES] = $connection->fetchPairs($select);
        }
        if (!isset($this->allFilterOptions[self::FILTER_FINISH])) {
            $select = $connection->select()
                ->from($connection->getTableName('cp_color_category'),['color_category_id','name']);
            $this->allFilterOptions[self::FILTER_FINISH] = $connection->fetchPairs($select);
        }
        if (!isset($this->allFilterOptions[self::FILTER_CONSTRUCTION])) {
            $this->allFilterOptions[self::FILTER_CONSTRUCTION] = $this->constructionOptions->getOptionsValues();
        }
    }

    /**
     * Get Style Filter Options
     *
     * @param  [] $styleColorData
     * @param  [] $options
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @return array
     */
    public function getCabinetsStyleFilterOptions($styleColorData, &$options)
    {
        if (isset($styleColorData[self::FILTER_STYLE])
            && !empty($styleColorData[self::FILTER_STYLE])) {
            $doorId = $styleColorData[self::FILTER_STYLE];
            $options['door']['name'] = self::FILTER_STYLE;
            $options['door']['label'] = self::FILTER_STYLE_LABEL;
            $options['door']['values'][$doorId] = [
                'id' => $doorId,
                'name' => $styleColorData['door_name']
            ];
        }
        if (isset($styleColorData[self::FILTER_CABINET_LINE])
            && !empty($styleColorData[self::FILTER_CABINET_LINE])) {
            $options['cabinetline']['name'] = self::FILTER_CABINET_LINE;
            $options['cabinetline']['label'] = self::FILTER_CABINET_LINE_LABEL;
            $parentCabLineId = $styleColorData['parent_cabinet_line_id'];
            $styleCabId = $styleColorData['cabinet_line_id'];
            if ($parentCabLineId) {
                if ((!isset($options['cabinetline']['values'][$parentCabLineId]['options']) ||
                    !(
                        isset($options['cabinetline']['values'][$parentCabLineId]['options'])
                        && in_array($styleCabId, $options['cabinetline']['values'][$parentCabLineId]['options'])
                    ))
                ) {
                    $options['cabinetline']['values'][$parentCabLineId]['options'][] = $styleCabId;
                    $options['cabinetline']['values'][$parentCabLineId]['name'] = $styleColorData['supplierCabinetName'];
                }
            } else {
                if (!isset($options['cabinetline']['values'][$styleCabId]['options'])) {
                    $options['cabinetline']['values'][$styleCabId]['options'][] = $styleCabId;
                    $options['cabinetline']['values'][$styleCabId]['name'] = $styleColorData['supplierCabinetName'];
                }
            }
        }
        if (isset($styleColorData[self::FILTER_FINISH])
            && !empty($styleColorData[self::FILTER_FINISH])) {
            $colorCategoryId = $styleColorData[self::FILTER_FINISH];
            $options['finish']['name'] = self::FILTER_FINISH;
            $options['finish']['label'] = self::FILTER_FINISH_LABEL;
            $options['finish']['values'][$colorCategoryId] = [
                'id' => $colorCategoryId,
                'name' => $styleColorData['color_category_name']
            ];
        }
        if (isset($styleColorData['wood_type_id'])
            && !empty($styleColorData['wood_type_id'])) {
            $woodtypeId = $styleColorData['wood_type_id'];
            $options['woodtype']['name'] = self::FILTER_WOOD_SPECIES;
            $options['woodtype']['label'] = self::FILTER_WOOD_SPECIES_LABEL;
            $options['woodtype']['values'][$woodtypeId] = [
                'id' => $woodtypeId,
                'name' => $styleColorData['wood_type_name']
            ];
        }
        if (isset($styleColorData[self::FILTER_CONSTRUCTION])
            && !empty($styleColorData[self::FILTER_CONSTRUCTION])) {
            $construction = $styleColorData[self::FILTER_CONSTRUCTION];
            $constructionLabel = $construction;
            if (isset($this->allFilterOptions[self::FILTER_CONSTRUCTION][$construction])) {
                $constructionLabel = $this->allFilterOptions[self::FILTER_CONSTRUCTION][$construction];
            }
            $options[self::FILTER_CONSTRUCTION]['name'] = self::FILTER_CONSTRUCTION;
            $options[self::FILTER_CONSTRUCTION]['label'] = self::FILTER_CONSTRUCTION_LABEL;
            $options[self::FILTER_CONSTRUCTION]['values'][$construction] = [
                'id' => $construction,
                'name' => $constructionLabel
            ];
        }
    }

    /**
     * Get Style Filter Options
     *
     * @param  [] $styleFilterOptions
     * @return array
     */
    public function getCabinetLineFilterOptions(&$styleFilterOptions)
    {
        if (isset($styleFilterOptions['cabinetline']['values'])) {
            foreach ($styleFilterOptions['cabinetline']['values'] as $parentId => &$style) {
                $options = $style['options'];
                $options[] = $parentId;
                $name = $style['name'];
                $style = [
                    'id' => implode(",", array_unique($options)),
                    'name' => $name
                ];
            }
        }
    }

    /**
     * Get fomatted price
     *
     * @param float $price
     * @return float|string
     */
    public function getFormattedPrice(float $price)
    {
        return $this->_priceHelper->currency($price, true, false);
    }

    /**
     * Get fomatted price
     *
     * @param object $connection
     * @return int
     */
    public function showTotalSectionCount($connection)
    {
        $select = $connection->select()
            ->from($connection->getTableName('cms_block'), 'COUNT(identifier)')
            ->where("identifier like '%".self::CUSTOMCABINETSECTION ."_%'");
        return $connection->fetchOne($select);
    }

    /**
     * Get Sale Category Data
     *
     * @return array
     * @throws \Magento\Framework\Exception\LocalizedException
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Zend_Db_Select_Exception
     */
    public function getSaleCategoryData()
    {
        try {
            $customer = $this->customerSession->create();
            $customerGroupId = Boolean::NO;
            if($customer->isLoggedIn()){
                $customerGroupId = $customer->getCustomer()->getGroupId();
            }
            $cacheKey = 'SALE_CATEGORY_DATA_'.$customerGroupId;
            $categoryData = $this->commonCacheHelper->loadData($cacheKey);
            if(empty($categoryData)){
                $categoryData = [];
                $level = [ListCabinets::CATEGORY_LEVEL_4, ListCabinets::CATEGORY_LEVEL_5];
                $store = $this->storeManager->getStore();
                $mediaUrl = $this->getMediaUrl();
                $collection = $this->collectionFactory->create();
                $collection->setStoreId($store->getStoreId());
                $selectFields = [
                    'name',
                    'image',
                    'shipping_time',
                    'color_id',
                    'style_id',
                    'cabinetline',
                    'woodspecies_id',
                    'cabinet_subspecification',
                    'yotpo_product_id',
                    'ten_by_price_sku',
                    'sale_tag',
                    'is_new',
                    'is_new_end_date'
                ];
                $collection->addAttributeToSelect($selectFields, 'left');
                $collection->addAttributeToFilter('include_in_menu', 1);
                $collection->addAttributeToFilter('level', ['in' => $level]);
                $collection->addAttributeToFilter('is_sale_category', true);
                $collection->addIsActiveFilter();
                $collection->addOrder('level', Collection::SORT_ORDER_ASC);
                $connection = $collection->getConnection();
                $collection->getSelect()
                    ->joinLeft(
                        ['cpl' => $connection->getTableName('cp_cabinet_line')],
                        "IF(at_cabinetline.value_id > 0, at_cabinetline.value, at_cabinetline_default.value) = cpl.cabinet_line_id",
                        [
                            'cabinet_line_id',
                            'cabinet_name' => 'cpl.cabinet_name',
                            'parent_cabinet_line_id',
                            'supplierCabinetName'=> 'cpl.supplier',
                            'cabinet_shipping_time' => 'cpl.shipping_time'
                        ]
                    )->joinLeft(
                        ['cpc' => $connection->getTableName('cp_color')],
                        "IF(at_color_id.value_id > 0, at_color_id.value, at_color_id_default.value) = cpc.color_id",
                        [
                            'color_swatch_image' => new \Zend_Db_Expr("CONCAT('$mediaUrl',cpc.image)")
                        ]
                    )->joinLeft(
                        ['cct' => $connection->getTableName('cp_color_type')],
                        'cpc.type_id = cct.type_id',
                        ['color_type' => 'cct.name']
                    )->joinLeft(
                        ['cpcc' => $connection->getTableName('cp_color_category')],
                        'cpc.color_category_id = cpcc.color_category_id
                     AND cpcc.status = ' . ColorStatus::STATUS_ENABLE,
                        [
                            'color_category_name' => 'cpcc.name',
                            'cpcc.color_category_id'
                        ]
                    )->joinLeft(
                        ['cps' => $connection->getTableName('cp_style')],
                        "IF(at_style_id.value_id > 0, at_style_id.value, at_style_id_default.value) = cps.style_id",
                        ['style_yotpo_product_id' => 'cps.yotpo_product_id','construction','style_shipping_time' => 'cps.shipping_time']
                    )->joinLeft(
                        ['cpd' => $connection->getTableName('cp_door')],
                        'cpd.door_id = cps.door_id',
                        [
                            'door_id' => 'cpd.door_id',
                            'door_name' => 'cpd.name'
                        ]
                    )->joinLeft(
                        ['cwt' => $connection->getTableName('cp_wood_type')],
                        "IF(at_woodspecies_id.value_id > 0, at_woodspecies_id.value, at_woodspecies_id_default.value) = cwt.type_id",
                        ['wood_type_id' => 'cwt.type_id', 'wood_type_name' => 'cwt.type_name']
                    );
                $collection->getSelect()->order('is_new '. Collection::SORT_ORDER_DESC);
                $collection->getSelect()->order('cpc.sort_order '.Collection::SORT_ORDER_ASC);
                $collection->getSelect()->order('e.position '.Collection::SORT_ORDER_ASC);
                $collection->getSelect()->group('e.entity_id');
                foreach ($collection as $category) {
                    if ($category->getLevel() == ListCabinets::CATEGORY_LEVEL_4) {
                        $yotpoProductId = $category->getStyleYotpoProductId() ?
                            $category->getStyleYotpoProductId() :
                            $category->getYotpoProductId();
                        $categoryData[$category->getId()] = [
                            'style_data' => true,
                            'name' => $category->getName(),
                            'is_cabinet_parent' => 'yes',
                            'cat_id' => $category->getId(),
                            'image_url' => null,
                            'url' => $category->getUrl(),
                            'supplierCabinetName' => $category->getData("supplierCabinetName"),
                            'cabinetline' => $category->getCabinetline() ?? null,
                            'cabinet_subspecification' => $category->getCabinetSubspecification() ?? null,
                            'yotpo_product_id' => $yotpoProductId
                        ];
                    } else {
                        if (!isset($categoryData[$category->getParentId()])) {
                            $parentCategory = $category->getParentCategory();
                            $yotpoProductId = $parentCategory->getStyleYotpoProductId() ?
                                $parentCategory->getStyleYotpoProductId() :
                                $parentCategory->getYotpoProductId();
                            $categoryData[$parentCategory->getId()] = [
                                'style_data' => true,
                                'name' => $parentCategory->getName(),
                                'is_cabinet_parent' => 'yes',
                                'cat_id' => $parentCategory->getId(),
                                'image_url' => null,
                                'url' => $parentCategory->getUrl(),
                                'supplierCabinetName' => $category->getData("supplierCabinetName"),
                                'cabinetline' => $category->getCabinetline() ?? null,
                                'cabinet_subspecification' => $parentCategory->getCabinetSubspecification() ?? null,
                                'yotpo_product_id' => $yotpoProductId
                            ];
                        }
                        $imageUrl = null;
                        if ($category->getImageUrl()) {
                            $imageUrl = $category->getImageUrl();
                            if (!str_contains($category->getImageUrl(), $store->getBaseUrl())) {
                                $imageUrl = $store->getBaseUrl() . $category->getImageUrl();
                            }
                        }
                        if($category->getColorType()){
                            $tenBypriceData = $this->_webQuoteHelper->getTenByPriceDiscountData($category->getId()) ?? null;
                            $discountPrice = null;
                            $regularPrice = null;
                            $savePrice = null;
                            $asLowAsPrice = null;
                            $percentage = null;
                            $isFirst = 0;
                            if (!empty($tenBypriceData)) {
                                $discountPrice = (float)$tenBypriceData['discount_price'];
                                $regularPrice = (float)$tenBypriceData['regular_price'];
                                $savePrice = (float)$tenBypriceData['save_price'];
                                $asLowAsPrice = (float)$tenBypriceData['as_low_as_price'];
                                $percentage = $tenBypriceData['percentage'];
                            }
                            if(!isset($categoryData[$category->getParentId()]['child'])){
                                $isFirst = 1;
                            }
                            if ($isFirst) {
                                $categoryData[$category->getParentId()]['image_url'] = $imageUrl;
                                $categoryData[$category->getParentId()]['url'] = $category->getUrl();
                            }
                            $categoryData[$category->getParentId()]['child'][$category->getColorType()][] = [
                                'name' => $category->getName(),
                                'heading_title' => $category->getHeadingTitle(),
                                'url' => $category->getUrl(),
                                'image_url' => $imageUrl,
                                'parent_cat_id' => $category->getParentId(),
                                'cat_id' => $category->getId(),
                                'swatch_image' => $category->getColorSwatchImage() ?? null,
                                'shipping_time' => $this->getLeadTime($category),
                                'color_type' => $category->getColorType(),
                                'discount_price' => $discountPrice,
                                'regular_price' => $regularPrice,
                                'as_low_as_price' => $asLowAsPrice,
                                'save_price' => $savePrice,
                                'percentage' => $percentage,
                                'style_id' => $category->getStyleId() ?? null,
                                'color_id' => $category->getColorId() ?? null,
                                'supplierCabinetName' => $category->getData("supplierCabinetName"),
                                'cabinetline' => $category->getCabinetline() ?? null,
                                'woodspecies_id' => $category->getWoodspeciesId() ?? null,
                                'construction' => $category->getConstruction() ?? null,
                                'sale_tag' => $category->getSaleTag() ?? null,
                                'is_first' => $isFirst,
                                'is_new' => $category->getIsNew() ?? 0,
                                'is_new_end_date' => $category->getIsNewEndDate() ?? NULL,
                            ];
                            if(isset($categoryData[$category->getParentId()]['child'])){
                                $isFirst = 0;
                            }
                        }
                    }
                }
                if (!empty($categoryData)) {
                    $categoryData = $this->commonCacheHelper->cacheData(
                        $categoryData,
                        $cacheKey,
                        ['BLOCK_HTML'],
                        172800
                    );
                }
            }
            return $categoryData;
        } catch (LocalizedException $ex) {
            throw new LocalizedException(__($ex->getMessage()));
        }
    }

    /**
     * Get Lead Time
     *
     * @param  object $category
     * @return string
     */
    public function getLeadTime($category) {
        $shippingTime = $category->getShippingTime();
        if(empty($shippingTime) || !$shippingTime || !trim($shippingTime)) {
            $shippingTime = $category->getStyleShippingTime();
            if(empty($shippingTime) || !$shippingTime || !trim($shippingTime)) {
                $shippingTime = $category->getCabinetShippingTime();
                if(empty($shippingTime) || !$shippingTime || !trim($shippingTime)) {
                    $shippingTime = CheckoutHelper::MINIMUM_LEAD_TIME.' - '.CheckoutHelper::MAXIMUM_LEAD_TIME. ' '.CheckoutHelper::LEAD_TIME_LABEL;
                }
            }
        }
        return $shippingTime;
    }
}
