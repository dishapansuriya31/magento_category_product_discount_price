<?php

namespace Commercepundit\WebQuote\Model\Category\Attribute\Source;

class Showmode extends \Magento\Eav\Model\Entity\Attribute\Source\AbstractSource
{
    /**
     * Returns all option value for view
     *
     * @return array
     */
    public function getAllOptions()
    {
        if (!$this->_options) {
            $this->_options = [
                ['value' => 'please_select', 'label' => __('Please Select')],
                ['value' => 'grid', 'label' => __('Grid Only')],
                ['value' => 'list', 'label' => __('List Only')],
                ['value' => 'grid-list', 'label' => __('Grid (default) / List')],
                ['value' => 'list-grid', 'label' => __('List (default) / Grid')],
                //['value' => \Magento\Catalog\Helper\Product\ProductList::VIEW_MODE_GRID, 'label' => __('Grid')],
                //['value' => \Magento\Catalog\Helper\Product\ProductList::VIEW_MODE_LIST, 'label' => __('List')],
            ];
        }
        return $this->_options;
    }
}
