<?php
namespace Commercepundit\WebQuote\Model\Config\Source;

use Commercepundit\Cabinets\Model\Color\Type\Source\Status;

class Color extends \Magento\Eav\Model\Entity\Attribute\Source\AbstractSource
{
    /**
     * @var \Magento\Framework\App\ResourceConnection
     */
    protected $resourceConnection;

    /**
     * @param \Magento\Framework\App\ResourceConnection $resourceConnection
     */
    public function __construct(
        \Magento\Framework\App\ResourceConnection $resourceConnection
    ) {
        $this->resourceConnection = $resourceConnection;
    }

    /**
     * To Option Array
     *
     * @param  boolean $empty
     * @return array
     */
    public function getAllOptions()
    {
        $options = [];
        $options = [['value' => '', 'label' => __('-- Please Select --')]];
        $connection = $this->resourceConnection->getConnection();
        $select = $connection->select()
            ->from($connection->getTableName('cp_color'), ['color_id','name'])
            //->where('status = ?', Status::STATUS_ENABLE)
            ->order('name ASC');
        $colors = $connection->fetchPairs($select);
        if (count($colors)) {
            foreach ($colors as $colorId => $name) {
                $options[] = ['value' => $colorId, 'label' => __($name)];
            }
        }
        return $options;
    }
}
