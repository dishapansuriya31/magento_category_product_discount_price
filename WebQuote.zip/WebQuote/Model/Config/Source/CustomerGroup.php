<?php
/*
 * <!--
 * *
 *  * Commercepundit
 *  *
 *  * NOTICE OF LICENSE
 *  *
 *  * This source file is subject to the Commercepundit.com license that is
 *  * available through the world-wide-web at this URL:
 *  * http://commercepundit.com/license
 *  *
 *  * DISCLAIMER
 *  *
 *  * Do not edit or add to this file if you wish to upgrade this extension to newer
 *  * version in the future.
 *  *
 *  * @category   Commercepundit
 *  * @package    Commercepundit_Customer
 *  * @copyright  Copyright (c) Commercepundit (http://www.commercepundit.com/)
 *  * @license    http://www.commercepundit.com/LICENSE-1.0.html
 *
 * -->
 */

namespace Commercepundit\WebQuote\Model\Config\Source;

use Commercepundit\Customer\Helper\Data as CustomerHelper;
use Magento\Customer\Api\Data\GroupInterface;
use Magento\Customer\Api\GroupRepositoryInterface;
use Magento\Framework\Api\FilterBuilder;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Customer\Model\Customer\Source\GroupSourceInterface;

/**
 * Get customer groups
 */
class CustomerGroup implements \Magento\Framework\Option\ArrayInterface
{
    /**
     * @var CustomerHelper
     */
    protected $customerHelper;

    /**
     * @var GroupRepositoryInterface
     */
    protected $groupRepository;

    /**
     * @var FilterBuilder
     */
    protected $filterBuilder;

    /**
     * @var SearchCriteriaBuilder
     */
    protected $searchCriteriaBuilder;

    /**
     * @var GroupSourceInterface
     */
    protected $customerGroupSource;

    /**
     * @param CustomerHelper $customerHelper
     * @param GroupSourceInterface $customerGroupSource
     * @param GroupRepositoryInterface $groupRepository
     * @param FilterBuilder $filterBuilder
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     */
    public function __construct(
        CustomerHelper $customerHelper,
        GroupSourceInterface $customerGroupSource,
        GroupRepositoryInterface $groupRepository,
        FilterBuilder $filterBuilder,
        SearchCriteriaBuilder $searchCriteriaBuilder
    ) {
        $this->customerHelper = $customerHelper;
        $this->customerGroupSource = $customerGroupSource;
        $this->groupRepository = $groupRepository;
        $this->filterBuilder = $filterBuilder;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
    }

    /**
     * Customer Group options array.
     *
     * @return array
     */
    public function toOptionArray(): array
    {
        return $this->customerGroupSource->toOptionArray();
    }

    /**
     * Get Customer Groups
     *
     * @param  boolean $excludeHomemarkIds
     * @return array
     */
    public function getCustomerGroups($excludeHomemarkIds = false): array
    {
        $homemarkGroupIds = [];
        $customerGroups = [];
        if ($excludeHomemarkIds == true) {
            $homemarkIds = $this->customerHelper->getHomemarkCustomerGroupIds();
            if ($homemarkIds && trim($homemarkIds)) {
                $homemarkGroupIds = explode(',',$homemarkIds);
            }
        }
        if (!empty($homemarkGroupIds)) {
            $excludeHomemarkFilter[] = $this->filterBuilder
                ->setField(GroupInterface::ID)
                ->setConditionType('nin')
                ->setValue($homemarkGroupIds)
                ->create();

            $searchCriteria = $this->searchCriteriaBuilder
                ->addFilters($excludeHomemarkFilter)
                ->create();
        } else {
            $searchCriteria = $this->searchCriteriaBuilder->create();
        }

        $groups = $this->groupRepository->getList($searchCriteria);
        foreach ($groups->getItems() as $group) {
            $customerGroups[$group->getId()] = $group->getCode();
        }
        return $customerGroups;
    }

    /**
     * Get Website Id
     *
     * @param  int|null $storeId
     * @return int
     */
    public function getWebsiteId($storeId = null){
        return (int)$this->customerHelper->getWebsiteId($storeId);
    }
}
