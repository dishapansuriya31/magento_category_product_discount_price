<?php
namespace Commercepundit\WebQuote\Model\Config\Source;

use Commercepundit\General\Model\Config\Source\Boolean;

class CabinetLine extends \Magento\Eav\Model\Entity\Attribute\Source\AbstractSource
{
    /**
     * @var \Magento\Framework\App\ResourceConnection
     */
    protected $resourceConnection;

    /**
     * @param \Magento\Framework\App\ResourceConnection $resourceConnection
     */
    public function __construct(
        \Magento\Framework\App\ResourceConnection $resourceConnection
    ) {
        $this->resourceConnection = $resourceConnection;
    }

    /**
     * To Option Array
     *
     * @param  boolean $empty
     * @return array
     */
    public function getAllOptions($empty = true)
    {
        $option = [];
        $connection = $this->resourceConnection->getConnection();
        $select = $connection->select()
            ->from($connection->getTableName('cp_cabinet_line'), ['cabinet_line_id','cabinet_name'])
            ->order('cabinet_line_id ASC')
            //->where('status = ?', Boolean::YES)
            ->order('cabinet_name ASC');
        $cabinetlines = $connection->fetchPairs($select);
        if (count($cabinetlines)) {
            foreach ($cabinetlines as $cabinetlineId => $name) {
                $option[] = ['value' => $cabinetlineId, 'label' => __($name)];
            }
        }

        if ($empty == true) {
            array_unshift($option, ['value' => '', 'label' => __('-- Please Select --')]);
        }
        return $option;
    }
}
