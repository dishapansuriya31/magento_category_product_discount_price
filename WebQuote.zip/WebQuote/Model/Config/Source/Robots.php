<?php
/*
 *  Commercepundit
 *
 *   NOTICE OF LICENSE
 *
 *   This source file is subject to the Commercepundit.com license that is
 *   available through the world-wide-web at this URL:
 *   http://commercepundit.com/license
 *
 *   DISCLAIMER
 *
 *   Do not edit or add to this file if you wish to upgrade this extension to newer
 *   version in the future.
 *
 *  @category   Commercepundit
 *  @package    Commercepundit_WebQuote
 *  @copyright  Copyright (c) Commercepundit (http://www.commercepundit.com/)
 *  @license    http://www.commercepundit.com/LICENSE-1.0.html
 *
 */

namespace Commercepundit\WebQuote\Model\Config\Source;

class Robots extends \Magento\Eav\Model\Entity\Attribute\Source\AbstractSource
{
    /**
     * @inerhitDoc
     */
    public function getAllOptions(): array
    {
        return [
            ['value' => 'INDEX,FOLLOW', 'label' => 'INDEX, FOLLOW'],
            ['value' => 'NOINDEX,FOLLOW', 'label' => 'NOINDEX, FOLLOW'],
            ['value' => 'INDEX,NOFOLLOW', 'label' => 'INDEX, NOFOLLOW'],
            ['value' => 'NOINDEX,NOFOLLOW', 'label' => 'NOINDEX, NOFOLLOW']
        ];
    }
}
