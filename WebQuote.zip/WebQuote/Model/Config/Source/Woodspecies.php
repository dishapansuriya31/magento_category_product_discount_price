<?php
namespace Commercepundit\WebQuote\Model\Config\Source;

use Commercepundit\Cabinets\Model\Color\Type\Source\Status;

class Woodspecies extends \Magento\Eav\Model\Entity\Attribute\Source\AbstractSource
{
    /**
     * @var \Magento\Framework\App\ResourceConnection
     */
    protected $resourceConnection;

    /**
     * @param \Magento\Framework\App\ResourceConnection $resourceConnection
     */
    public function __construct(
        \Magento\Framework\App\ResourceConnection $resourceConnection
    ) {
        $this->resourceConnection = $resourceConnection;
    }

    /**
     * To Option Array
     *
     * @param  boolean $empty
     * @return array
     */
    public function getAllOptions()
    {
        $options = [];
        $options = [['value' => '', 'label' => __('-- Please Select --')]];
        $connection = $this->resourceConnection->getConnection();
        $select = $connection->select()
            ->from($connection->getTableName('cp_wood_type'), ['type_id','type_name'])
            //->where('status = ?', Status::STATUS_ENABLE)
            ->order('type_name ASC');
        $woodtype = $connection->fetchPairs($select);
        if (count($woodtype)) {
            foreach ($woodtype as $typeId => $typeName) {
                $options[] = ['value' => $typeId, 'label' => __($typeName)];
            }
        }
        return $options;
    }
}
