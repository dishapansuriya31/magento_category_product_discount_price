<?php
namespace Commercepundit\WebQuote\Model\Config\Source;

use Commercepundit\Cabinets\Model\Color\Type\Source\Status;

class Style extends \Magento\Eav\Model\Entity\Attribute\Source\AbstractSource
{
    /**
     * @var \Magento\Framework\App\ResourceConnection
     */
    protected $resourceConnection;

    /**
     * @param \Magento\Framework\App\ResourceConnection $resourceConnection
     */
    public function __construct(
        \Magento\Framework\App\ResourceConnection $resourceConnection
    ) {
        $this->resourceConnection = $resourceConnection;
    }

    /**
     * To Option Array
     *
     * @param  boolean $empty
     * @return array
     */
    public function getAllOptions()
    {
        $options = [];
        $options = [['value' => '', 'label' => __('-- Please Select --')]];
        $connection = $this->resourceConnection->getConnection();
        $select = $connection->select()
            ->from($connection->getTableName('cp_style'), ['style_id','name'])
            //->where('status = ?', Status::STATUS_ENABLE)
            ->order('name ASC');
        $styles = $connection->fetchPairs($select);
        if (count($styles)) {
            foreach ($styles as $styleId => $name) {
                $options[] = ['value' => $styleId, 'label' => __($name)];
            }
        }
        return $options;
    }
}
