<?php
/*
 * <!--
 * *
 *  * Commercepundit
 *  *
 *  * NOTICE OF LICENSE
 *  *
 *  * This source file is subject to the Commercepundit.com license that is
 *  * available through the world-wide-web at this URL:
 *  * http://commercepundit.com/license
 *  *
 *  * DISCLAIMER
 *  *
 *  * Do not edit or add to this file if you wish to upgrade this extension to newer
 *  * version in the future.
 *  *
 *  * @category   Commercepundit
 *  * @package    Commercepundit_Customer
 *  * @copyright  Copyright (c) Commercepundit (http://www.commercepundit.com/)
 *  * @license    http://www.commercepundit.com/LICENSE-1.0.html
 *
 * -->
 */

namespace Commercepundit\WebQuote\Model\Source;

use Magento\Directory\Helper\Data;

/**
 * Get websites.
 */
class Websites implements \Magento\Framework\Option\ArrayInterface
{
    /**
     * @var Data
     */
    protected $directoryHelper;

    /**
     * @param Data $directoryHelper
     */
    public function __construct(Data $directoryHelper)
    {
        $this->directoryHelper = $directoryHelper;
    }

    /**
     * Websites Options array.
     *
     * @return array[]
     */
    public function toOptionArray(): array
    {
        $websites = [
            [
                'label' => __('All Websites') . ' [' . $this->directoryHelper->getBaseCurrencyCode() . ']',
                'value' => 0,
            ]
        ];

        return $websites;
    }
}
