<?php
/*
 * <!--
 * *
 *  * Commercepundit
 *  *
 *  * NOTICE OF LICENSE
 *  *
 *  * This source file is subject to the Commercepundit.com license that is
 *  * available through the world-wide-web at this URL:
 *  * http://commercepundit.com/license
 *  *
 *  * DISCLAIMER
 *  *
 *  * Do not edit or add to this file if you wish to upgrade this extension to newer
 *  * version in the future.
 *  *
 *  * @category   Commercepundit
 *  * @package    Commercepundit_Customer
 *  * @copyright  Copyright (c) Commercepundit (http://www.commercepundit.com/)
 *  * @license    http://www.commercepundit.com/LICENSE-1.0.html
 *
 * -->
 */

namespace Commercepundit\WebQuote\Model\Source;

use Magento\Customer\Model\Customer\Source\GroupSourceInterface;
use Magento\Framework\Module\Manager as ModuleManager;

/**
 * Get customer groups
 */
class CustomerGroup implements \Magento\Framework\Option\ArrayInterface
{
    /**
     * @var ModuleManager
     */
    protected $moduleManager;

    /**
     * @var GroupSourceInterface
     */
    protected $customerGroupSource;

    /**
     * @param ModuleManager $moduleManager
     * @param GroupSourceInterface $customerGroupSource
     */
    public function __construct(
        ModuleManager        $moduleManager,
        GroupSourceInterface $customerGroupSource
    ) {
        $this->moduleManager = $moduleManager;
        $this->customerGroupSource = $customerGroupSource;
    }

    /**
     * Customer group options array.
     *
     * @return array
     */
    public function toOptionArray()
    {
        if (!$this->moduleManager->isEnabled('Magento_Customer')) {
            return [];
        }

        return $this->customerGroupSource->toOptionArray();
    }
}
