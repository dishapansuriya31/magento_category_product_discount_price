<?php
/*
 * <!--
 * *
 *  * Commercepundit
 *  *
 *  * NOTICE OF LICENSE
 *  *
 *  * This source file is subject to the Commercepundit.com license that is
 *  * available through the world-wide-web at this URL:
 *  * http://commercepundit.com/license
 *  *
 *  * DISCLAIMER
 *  *
 *  * Do not edit or add to this file if you wish to upgrade this extension to newer
 *  * version in the future.
 *  *
 *  * @category   Commercepundit
 *  * @package    Commercepundit_Customer
 *  * @copyright  Copyright (c) Commercepundit (http://www.commercepundit.com/)
 *  * @license    http://www.commercepundit.com/LICENSE-1.0.html
 *
 * -->
 */
namespace Commercepundit\WebQuote\Model;

use Bread\BreadCheckout\Model\Payment\Api\Client;
use Magento\Catalog\Api\CategoryRepositoryInterface;
use Magento\Catalog\Model\Category as ModelCategory;
use Magento\Catalog\Model\ProductRepository;
use Magento\Customer\Api\GroupManagementInterface;
use Commercepundit\WebQuote\Model\Config\Source\CustomerGroup as CustomerGroupSource;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Locale\FormatInterface;
use Magento\Framework\Model\AbstractModel;
use Magento\Framework\Model\Context;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface;
use Magento\Framework\Currency as ZendCurrency;
/**
 * Ten by price model
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class TenByTenPrice extends AbstractModel
{
    /**
     * @var CategoryRepositoryInterface
     */
    private $categoryRepository;

    /**
     * @var GroupManagementInterface
     */
    private $groupManagement;

    /**
     * @var FormatInterface
     */
    private $localeFormat;

    /**
     * @var \Magento\Directory\Model\Currency
     */
    private $currency;

    /**
     * @var ProductRepository
     */
    private $productRepository;

    /**
     * @var TimezoneInterface
     */
    private $localeDate;

    /**
     * @var CustomerGroupSource
     */
    private $customerGroupSource;

    /**
     * @var \Commercepundit\General\Helper\Price
     */
    private $priceHelper;

    /**
     * @var Client
     */
    protected $paymentApiClient;

    /**
     * @param Context $context
     * @param \Magento\Framework\Registry $registry
     * @param CategoryRepositoryInterface $categoryRepository
     * @param GroupManagementInterface $groupManagement
     * @param FormatInterface $format
     * @param ProductRepository $productRepository
     * @param TimezoneInterface $localeDate
     * @param CustomerGroupSource $customerGroupSource
     * @param \Magento\Directory\Model\Currency $currency
     * @param \Commercepundit\General\Helper\Price $priceHelper
     * @param Client $paymentApiClient
     * @param \Magento\Framework\Model\ResourceModel\AbstractResource|null $resource
     * @param \Magento\Framework\Data\Collection\AbstractDb|null $resourceCollection
     * @param array $data
     * @SuppressWarnings(PHPMD.ExcessiveParameterList)
     */
    public function __construct(
        Context $context,
        \Magento\Framework\Registry $registry,
        CategoryRepositoryInterface $categoryRepository,
        GroupManagementInterface $groupManagement,
        FormatInterface $format,
        ProductRepository $productRepository,
        TimezoneInterface $localeDate,
        CustomerGroupSource $customerGroupSource,
        \Magento\Directory\Model\Currency $currency,
        \Commercepundit\General\Helper\Price $priceHelper,
        Client $paymentApiClient,
        \Magento\Framework\Model\ResourceModel\AbstractResource $resource = null,
        \Magento\Framework\Data\Collection\AbstractDb $resourceCollection = null,
        array $data = []
    ) {
        parent::__construct($context, $registry, $resource, $resourceCollection, $data);
        $this->categoryRepository = $categoryRepository;
        $this->groupManagement = $groupManagement;
        $this->localeFormat = $format;
        $this->currency = $currency;
        $this->productRepository = $productRepository;
        $this->localeDate = $localeDate;
        $this->customerGroupSource = $customerGroupSource;
        $this->priceHelper = $priceHelper;
        $this->paymentApiClient = $paymentApiClient;
    }

    /**
     * Initialize magento model.
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(\Commercepundit\WebQuote\Model\ResourceModel\TenByTenPrice::class);
    }

    /**
     * Get ten by price
     *
     * @param ModelCategory|int $category
     * @return array|false
     * @throws LocalizedException
     */
    public function getTenByPrice($category)
    {
        $categoryId = null;
        if (is_numeric($category)) {
            try {
                $categoryId = $this->categoryRepository->get($category)->getId();
            } catch (NoSuchEntityException $e) {
                return false;
            }
        } elseif ($category instanceof ModelCategory) {
            $categoryId = $category->getId() ?? '';
        }
        if ($categoryId) {
            $collection = $this->getCollection()->addFieldToFilter('entity_id', $categoryId);
            $allCustGroupId = $this->getAllCustomerGroupsId();
            if ($collection->getSize()) {
                $tenByPriceData = [];
                foreach ($collection as $item) {
                    $tenByPriceData [] = [
                        'value_id' => $item->getValueId(),
                        'website_id' => $item->getWebsiteId(),
                        'cust_group' => $item->getAllGroups() == 1 ? $allCustGroupId : $item->getCustomerGroupId(),
                        'regular_price' => $this->getFormatPrice($item->getRegularPrice()),
                        'discount_price' => $this->getFormatPrice($item->getDiscountPrice()),
                        'as_low_as_price' => $this->getFormatPrice($item->getAsLowAsPrice())
                    ];
                }
                return $tenByPriceData;
            }
        }
        return false;
    }

    /**
     * Gets the CUST_GROUP_ALL id
     *
     * @return int
     * @throws LocalizedException
     */
    protected function getAllCustomerGroupsId(): int
    {
        // ex: 32000
        return $this->groupManagement->getAllCustomersGroup()->getId();
    }

    /**
     * Save data.
     *
     * @param array|null $data
     * @param int $entityId
     * @return void
     * @throws LocalizedException
     */
    public function saveTenByPriceData(array $data, int $entityId)
    {
        if ($entityId) {
            $isValid = $this->validate($data);
            if ($isValid) {
                $collection = $this->getCollection()->addFieldToFilter('entity_id', $entityId);
                if ($collection->getSize()) {
                    $categoryId = $entityId;
                    $origPrices = $collection->getData();
                    $old = $this->prepareOldTierPriceToCompare($origPrices);
                    $new = $this->prepareNewDataForSave($data);

                    $delete = array_diff_key($old, $new);
                    $insert = array_diff_key($new, $old);
                    $update = array_intersect_key($new, $old);

                    $this->deleteValues($categoryId, $delete);
                    $this->insertValues($categoryId, $insert);
                    $this->updateValues($update, $old);
                } else {
                    $new = $this->prepareNewDataForSave($data);
                    $this->insertValues($entityId, $new);
                }
            }
        }
    }

    /**
     * Prepare old data to compare.
     *
     * @param array|null $origPrices
     * @return array
     * @throws LocalizedException
     */
    private function prepareOldTierPriceToCompare(?array $origPrices): array
    {
        $old = [];
        if (is_array($origPrices)) {
            foreach ($origPrices as $data) {
                $key = $this->getPriceKey($data);
                $old[$key] = $data;
            }
        }
        return $old;
    }

    /**
     * Get generated price key based on price data
     *
     * @param array $priceData
     * @return string
     * @throws LocalizedException
     */
    private function getPriceKey(array $priceData): string
    {
        $customerGroup = 0;
        if (isset($priceData['cust_group'])) {
            $customerGroup = $priceData['cust_group'] == 1 ? $this->getAllCustomerGroupsId() : $priceData['cust_group'];
        }
        if (isset($priceData['all_groups'])) {
            $customerGroup = $priceData['all_groups'] == 1 ? $this->getAllCustomerGroupsId() :
                $priceData['customer_group_id'];
        }
        return implode(
            '-',
            array_merge([$priceData['website_id']], [$customerGroup])
        );
    }

    /**
     * Prepare new data for save.
     *
     * @param array $priceRows
     * @return array
     * @throws LocalizedException
     */
    private function prepareNewDataForSave(array $priceRows): array
    {
        $new = [];
        $priceRows = array_filter($priceRows);
        foreach ($priceRows as $data) {
            if (isset($data['cust_group'])) {
                $key = $this->getPriceKey($data);
                $new[$key] = $this->prepareTenByPrice($data);
            }
        }

        return $new;
    }

    /**
     * Prepare ten by price data by provided price row data.
     *
     * @param array $data
     * @return array
     * @throws LocalizedException
     */
    protected function prepareTenByPrice(array $data): array
    {
        $useForAllGroups = (int)$data['cust_group'] === $this->getAllCustomerGroupsId();
        $customerGroupId = $useForAllGroups ? 0 : $data['cust_group'];
        return [
            'website_id' => $data['website_id'],
            'all_groups' => (int)$useForAllGroups,
            'customer_group_id' => $customerGroupId,
            'regular_price' => $data['regular_price'],
            'discount_price' => $data['discount_price'],
            'as_low_as_price' => $data['as_low_as_price']
        ];
    }

    /**
     * Validate data.
     *
     * @param array $priceRows
     * @throws LocalizedException
     */
    public function validate(array $priceRows): bool
    {
        $duplicates = [];
        foreach ($priceRows as $priceRow) {
            if (!empty($priceRow['delete'])) {
                continue;
            }
            $compare = implode(
                '-',
                [$priceRow['website_id'], $priceRow['cust_group']]
            );
            if (isset($duplicates[$compare])) {
                throw new LocalizedException(
                    __('We found a duplicate website, ten by price, customer group.')
                );
            }
            $this->validatePrice($priceRow);
            $duplicates[$compare] = true;
        }
        return true;
    }

    /**
     * Validate price.
     *
     * @param array $priceRow
     * @return void
     * @throws LocalizedException
     */
    protected function validatePrice(array $priceRow)
    {
        if (!isset($priceRow['regular_price']) || !$this->isPositiveOrZero($priceRow['regular_price']) ||
            !isset($priceRow['discount_price']) || !$this->isPositiveOrZero($priceRow['discount_price']) ||
            !isset($priceRow['as_low_as_price']) || !$this->isPositiveOrZero($priceRow['as_low_as_price'])
        ) {
            throw new LocalizedException(
                __('Ten By price must be a number greater than 0.')
            );
        }
    }

    /**
     * Returns whether the value is greater than, or equal to, zero
     *
     * @param mixed $value
     * @return bool
     */
    protected function isPositiveOrZero($value): bool
    {
        $value = $this->localeFormat->getNumber($value);
        $isNegative = $value < 0;
        return  !$isNegative;
    }

    /**
     * Update existing ten by prices.
     *
     * @param array $valuesToUpdate
     * @param array $oldValues
     * @return void
     * @throws LocalizedException
     */
    private function updateValues(array $valuesToUpdate, array $oldValues): void
    {
        foreach ($valuesToUpdate as $key => $value) {
            if (
                ($value['regular_price'] !== null && (float)$oldValues[$key]['regular_price'] !== $this->localeFormat->getNumber($value['regular_price'])) ||
                ($value['discount_price'] !== null && (float)$oldValues[$key]['discount_price'] !== $this->localeFormat->getNumber($value['discount_price'])) ||
                ($value['as_low_as_price'] !== null && (float)$oldValues[$key]['as_low_as_price'] !== $this->localeFormat->getNumber($value['as_low_as_price']))
            ) {
                $price = new \Magento\Framework\DataObject(
                    [
                        'value_id' => $oldValues[$key]['value_id'],
                        'website_id' => $value['website_id'],
                        'all_groups' => $value['all_groups'],
                        'customer_group_id' => $value['customer_group_id'],
                        'regular_price' => $value['regular_price'],
                        'discount_price' => $value['discount_price'],
                        'as_low_as_price' => $value['as_low_as_price']
                    ]
                );
                $this->_getResource()->savePriceData($price);
            }
        }
    }

    /**
     * Insert new tier prices for processed product
     *
     * @param int $categoryId
     * @param array $valuesToInsert
     * @return void
     * @throws LocalizedException
     */
    private function insertValues(int $categoryId, array $valuesToInsert): void
    {
        foreach ($valuesToInsert as $data) {
            $price = new \Magento\Framework\DataObject($data);
            $price->setData(
                'entity_id',
                $categoryId
            );
            $this->_getResource()->savePriceData($price);
        }
    }

    /**
     * Delete ten by price value.
     *
     * @param int $categoryId
     * @param array $valuesToDelete
     * @return void
     * @throws LocalizedException
     */
    private function deleteValues(int $categoryId, array $valuesToDelete): void
    {
        foreach ($valuesToDelete as $data) {
            $this->_getResource()->deletePriceData($categoryId, null, $data[$this->getIdFieldName()]);
        }
    }

    /**
     * Get formatted price.
     *
     * @param float $price
     * @return string
     */
    protected function getFormatPrice(float $price): string
    {
        return $this->currency->format($price, ['display' => ZendCurrency::NO_SYMBOL], false);
    }

    /**
     * Fetch and save ten by price data.
     *
     * @param ModelCategory|int $category
     * @return bool
     * @throws NoSuchEntityException
     * @throws LocalizedException
     *
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @SuppressWarnings(PHPMD.NPathComplexity)
     * @SuppressWarnings(PHPMD.UnusedLocalVariable)
     */
    public function fetchTenByPrice($category,$storeId): bool
    {
        try {
            if (is_numeric($category)) {
                try {
                    $category = $this->categoryRepository->get($category);
                } catch (NoSuchEntityException $e) {
                    return false;
                }
            }
            if (!$category instanceof ModelCategory) {
                return false;
            }
            $tenBySku = $category->getData('ten_by_price_sku') ?? '';
            $isShowAddToCartButton = (bool)$category->getIsShowTenByTenAddToCartButton() ?? false;
            if (empty($tenBySku) || !trim($tenBySku) || $isShowAddToCartButton != true) {
                return false;
            }
            $tenByPriceData = [];
            $tenBySkus = explode(',', trim($tenBySku));
            $customerGroupIds = $this->customerGroupSource->getCustomerGroups(true);
            if (!empty($tenBySkus) && !empty($customerGroupIds)) {
                $websiteId = $this->customerGroupSource->getWebsiteId($category->getStoreId());
                $connection = $this->getResource()->getConnection();
                $date = date('Y-m-d',$this->localeDate->scopeTimeStamp($category->getStoreId()));
                foreach($tenBySkus as $sku) {
                    try {
                    $product = $this->productRepository->get($sku, false, $storeId);
                    } catch (NoSuchEntityException $e) {
                        continue;
                    }
                    if ($product && $product->getId()) {
                        $cabinetLineId = 0;
                        if ($product->getCabinetLineId() && trim($product->getCabinetLineId())) {
                            $cabinetLineIds = explode(',', $product->getCabinetLineId());
                            $cabinetLineId = reset($cabinetLineIds);
                        }
                        foreach ($customerGroupIds as $groupId => $groupName) {
                            $regularPrice = (float)$product->getPrice();
                            $discountPrice = (float)$product->getPrice();
                            $key = implode('-', [$websiteId, $groupId]);
                            $select = $connection->select()
                                ->from($connection->getTableName('catalogrule_product_price'),['rule_price'])
                                ->where('product_id = ?', $product->getId())
                                ->where('customer_group_id = ?', $groupId)
                                ->where('rule_date = ?', $date);
                            $rulePrice = (float)$connection->fetchOne($select);
                            if ($rulePrice > 0) {
                                $discountPrice = $rulePrice;
                            }
                            if ($cabinetLineId > 0) {
                                $regularPrice = $this->priceHelper->applyPriceLogic(
                                    $regularPrice,
                                    $cabinetLineId,
                                    $groupId
                                );
                                $discountPrice = $this->priceHelper->applyPriceLogic(
                                    $discountPrice,
                                    $cabinetLineId,
                                    $groupId
                                );
                            }
                            if (isset($tenByPriceData[$key])) {
                                $tenByPriceData[$key]['regular_price'] += $regularPrice;
                                $tenByPriceData[$key]['discount_price'] += $discountPrice;
                            } else {
                                $tenByPriceData[$key] = [
                                    'website_id' => 0,
                                    'cust_group' => $groupId,
                                    'regular_price' => $regularPrice,
                                    'discount_price' => $discountPrice
                                ];
                            }
                            $tenByPriceData[$key]['as_low_as_price'] = 0;
                        }
                    }
                }
            }
            if (!empty($tenByPriceData) && count($tenByPriceData) > 0) {
                $this->saveTenByPriceData($tenByPriceData, $category->getId());
                return true;
            }
        } catch (LocalizedException|\Exception $e) {
            $writer = new \Laminas\Log\Writer\Stream(BP . '/var/log/tenByPrice.log');
            $logger = new \Laminas\Log\Logger();
            $logger->addWriter($writer);
            $logger->debug($e->getMessage());
        }
        return false;
    }

    /**
     * Get AsLowAs Price From Bread
     *
     * @param  float $price
     * @param  int $storeId
     * @return float
     */
    public function getAsLowAsPriceFromBread($price,$storeId) {
        $rate = 0;
        try {
            if ($this->paymentApiClient->isActive(\Magento\Store\Model\ScopeInterface::SCOPE_STORE,$storeId)){
                $price = (int)(floatval($price) * 100);
                $result = $this->paymentApiClient->getAsLowAsData($price,$storeId);
                if (isset($result['asLowAs']) && isset($result['asLowAs']['paymentAmountText']) && isset($result['asLowAs']['paymentAmountText']['en-us'])) {
                    $currencySymbol = $this->currency->getCurrencySymbol();
                    $rate = (float)str_replace($currencySymbol,'',(string)$result['asLowAs']['paymentAmountText']['en-us']);
                }
            }
        } catch (\Throwable $e) {
            $rate = 0;
        }
        return $rate;
    }

    /**
     * Fetch and save aslowas price data.
     *
     * @param int $categoryId
     * @param int $storeId
     * @throws LocalizedException
     */
    public function fetchAsLowAsPrice($categoryId,$storeId)
    {
        try {
            $collection = $this->getCollection()->addFieldToFilter('entity_id', $categoryId);
            if ($collection->getSize()) {
                foreach($collection as $priceData) {
                    $tenByPrice = (float)$priceData->getRegularPrice();
                    if ((float)$priceData->getDiscountPrice() < (float)$priceData->getRegularPrice()) {
                        $tenByPrice = (float)$priceData->getDiscountPrice();
                    }
                    $asLowAsPrice = (float)$this->getAsLowAsPriceFromBread($tenByPrice,$storeId);
                    if ($asLowAsPrice > 0) {
                        $priceData->setAsLowAsPrice($asLowAsPrice)->save();
                    }
                }
            } else {
                throw new LocalizedException(__('10X10 price data not found.'));
            }
        } catch (LocalizedException|\Exception $e) {
            throw new LocalizedException(__($e->getMessage()));
            /*$writer = new \Laminas\Log\Writer\Stream(BP . '/var/log/asLowAsPrice.log');
            $logger = new \Laminas\Log\Logger();
            $logger->addWriter($writer);
            $logger->debug($e->getMessage());*/
        }
    }
}
