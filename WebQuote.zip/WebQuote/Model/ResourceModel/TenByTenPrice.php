<?php
/*
 * <!--
 * *
 *  * Commercepundit
 *  *
 *  * NOTICE OF LICENSE
 *  *
 *  * This source file is subject to the Commercepundit.com license that is
 *  * available through the world-wide-web at this URL:
 *  * http://commercepundit.com/license
 *  *
 *  * DISCLAIMER
 *  *
 *  * Do not edit or add to this file if you wish to upgrade this extension to newer
 *  * version in the future.
 *  *
 *  * @category   Commercepundit
 *  * @package    Commercepundit_Customer
 *  * @copyright  Copyright (c) Commercepundit (http://www.commercepundit.com/)
 *  * @license    http://www.commercepundit.com/LICENSE-1.0.html
 *
 * -->
 */

namespace Commercepundit\WebQuote\Model\ResourceModel;

use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

class TenByTenPrice extends AbstractDb
{
    /**
     * Initialize resource model.
     */
    protected function _construct()
    {
        $this->_init('cp_ten_by_ten_price', 'value_id');
    }

    /**
     * Delete ten by price values.
     *
     * @param int $categoryId
     * @param mixed $websiteId
     * @param mixed $priceId
     * @return int
     * @throws LocalizedException
     */
    public function deletePriceData(int $categoryId, $websiteId = null, $priceId = null): int
    {
        $connection = $this->getConnection();

        $conds = [$connection->quoteInto('entity_id' . ' = ?', $categoryId)];

        if ($websiteId !== null) {
            $conds[] = $connection->quoteInto('website_id = ?', $websiteId);
        }

        if ($priceId !== null) {
            $conds[] = $connection->quoteInto($this->getIdFieldName() . ' = ?', $priceId);
        }

        $where = implode(' AND ', $conds);

        return $connection->delete($this->getMainTable(), $where);
    }

    /**
     * Insert new ten by prices.
     *
     * @param \Magento\Framework\DataObject $priceObject
     * @return void
     * @throws LocalizedException
     */
    public function savePriceData(\Magento\Framework\DataObject $priceObject): void
    {
        $connection = $this->getConnection();
        $data = $this->_prepareDataForTable($priceObject, $this->getMainTable());

        if (!empty($data[$this->getIdFieldName()])) {
            $where = $connection->quoteInto($this->getIdFieldName() . ' = ?', $data[$this->getIdFieldName()]);
            unset($data[$this->getIdFieldName()]);
            $connection->update($this->getMainTable(), $data, $where);
        } else {
            $connection->insert($this->getMainTable(), $data);
        }
    }
}
