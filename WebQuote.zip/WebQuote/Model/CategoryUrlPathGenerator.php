<?php

namespace Commercepundit\WebQuote\Model;

use Magento\Catalog\Api\CategoryRepositoryInterface;
use Magento\Catalog\Model\Category;
use Magento\CatalogUrlRewrite\Model\CategoryUrlPathGenerator as Magento_CategoryUrlPathGenerator;

class CategoryUrlPathGenerator extends Magento_CategoryUrlPathGenerator {


    /**
     * Minimal category level that can be considered for generate path
     */
    const MINIMAL_CATEGORY_LEVEL_FOR_PROCESSING = 3;

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $storeManager;

    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $scopeConfig;

    /**
     * @var CategoryRepositoryInterface
     */
    protected $categoryRepository;

    /**
     * @var Request
     */
    protected $request;

    /**
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     * @param CategoryRepositoryInterface $categoryRepository
     * @param \Magento\Framework\App\Request\Http $request
     */
    public function __construct(
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        CategoryRepositoryInterface $categoryRepository,
        \Magento\Framework\App\Request\Http $request
    ) {
        $this->storeManager = $storeManager;
        $this->scopeConfig = $scopeConfig;
        $this->categoryRepository = $categoryRepository;
        $this->request = $request;
        parent::__construct($storeManager,$scopeConfig,$categoryRepository);
    }


    /**
     * Fetch UrlPath 
     *
     * @param array|object $category
     * @param int|null $parentCategory
     * @return string
     * @throws LocalizedException
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     * @SuppressWarnings(PHPMD.CyclomaticComplexity) 
     */
    public function getUrlPath($category, $parentCategory = null)
    {
        if (in_array($category->getParentId(), [Category::ROOT_CATEGORY_ID, Category::TREE_ROOT_ID])) {
            return '';
        }
        $path = $category->getUrlPath();
        if ($path !== null && !$category->dataHasChangedFor('url_key') && !$category->dataHasChangedFor('parent_id')) {
            return $path;
        }
        $path = $category->getUrlKey();
        if ($path === false) {
            return $category->getUrlPath();
        }
        /* cp custom change */
        if ($this->request->getModuleName() == 'admin' &&
            $this->request->getControllerName() == 'import' &&
            $this->request->getActionName() == 'start'
        ) {
            if ($this->isNeedToGenerateUrlPathForParent($category)) {
                $parentCategory = $parentCategory === null ?
                    $this->categoryRepository->get($category->getParentId(), $category->getStoreId()) : $parentCategory;
                $parentPath = $this->getUrlPath($parentCategory);
                $path = $parentPath === '' ? $path : $parentPath . '/' . $path;
            }
        }
        return $path;
        /* cp custom change */
    }   

    /**
     * Define whether we should generate URL path for parent
     *
     * @param \Magento\Catalog\Model\Category $category
     * @return bool
     */
    protected function isNeedToGenerateUrlPathForParent($category)
    {
        return $category->isObjectNew() || $category->getLevel() >= self::MINIMAL_CATEGORY_LEVEL_FOR_PROCESSING;
    } 
}