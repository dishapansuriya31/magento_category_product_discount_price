<?php

namespace Commercepundit\WebQuote\Model;

/**
 * Class Richelieu
 *
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class NewCategoryLabel extends \Magento\Framework\Model\AbstractModel
{
    /**
     * @var \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory
     */
    protected $_productCollectionFactory;

    /**
     * @param \Magento\Framework\Model\Context                                $context
     * @param \Magento\Store\Model\StoreManagerInterface                      $storeManager
     *
     * @throws \Magento\Framework\Exception\FileSystemException
     * @SuppressWarnings(PHPMD.ExcessiveParameterList)
     */
    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Framework\Registry $registry,
        \Magento\Catalog\Model\ResourceModel\Category\CollectionFactory $categoryFactory,
        \Magento\Catalog\Model\CategoryRepository $categoryRepository,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\Stdlib\DateTime\TimezoneInterface $date,
    ) {
        $this->scopeConfig = $scopeConfig;
        $this->categoryFactory = $categoryFactory;
        $this->categoryRepository = $categoryRepository;
        $this->storeManager = $storeManager;
        $this->date = $date;
        parent::__construct($context,$registry);

    }

    /**
     * @return bool
     * @SuppressWarnings(PHPMD.ExcessiveParameterList)
     */
    public function changeLabelInfo()
    {
        $currentDate = new \DateTime();
        $categories = $this->categoryFactory->create()->setStoreId(0)
                        ->addAttributeToSelect('*')
                        ->addAttributeToFilter('is_new',['eq'=>1])
                        ->addAttributeToFilter('is_new_end_date',['lt' => $currentDate->format('Y-m-d 00:00:00')]);
        if($categories && $categories->getSize()){
            foreach ($categories as $category) {
                $category = $this->categoryRepository->get($category->getId());
                $category->setIsNew(0);
                $category->setIsNewEndDate('');
                $this->categoryRepository->save($category);
            }
        }
        return true;
    }

    public function getConfigValue($path)
    {
        return $this->scopeConfig->getValue($path, \Magento\Store\Model\ScopeInterface::SCOPE_STORE, $this->storeManager->getStore()->getStoreId());
    }

}
