<?php

/**
 * Commercepundit
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Commercepundit.com license that is
 * available through the world-wide-web at this URL:
 * http://commercepundit.com/license
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category   Commercepundit
 * @package    Commercepundit_WebQuote
 * @copyright  Copyright (c)Commercepundit (http://www.commercepundit.com/)
 * @license    http://www.commercepundit.com/LICENSE-1.0.html
 */

namespace Commercepundit\WebQuote\Model;

use Commercepundit\Cabinets\Helper\Data as CabinetHelper;
use Commercepundit\Cabinets\Model\Color\Source\Group;
use Commercepundit\Cabinets\Model\Color\Source\Status as ColorStatus;
use Commercepundit\Cabinets\Model\Style\Source\Status;
use Commercepundit\General\Model\Config\Source\Boolean;
use Magento\Framework\UrlInterface;

class GetstylebycabinetidManagement implements \Commercepundit\WebQuote\Api\GetstylebycabinetidManagementInterface
{
    const FILTER_PARAM = [
        'door_id' => 'CS.',
        'color_category_id' => 'color_category.',
        'cabinet_line_id' => 'CS.',
    ];

    /**
     * @var \Magento\Framework\App\ResourceConnection
     */
    protected $resourceConnection;

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $storeManager;

    /**
     * @var CabinetHelper
     */
    protected $cabinetHelper;

    protected $filterOptions = [];

    /**
     * @param \Magento\Framework\App\ResourceConnection $resourceConnection
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param CabinetHelper $cabinetHelper
     */
    public function __construct(
        \Magento\Framework\App\ResourceConnection  $resourceConnection,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        CabinetHelper                              $cabinetHelper
    ) {
        $this->resourceConnection = $resourceConnection;
        $this->storeManager = $storeManager;
        $this->cabinetHelper = $cabinetHelper;
    }

    /**
     * Get Media Url
     *
     * @return string
     */
    public function getMediaUrl()
    {
        return $this->storeManager->getStore()
            ->getBaseUrl(UrlInterface::URL_TYPE_MEDIA);
    }

    /**
     * Get Door Listing Color Data
     *
     * @param mixed $filterRequest
     * @return array
     */

    public function stylebycabinetid($filterRequest = [])
    {
        $doorListingColorData = [];
        $webQuoteListingData = [];
        $connection = $this->resourceConnection->getConnection();
        $select = $connection->select()
            ->from(
                ['CS' => $connection->getTableName('cp_style')],
                ['*', 'style_cabinet_line_id' => 'cabinet_line_id']
            )
            ->join(
                ['CSC' => $connection->getTableName('cp_style_color')],
                'CS.style_id = CSC.style_id',
                ['mapping_image' => 'CSC.image', 'price_id', 'cabinet_line_id','category_url' => 'CSC.category_url']
            )
            ->join(
                $connection->getTableName('cp_door'),
                'CS.door_id = cp_door.door_id',
                [
                    'cp_door.door_id',
                    'door_name' => 'cp_door.name',
                ]
            )
            ->join(
                ['CC' => $connection->getTableName('cp_color')],
                'CSC.color_id = CC.color_id AND CC.status = ' . ColorStatus::STATUS_ENABLE,
                ['CC.color_id', 'color_image' => 'CC.image', 'color_name' => 'CC.name', 'color_group' => 'CC.group', 'CC.sort_order'] //phpcs:ignore
            )->join(
                ['CCL' => $connection->getTableName('cp_cabinet_line')],
                'CS.cabinet_line_id = CCL.cabinet_line_id',
                [
                    'color_type_used' => 'CCL.is_used_color_type',
                    'cabinet_name' => 'CCL.supplier',
                    'ori_cabinet_line_id' => 'cabinet_line_id',
                    'parent_cabinet_line_id '
                ]
            )->join(
                ['color_category' => $connection->getTableName('cp_color_category')],
                'color_category.color_category_id = CC.color_category_id
                 AND color_category.status = ' . ColorStatus::STATUS_ENABLE,
                [
                    'color_category_name' => 'color_category.name',
                    'color_category.color_category_id'
                ]
            )->join(
                ['CCT' => $connection->getTableName('cp_color_type')],
                'CC.type_id = CCT.type_id',
                ['color_type' => 'CCT.name']
            );

        //Exclude Collection query for restriction
        $select = $this->cabinetHelper->isRestrictCabinetLine($select, $connection);

        $select->where('CS.status = ?', Status::STATUS_ENABLE);
        if (!empty($filterRequest)) {

            foreach ($filterRequest as $column => $filterValue) {
                if (array_key_exists($column, self::FILTER_PARAM)) {
                    $select->where(
                        sprintf("%s%s IN (?)", self::FILTER_PARAM[$column], $column),
                        $filterValue
                    );
                }
            }
        }
        $select->order('CC.sort_order ASC');
        $allData = $connection->fetchAll($select);
        if (count($allData)) {
            $mediaUrl = $this->getMediaUrl();
            $defaultStyleId = 0;
            foreach ($allData as $data) {
                if ($defaultStyleId == 0) {
                    $defaultStyleId = $data['style_id'];
                }
                $data['defaultStyleId'] = $defaultStyleId;
                $this->formatDoorListingColorData($doorListingColorData, $data, $mediaUrl);
                $this->getWebQuoteStyleFilterOptions($data, $this->filterOptions);
            }
            $this->getCabinetLineFilterOptions($this->filterOptions);
            $webQuoteListingData = [
                [
                    'filter_options' => $this->filterOptions,
                    'styles_data' => $doorListingColorData,
                    'total_pages' => ($doorListingColorData) ? count($doorListingColorData) : '0',
                ]
            ];
        }
        return $webQuoteListingData;
    }

    /**
     * Get parent or child cabinetline ids
     *
     * @param int $cabinetLineId
     * @return array
     */
    public function getCabinetLineId($cabinetLineId)
    {
        if (empty($cabinetLineId)) {
            return [];
        }
        $connection = $this->resourceConnection->getConnection();
        $whereCond = sprintf(
            "(CS.cabinet_line_id = %s or CS.parent_cabinet_line_id = %s)",
            $cabinetLineId,
            $cabinetLineId
        );
        $select = $connection->select()
            ->from(
                ['CS' => $connection->getTableName('cp_cabinet_line')]
            )
            ->where('CS.status =  ? ', Status::STATUS_ENABLE)
            ->where(new \Zend_Db_Expr($whereCond));
        return $connection->fetchAll($select);
    }

    /**
     * Format Style Color Data
     *
     * @param array  &$styleColorData
     * @param array   $data
     * @param string  $mediaUrl
     * @return void
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @SuppressWarnings(PHPMD.NPathComplexity)
     */
    protected function formatDoorListingColorData(&$styleColorData, $data, $mediaUrl)
    {
        if (isset($data['color_image']) && $data['color_image']) {
            $data['color_image'] = $mediaUrl . $data['color_image'];
        }

        if (isset($data['color_type_used']) && $data['color_type_used'] == Boolean::YES) {
            $data['color_name'] = $data['color_type'];
        }

        if (isset($data['image']) && $data['image']) {
            $data['image'] = $mediaUrl . $data['image'];
        }
        if (isset($data['mapping_image']) && $data['mapping_image']) {
            $data['mapping_image'] = $mediaUrl . $data['mapping_image'];
            $data['mapping_image_style_' . $data['style_id']] = $data['mapping_image'];
        }
        if (!isset($styleColorData[$data['style_id']])) {
            $styleColorData[$data['style_id']] = $data;
        }
        if ($data['color_group'] == Group::STANDARD) {
            $styleColorData[$data['style_id']]['colors']['standard'][$data['color_id']] = $data;
            $styleColorData[$data['style_id']]['colors']['doorcolor'][$data['color_id']] = $data;
        }
        if ($data['color_group'] == Group::DESIGNER) {
            $styleColorData[$data['style_id']]['colors']['designer'][$data['color_id']] = $data;
            $styleColorData[$data['style_id']]['colors']['doorcolor'][$data['color_id']] = $data;
        }
    }

    /**
     * Get Style Filter Options
     *
     * @param  [] $styleColorData
     * @param  [] $options
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @return array
     */
    public function getWebQuoteStyleFilterOptions($styleColorData, &$options)
    {
        if (count($styleColorData)) {
            if (isset($styleColorData['door_id'])) {
                $doorId = $styleColorData['door_id'];
                $options['door']['name'] = 'door_id';
                $options['door']['label'] = 'Style';
                $options['door']['values'][$doorId] = [
                    'id' => $styleColorData['door_id'],
                    'name' => $styleColorData['door_name']
                ];
            }
            if (isset($styleColorData['style_cabinet_line_id'])) {
                $options['cabinetline']['name'] = 'cabinet_line_id';
                $options['cabinetline']['label'] = 'Line';
                $parentCabLineId = $styleColorData['parent_cabinet_line_id'];
                $styleCabId = $styleColorData['style_cabinet_line_id'];
                if ($parentCabLineId) {
                    if ((
                        !isset($options['cabinetline']['values'][$parentCabLineId]['options']) ||
                        !(isset($options['cabinetline']['values'][$parentCabLineId]['options'])
                            && in_array($styleCabId, $options['cabinetline']['values'][$parentCabLineId]['options']))
                    )) {
                        $options['cabinetline']['values'][$parentCabLineId]['options'][] = $styleCabId;
                        $options['cabinetline']['values'][$parentCabLineId]['name'] = $styleColorData['cabinet_name'];
                    }
                } else {
                    if (!isset($options['cabinetline']['values'][$styleCabId]['options'])) {
                        $options['cabinetline']['values'][$styleCabId]['options'][] = $styleCabId;
                        $options['cabinetline']['values'][$styleCabId]['name'] = $styleColorData['cabinet_name'];
                    }
                }
            }
            if (isset($styleColorData['color_category_id'])) {
                $colorCategoryId = $styleColorData['color_category_id'];
                $options['finish']['name'] = 'color_category_id';
                $options['finish']['label'] = 'Finish';
                $options['finish']['values'][$colorCategoryId] = [
                    'id' => $styleColorData['color_category_id'],
                    'name' => $styleColorData['color_category_name']
                ];
            }
        }
    }

    /**
     * Get Style Filter Options
     *
     * @param  [] $styleFilterOptions
     * @return array
     */
    public function getCabinetLineFilterOptions(&$styleFilterOptions)
    {
        if (isset($styleFilterOptions['cabinetline']['values'])) {
            foreach ($styleFilterOptions['cabinetline']['values'] as $parentId => &$style) {
                $options = $style['options'];
                $options[] = $parentId;
                $name = $style['name'];
                $style = [
                    'id' => implode(",", array_unique($options)),
                    'name' => $name
                ];
            }
        }
    }
}
