<?php
/*
 * Commercepundit
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Commercepundit.com license that is
 * available through the world-wide-web at this URL:
 * http://commercepundit.com/license
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category   Commercepundit
 * @package    Commercepundit_Customer
 * @copyright  Copyright (c) Commercepundit (http://www.commercepundit.com/)
 * @license    http://www.commercepundit.com/LICENSE-1.0.html
 *
 *
 */

namespace Commercepundit\WebQuote\Plugin;

use Magento\Cms\Model\Wysiwyg\Images\Storage;
use Magento\Framework\App\Filesystem\DirectoryList;

class ImageStorageValidation
{
    /**
     * Upload and resize new file
     *
     * @param Storage $subject
     * @param string $targetPath
     * @param string $type
     * @return array
     *
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function beforeUploadFile(Storage $subject, $targetPath, $type): array
    {
        if (is_null($type)) {
            $type = 'image';
        }
        return [$targetPath, $type];
    }

    /**
     * Around resize.
     *
     * @param Storage $subject
     * @param callable $proceed
     * @param string $source
     * @param bool $keepRatio
     * @return bool
     *
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function aroundResizeFile(Storage $subject, callable $proceed, $source, $keepRatio = true): bool
    {
        if ($source && strpos($source, '.pdf') === false) {
            return $proceed($source, $keepRatio);
        }
        return false;
    }
}
