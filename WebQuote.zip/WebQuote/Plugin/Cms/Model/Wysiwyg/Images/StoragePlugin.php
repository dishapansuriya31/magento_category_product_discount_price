<?php
/*
 * Commercepundit
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Commercepundit.com license that is
 * available through the world-wide-web at this URL:
 * http://commercepundit.com/license
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category   Commercepundit
 * @package    Commercepundit_WebQuote
 * @copyright  Copyright (c) Commercepundit (http://www.commercepundit.com/)
 * @license    http://www.commercepundit.com/LICENSE-1.0.html
 *
 *
 */

namespace Commercepundit\WebQuote\Plugin\Cms\Model\Wysiwyg\Images;

use Magento\Cms\Model\Wysiwyg\Images\Storage;
use Magento\Framework\View\Asset\Repository;

class StoragePlugin
{
    public function __construct(private Repository $assetRepo)
    {}

    /**
     * Add PDF thumbnail image url.
     *
     * @param Storage $subject
     * @param string $result
     * @param string $filePath
     * @param bool $checkFile
     * @return string
     *
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function afterGetThumbnailUrl(Storage $subject, string $result, string $filePath, $checkFile = false): string
    {
        if ($filePath && strpos($filePath, '.pdf') !== false) {
            return $this->assetRepo->getUrl("Commercepundit_WebQuote::images/pdf_icon.png");
        }
        return $result;
    }
}
