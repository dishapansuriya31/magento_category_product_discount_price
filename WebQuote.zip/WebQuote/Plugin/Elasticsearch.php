<?php
namespace Commercepundit\WebQuote\Plugin;

use Magento\Catalog\Model\ResourceModel\Product\Attribute\CollectionFactory AS AttributeCollectionFactory;
class Elasticsearch
{
    /**
     * @var \Magento\Framework\Registry
     */
    private $registry;

    /**
     * @var \Magento\Framework\App\RequestInterface
     */
    public $request;

    /**
     * @var AttributeCollectionFactory
     */
    private $attributeCollectionFactory;

    /**
     * @var \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory
     */
    protected $productCollection;

    /**
     * @var \Magento\Catalog\Model\CategoryFactory
     */
    protected $_categoryFactory;

    /**
     * @param Magento\Framework\Registry $registry
     * @param Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $collection
     * @param Magento\Catalog\Model\CategoryFactory $categoryFactory
     * @param Magento\Framework\App\RequestInterface $request
     * @param AttributeCollectionFactory $attributeCollectionFactory
     * @SuppressWarnings(PHPMD.ExcessiveParameterList)
     */
    public function __construct(
        \Magento\Framework\Registry $registry,
        \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $collection,
        \Magento\Catalog\Model\CategoryFactory $categoryFactory,
        \Magento\Framework\App\RequestInterface $request,
        AttributeCollectionFactory $attributeCollectionFactory
    ) {
        $this->registry = $registry;
        $this->productCollection = $collection;
        $this->_categoryFactory = $categoryFactory;
        $this->request = $request;
        $this->attributeCollectionFactory = $attributeCollectionFactory;
    }
    /**
     * Retrieve Custom query
     *
     * @param \Magento\Elasticsearch7\Model\Client\Elasticsearch $subject
     * @param string $query
     * @return query
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function beforeQuery($subject, $query)
    {
        $productIds = [];
        $queryStr = $this->request->getParam('query');
        if (!empty($queryStr)) {
            $productSearchableAttributes = $this->getUsedInSearchAttribute();
            $filerArray = [];
            foreach ($productSearchableAttributes as $attribute) {
                $filerArray[] = [
                    'attribute' => $attribute->getAttributeCode(), 
                    'like' => '%' . trim($queryStr) . '%'
                ];
            }
            $category = $this->registry->registry('current_category');//get current category
            $collection = $this->productCollection->create();
            $collection->addAttributeToSelect('*');
            $collection->addCategoryFilter($category);
            $collection->addAttributeToFilter(
                $filerArray
            );
            $collection->addAttributeToFilter(
                'visibility',
                \Magento\Catalog\Model\Product\Visibility::VISIBILITY_BOTH
            );
            $collection->addAttributeToFilter(
                'status',
                \Magento\Catalog\Model\Product\Attribute\Source\Status::STATUS_ENABLED
            );
            
            foreach ($collection as $product) {
                $productIds[] = $product->getId();
            }
            //show product ids in search result.
            $productIdsToShow =  $productIds;
            $query['body']['query']['bool']['must'] = [
                'ids' => [ 'values' => $productIdsToShow]
            ];
        }
        
        return [$query];
    }

    /**
     * Search attributes

     * @return DataObject[]
     */
    public function getUsedInSearchAttribute()
    {
        $searchableAttributes = $this->attributeCollectionFactory
            ->create()
            ->addFieldToFilter('is_searchable',1)
            ->addFieldToFilter('is_required',1)
            ->addFieldToFilter('frontend_input',
                [
                    [
                        'eq' => 'text'
                    ], 
                    [
                        'eq' => 'textarea',
                    ]
                ]
            )
            ->getItems();
        return $searchableAttributes;
    }
}
