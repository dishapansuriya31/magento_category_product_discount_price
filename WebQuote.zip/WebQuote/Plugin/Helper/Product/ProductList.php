<?php

/**
 * Commercepundit
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Commercepundit.com license that is
 * available through the world-wide-web at this URL:
 * http://commercepundit.com/license
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category   Commercepundit
 * @package    Commercepundit_WebQuote
 * @copyright  Copyright (c) Commercepundit (http://www.commercepundit.com/)
 * @license    http://www.commercepundit.com/LICENSE-1.0.html
 */

namespace Commercepundit\WebQuote\Plugin\Helper\Product;

use Magento\Catalog\Helper\Product\ProductList as ShowProductMode;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Registry;

/**
 * Show category mode
 * Magento\Catalog\Helper\Product\ProductList
 */
class ProductList
{
    public const XML_PATH_LIST_MODE = 'catalog/frontend/list_mode';
    /**
     * @var ScopeConfigInterface
     */
    protected $scopeConfig;
    /**
     * @var \Magento\Framework\ObjectManagerInterface
     */
    protected $objectManager;
    /**
     * @var Registry
     */
    private $coreRegistry;

    /**
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     * @param \Magento\Framework\ObjectManagerInterface $objectmanager
     * @param \Magento\Framework\Registry $coreRegistry
     */
    public function __construct(
        ScopeConfigInterface $scopeConfig,
        \Magento\Framework\ObjectManagerInterface $objectmanager,
        Registry $coreRegistry = null
    ) {
        $this->scopeConfig = $scopeConfig;
        $this->objectManager = $objectmanager;
        $this->coreRegistry = $coreRegistry ??
        $this->objectManager->get(\Magento\Framework\Registry::class);
    }
    /**
     * ArroundGetAvailableViewMode
     *
     * @param ShowProductMode $subject
     * @param callable $proceed
     *
     * @return array
     * @throws NoSuchEntityException
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @SuppressWarnings(Unused)
     */
    public function aroundGetAvailableViewMode(ShowProductMode $subject, callable $proceed)
    {
        $value = '';
        $currentCategory = $this->coreRegistry->registry('current_category');
        if (!empty($currentCategory)) {
            $value = $currentCategory->getShowMode();
        } else {
            $value = "list-grid";
        }
        if ($value == "list" || $value == "list-grid") {
            $value = "list-grid";
        } elseif ($value == "grid" || $value == "grid-list") {
            $value = "grid-list";
        } else {
            $value = '';
        }
        if (empty($value)) {
            $value = $this->scopeConfig->getValue(
                self::XML_PATH_LIST_MODE,
                \Magento\Store\Model\ScopeInterface::SCOPE_STORE
            );
        }
        switch ($value) {
            case 'grid':
                $availableMode = ['grid' => __('Grid') ];
                break;
            case 'list':
                $availableMode = ['list' => __('List') ];
                break;
            case 'grid-list':
                $availableMode = ['grid' => __('Grid'), 'list' => __('List') ];
                break;
            case 'list-grid':
                $availableMode = ['list' => __('List'), 'grid' => __('Grid') ];
                break;
            default:
                $availableMode = 'null';
                break;
        }
        return $availableMode;
    }
}
