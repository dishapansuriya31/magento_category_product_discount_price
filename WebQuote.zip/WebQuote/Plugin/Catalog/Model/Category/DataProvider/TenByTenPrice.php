<?php
/*
 *  Commercepundit
 *
 *  NOTICE OF LICENSE
 *
 * This source file is subject to the Commercepundit.com license that is
 * available through the world-wide-web at this URL:
 * http://commercepundit.com/license
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category   Commercepundit
 * @package    Commercepundit_Customer
 * @copyright  Copyright (c) Commercepundit (http://www.commercepundit.com/)
 * @license    http://www.commercepundit.com/LICENSE-1.0.html
 *
 */
namespace Commercepundit\WebQuote\Plugin\Catalog\Model\Category\DataProvider;

use Magento\Catalog\Model\Category\DataProvider;

class TenByTenPrice
{
    /**
     * Prepare meta.
     *
     * @param DataProvider $subject
     * @param array $result
     * @param array $meta
     * @return array
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function afterPrepareMeta(DataProvider $subject, array $result, array $meta): array
    {
        $result['cp_custom_category_group']['arguments']['data']['disabled'] = false;
        $result['cp_custom_category_group']['arguments']['data']['config']['componentType'] =
            \Magento\Ui\Component\Form\Fieldset::NAME;
        return $result;
    }
}
