<?php
/*
 *  Commercepundit
 *
 *  NOTICE OF LICENSE
 *
 * This source file is subject to the Commercepundit.com license that is
 * available through the world-wide-web at this URL:
 * http://commercepundit.com/license
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category   Commercepundit
 * @package    Commercepundit_Customer
 * @copyright  Copyright (c) Commercepundit (http://www.commercepundit.com/)
 * @license    http://www.commercepundit.com/LICENSE-1.0.html
 *
 */

namespace Commercepundit\WebQuote\Plugin\Catalog\Model\Category\DataProvider;

use Magento\Catalog\Model\Category\DataProvider;

class TenByPriceData
{
    /**
     * @var \Magento\Framework\Registry
     */
    protected $_registery;

    /**
     * @var \Commercepundit\WebQuote\Model\TenByTenPrice
     */
    protected $_tenByPrice;

    /**
     * @param \Magento\Framework\Registry $registry
     * @param \Commercepundit\WebQuote\Model\TenByTenPrice $tenByTenPrice
     */
    public function __construct(
        \Magento\Framework\Registry $registry,
        \Commercepundit\WebQuote\Model\TenByTenPrice $tenByTenPrice
    ) {
        $this->_registery = $registry;
        $this->_tenByPrice = $tenByTenPrice;
    }

    /**
     * Get ten by price data.
     *
     * @param DataProvider $subject
     * @param array $result
     * @return array
     * @throws \Magento\Framework\Exception\LocalizedException
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function afterGetData(DataProvider $subject, array $result): array
    {
        $category = $this->_registery->registry('category');
        $tenByPriceData = $this->_tenByPrice->getTenByPrice($category);
        if (!empty($tenByPriceData)) {
            $result[$category->getId()]['ten_by_price'] = $tenByPriceData;
        }
        return $result;
    }

    /**
     * Prepare meta.
     *
     * @param DataProvider $subject
     * @param array $result
     * @param array $meta
     * @return array
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function afterPrepareMeta(DataProvider $subject, array $result, array $meta): array
    {
        $result['cp_custom_category_group']['arguments']['data']['disabled'] = false;
        $result['cp_custom_category_group']['arguments']['data']['config']['componentType'] =
            \Magento\Ui\Component\Form\Fieldset::NAME;
        return $result;
    }
}
