<?php
/*
 * <!--
 * *
 *  * Commercepundit
 *  *
 *  * NOTICE OF LICENSE
 *  *
 *  * This source file is subject to the Commercepundit.com license that is
 *  * available through the world-wide-web at this URL:
 *  * http://commercepundit.com/license
 *  *
 *  * DISCLAIMER
 *  *
 *  * Do not edit or add to this file if you wish to upgrade this extension to newer
 *  * version in the future.
 *  *
 *  * @category   Commercepundit
 *  * @package    Commercepundit_Customer
 *  * @copyright  Copyright (c) Commercepundit (http://www.commercepundit.com/)
 *  * @license    http://www.commercepundit.com/LICENSE-1.0.html
 *
 * -->
 */

namespace Commercepundit\WebQuote\Plugin\Catalog\Controller\Adminhtml\Category;

use Magento\Catalog\Controller\Adminhtml\Category\Save;
use Magento\Framework\Controller\ResultInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Message\ManagerInterface as MessageManagerInterface;

class SavePlugin
{
    /**
     * @var \Commercepundit\WebQuote\Model\TenByTenPriceFactory
     */
    protected $_tenByTenFactory;

    /**
     * @var \Commercepundit\WebQuote\Model\ResourceModel\TenByTenPriceFactory
     */
    protected $_tenByResource;

    /**
     * @var MessageManagerInterface
     */
    protected $messageManger;
    /**
     * @param \Commercepundit\WebQuote\Model\TenByTenPriceFactory $tenByTenPriceFactory
     * @param \Commercepundit\WebQuote\Model\ResourceModel\TenByTenPriceFactory $tenbytenfactoryResource
     * @param MessageManagerInterface $messageManager
     */
    public function __construct(
        \Commercepundit\WebQuote\Model\TenByTenPriceFactory $tenByTenPriceFactory,
        \Commercepundit\WebQuote\Model\ResourceModel\TenByTenPriceFactory $tenbytenfactoryResource,
        MessageManagerInterface $messageManager
    ) {
        $this->_tenByTenFactory = $tenByTenPriceFactory;
        $this->_tenByResource = $tenbytenfactoryResource;
        $this->messageManger = $messageManager;
    }

    /**
     * Save data.
     *
     * @param Save $subject
     * @param ResultInterface $result
     * @return ResultInterface
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function afterExecute(Save $subject, ResultInterface $result): ResultInterface
    {
        $data = $subject->getRequest()->getParam('ten_by_price') ?? [];
        $categoryId = $subject->getRequest()->getParam('entity_id') ?? '';
        if ($categoryId) {
            try {
                $this->_tenByTenFactory->create()->saveTenByPriceData($data, $categoryId);
            } catch (LocalizedException $e) {
                $this->messageManger->addError($e->getMessage());
            }
        }
        return $result;
    }
}
