<?php
/**
 * Commercepundit
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Commercepundit.com license that is
 * available through the world-wide-web at this URL:
 * http://commercepundit.com/license
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category   Commercepundit
 * @package    Commercepundit_WebQuote
 * @copyright  Copyright (c) Commercepundit (http://www.commercepundit.com/)
 * @license    http://www.commercepundit.com/LICENSE-1.0.html
 */

namespace Commercepundit\WebQuote\Plugin\Model\Quote;

use Commercepundit\Countertops\Helper\Data as CountertopsHelper;
use Magento\Store\Model\ScopeInterface;
use Commercepundit\General\Model\Config\Source\Boolean;
use Magento\Framework\App\Config\ScopeConfigInterface;

class Item
{
    /**
     * @var ScopeConfigInterface
     */
    protected $scopeConfig;

    /**
     * Add to cart observer constructor.
     *
     * @param ScopeConfigInterface $scopeConfig
     */
    public function __construct(
        ScopeConfigInterface $scopeConfig
    )
    {
        $this->scopeConfig = $scopeConfig;
    }

    /**
     * After Represent Product
     *
     * @param \Magento\Quote\Model\Quote\Item $subject
     * @param \Closure $proceed
     * @param $product
     * @return boolean
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function aroundRepresentProduct(
        \Magento\Quote\Model\Quote\Item $subject,
        \Closure                        $proceed,
                                        $product
    )
    {
        $countertopsId = $this->scopeConfig->getValue(
            CountertopsHelper::COUNTERTOPS_ID_PATH,
            ScopeInterface::SCOPE_STORE,
            $subject->getStoreId()
        );
        if ($subject->getCabinetLineId() == $countertopsId
            && $subject->getIsSample() == Boolean::YES) {
            return $proceed($product);
        }
        return false;
    }

    /**
     * After compare
     *
     * @param \Magento\Quote\Model\Quote\Item $subject
     * @param \Closure $proceed
     * @param $item
     * @return boolean
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function aroundCompare(
        \Magento\Quote\Model\Quote\Item $subject,
        \Closure                        $proceed,
                                        $item
    )
    {
        $countertopsId = $this->scopeConfig->getValue(
            CountertopsHelper::COUNTERTOPS_ID_PATH,
            ScopeInterface::SCOPE_STORE,
            $subject->getStoreId()
        );
        if ($subject->getCabinetLineId() == $countertopsId
            && $subject->getIsSample() == Boolean::YES) {
            return $proceed($item);
        }
        return false;
    }
}
