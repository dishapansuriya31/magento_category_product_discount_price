<?php
/*
 * Commercepundit
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Commercepundit.com license that is
 * available through the world-wide-web at this URL:
 * http://commercepundit.com/license
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category   Commercepundit
 * @package    Commercepundit_WebQuote
 * @copyright  Copyright (c) Commercepundit (http://www.commercepundit.com/)
 * @license    http://www.commercepundit.com/LICENSE-1.0.html
 *
 *
 */

namespace Commercepundit\WebQuote\Controller\Widget;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Action\HttpGetActionInterface;
use Magento\Framework\App\Action\HttpPostActionInterface;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\Json\Helper\Data as JsonHelper;

/**
 * class FilterRequest For Handle widget Filter request.
 */
class FilterRequest extends Action implements HttpPostActionInterface, HttpGetActionInterface
{
    /**
     * @var JsonHelper
     */
    protected $jsonHelper;

    /**
     * @param Context $context
     * @param JsonHelper $jsonHelper
     */
    public function __construct(
        Context    $context,
        JsonHelper $jsonHelper
    ) {
        parent::__construct($context);
        $this->jsonHelper = $jsonHelper;
    }

    /**
     * Execute.
     */
    public function execute()
    {
        $params = $this->getRequest()->getContent();
        if (!empty($params)) {
            $params = $this->jsonHelper->jsonDecode($params);
            $layout = $this->_view->getLayout();
            $block = $layout->createBlock(\Commercepundit\WebQuote\Block\Widget\CabinetList::class);
            $filter = $params['filter_orig'] ?? [];
            if (isset($params['filter_request']) && !empty($params['filter_request'])) {
                $filter = array_merge($filter, $params['filter_request']);
            }
            $filterReq = $params['filter_request'] ?? [];
            $block->setData($filter);
            $block->setData("filter_request", $filterReq);
            $block->setData("is_filter_request", true);
            $block->setTemplate('Commercepundit_WebQuote::widget/cabinetLanding.phtml');
            $result = [
                'category' => $block->toHtml()
            ];
            return $this->getResponse()->representJson($this->jsonHelper->jsonEncode($result));
        }
        $result = $this->resultFactory->create(ResultFactory::TYPE_JSON);
        return $result->setData(null);
    }
}
