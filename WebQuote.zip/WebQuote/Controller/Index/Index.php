<?php
/**
 * Commercepundit
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Commercepundit.com license that is
 * available through the world-wide-web at this URL:
 * http://commercepundit.com/license
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category   Commercepundit
 * @package    Commercepundit_WebQuote
 * @copyright  Copyright (c) Commercepundit (http://www.commercepundit.com/)
 * @license    http://www.commercepundit.com/LICENSE-1.0.html
 */
namespace Commercepundit\WebQuote\Controller\Index;

use Commercepundit\WebQuote\Helper\Data as WebQuoteHelper;
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\HttpGetActionInterface as HttpGetActionInterface;

class Index extends Action implements HttpGetActionInterface
{

    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    protected $resultPageFactory;

    /**
     * @var WebQuoteHelper $webQuoteHelper
     */
    protected $webQuoteHelper;

    /**
     * Constructor
     *
     * @param \Magento\Framework\App\Action\Context      $context
     * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     * @param WebQuoteHelper                             $webQuoteHelper
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        WebQuoteHelper $webQuoteHelper
    ) {
        $this->resultPageFactory = $resultPageFactory;
        $this->webQuoteHelper      = $webQuoteHelper;
        parent::__construct($context);
    }

    /**
     * Execute
     */
    public function execute()
    {
        $resultPage = $this->resultPageFactory->create();
        $metaTitle = $this->webQuoteHelper->getCatalogMetaTitle();
        $metaDescription = $this->webQuoteHelper->getCatalogMetaDescription();
        $resultPage->getConfig()->getTitle()->set($metaTitle);
        $resultPage->getConfig()->setDescription($metaDescription);
        if ($this->getRequest()->getFrontName() == 'cpwebquote'){
            $this->_view->getPage()->getConfig()->setRobots('NOINDEX,NOFOLLOW');
        }
        return $resultPage;
    }
}
