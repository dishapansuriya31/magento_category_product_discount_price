<?php
/**
 * @package Commercepundit Ordersample
 * @copyright Copyright (c) 2018 Commercepundit
 * @license http://opensource.org/licenses/gpl-3.0.html GNU General Public License,version 3 (GPL-3.0)
 * @author Commercepundit
 */
namespace Commercepundit\WebQuote\Controller\Index;

use Magento\Catalog\Model\CategoryFactory;
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\HttpGetActionInterface as HttpGetActionInterface;
use Magento\Framework\App\Action\HttpPostActionInterface as HttpPostActionInterface;
use Magento\Framework\View\Result\PageFactory;
class CategoryGallery extends Action implements HttpGetActionInterface, HttpPostActionInterface
{
    /**
     * @var \Magento\Framework\Controller\Result\JsonFactory
     */
    protected $resultJsonFactory;

    /**
     * @var PageFactory
     */
    protected $_resultPageFactory;


    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
        PageFactory $resultPageFactory
    ) {
        $this->resultJsonFactory = $resultJsonFactory;
        $this->_resultPageFactory = $resultPageFactory;
        parent::__construct($context);
    }

    /**
     * Execute
     *
     * @return object
     */
    public function execute()
    {
        $result = [];
        $catId = $this->getRequest()->getParam('catid');
        if ($catId){
            $resultPage = $this->_resultPageFactory->create();
            $blockOutput = $resultPage->getLayout()
                ->createBlock('Commercepundit\WebQuote\Block\Category\ListCabinets')
                ->setTemplate('Commercepundit_WebQuote::Category/galleries.phtml')
                ->setData('cat_id',$catId)
                ->toHtml();
            if ($blockOutput){
                $result = [
                    "success" => true,
                    "html"    => $blockOutput
                ];
            }else{
                $result = [
                    "success" => false,
                    "html"    => ''
                ];
            }
        }
        $resultJson = $this->resultJsonFactory->create();
        $resultJson->setData($result);
        return $resultJson;
    }
}
