<?php

/**
 * Commercepundit
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Commercepundit.com license that is
 * available through the world-wide-web at this URL:
 * http://commercepundit.com/license
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category   Commercepundit
 * @package    Commercepundit_WebQuote
 * @copyright  Copyright (c) Commercepundit (http://www.commercepundit.com/)
 * @license    http://www.commercepundit.com/LICENSE-1.0.html
 */

namespace Commercepundit\WebQuote\Controller\Index;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Action\HttpGetActionInterface as HttpGetActionInterface;
use Magento\Framework\App\Action\HttpPostActionInterface as HttpPostActionInterface;
use Magento\Framework\Controller\Result\JsonFactory;
use Commercepundit\WebQuote\Helper\Data as WebQuoteHelper;
use Magento\Catalog\Model\Product\Attribute\Source\Status;

/**
 * Custom Tabs controller
 *
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class ShowCustomTabs extends Action implements HttpGetActionInterface, HttpPostActionInterface
{
    /**
     * @var JsonFactory
     */
    protected $_resultJsonFactory;

    /**
     * @var \Commercepundit\WebQuote\Block\Category\ListCabinets
     */
    protected $listcabinets;

    /**
     * @var \Magento\Catalog\Model\Category
     */
    protected $category;

    /**
     * Zipcode constructor.
     *
     * @param Context $context
     * @param JsonFactory $resultJsonFactory
     * @param \Commercepundit\WebQuote\Block\Category\ListCabinets $listcabinets
     * @param \Magento\Catalog\Model\Category $category
     */
    public function __construct(
        Context $context,
        JsonFactory $resultJsonFactory,
        \Commercepundit\WebQuote\Block\Category\ListCabinets $listcabinets,
        \Magento\Catalog\Model\Category $category
    ) {
        parent::__construct($context);
        $this->_resultJsonFactory = $resultJsonFactory;
        $this->listcabinets = $listcabinets;
        $this->category = $category;
    }
    /**
     * @return string
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @SuppressWarnings(PHPMD.NPathComplexity)
     */
    public function execute()
    {
        $fourthlevelcategory = \Commercepundit\WebQuote\Block\Category\ListCabinets::CATEGORY_LEVEL_4;
        $fifthlevelcategory = \Commercepundit\WebQuote\Block\Category\ListCabinets::CATEGORY_LEVEL_5;
        $result = $this->_resultJsonFactory->create();
        $tabsId = $this->getRequest()->getParam('id');
        $currentCategory = $this->category->load($this->getRequest()->getParam('catid'));
        $json = [];
        if($tabsId == 'specification'){
            $styleData = [];
            $specification = null;
            if(!empty($currentCategory->getSpecification())) {
                $specification = $currentCategory->getSpecification();
            } elseif($currentCategory->getLevel() != $fourthlevelcategory && $currentCategory->getParentCategory() && !empty($currentCategory->getParentCategory()->getSpecification())) {
                $specification = $currentCategory->getParentCategory()->getSpecification();
            } else {
                $styleData = $this->listcabinets->getStyleSpecifications($currentCategory->getStyleId() ?? 0);
                if(!empty($styleData['door_spec'])) {
                    $specification .= "<h4>Door</h4>";
                    $specification .= $styleData['door_spec'];
                }
                if(!empty($styleData['drawer_spec'])) {
                    $specification .= "<h4>Drawer</h4>";
                    $specification .= $styleData['drawer_spec'];
                }
                if(!empty($styleData['cabinetbox_spec'])) {
                    $specification .= "<h4>Box</h4>";
                    $specification .= $styleData['cabinetbox_spec'];
                }
                if(!empty($styleData['details_spec'])) {
                    $specification .= "<h4>Details</h4>";
                    $specification .= $styleData['details_spec'];
                }
            }
            if($specification != null){
                $specification = $this->listcabinets->getWysiwygContent($specification);
            }
            $json['message'] = $specification;
        }
        if($tabsId == 'cabinet-terms'){
            $styleData = [];
            $styleData = $this->listcabinets->getStyleSpecifications($currentCategory->getStyleId() ?? 0);
            if (isset($styleData['assembly_video']) && !empty($styleData['assembly_video'])) {
                $json['message'] = $this->listcabinets->getWysiwygContent($styleData['assembly_video']);
            }
            if(!empty($currentCategory->getCabinetTerms())){
                $json['message'] = $currentCategory->getCabinetTerms();
            }
        }
        if($tabsId == 'cabinet-terms-video'){
            $styleData = [];
            $styleData = $this->listcabinets->getStyleSpecifications($currentCategory->getStyleId() ?? 0);
            if (isset($styleData['details_assembly']) && !empty($styleData['details_assembly'])) {
                $json['message'] = $this->listcabinets->getWysiwygContent($styleData['details_assembly']);
            }
        }
        if($tabsId == 'additional-info'){
            $attachmentUrl = null;
            if($currentCategory->getIsActive() == Status::STATUS_ENABLED && ($currentCategory->getLevel() == $fourthlevelcategory || $currentCategory->getLevel() == $fifthlevelcategory)) {
                $parentId = $currentCategory->getParentId();
                $categoriesData = $this->listcabinets->getCategoryDataByCategoryId($parentId);
                $cabinetLineId = $currentCategory->getCabinetline();
                if(empty($cabinetLineId)) {
                    $cabinetLineId = reset($categoriesData)['cabinetline'];
                }
                $cabinetLineData = $this->listcabinets->getCabinetLineData($cabinetLineId);
                if(!empty($cabinetLineData['pdf_attachment'])){
                    $attachmentUrl = $this->listcabinets->getMediaUrl().$cabinetLineData['pdf_attachment'];
                }
            }
            if($attachmentUrl) {
                $json['message'] = '<h3>Download Construction Spec Sheet</h3><button class="download-attachment" download><a href="' . $attachmentUrl . '"> Download Spec Sheet Pdf </a></button>';
            }
        }
        $json['tabid'] = $tabsId;
        return $result->setData($json);
    }
}
