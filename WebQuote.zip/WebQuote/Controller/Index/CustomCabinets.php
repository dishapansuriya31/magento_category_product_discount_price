<?php
/**
 * @package Commercepundit Ordersample
 * @copyright Copyright (c) 2018 Commercepundit
 * @license http://opensource.org/licenses/gpl-3.0.html GNU General Public License,version 3 (GPL-3.0)
 * @author Commercepundit
 */
namespace Commercepundit\WebQuote\Controller\Index;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\HttpGetActionInterface as HttpGetActionInterface;
use Magento\Framework\App\Action\HttpPostActionInterface as HttpPostActionInterface;

/**
 * Check Customer is login
 */
class CustomCabinets extends Action implements HttpGetActionInterface, HttpPostActionInterface
{
    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    protected $resultPageFactory;

    /**
     * @var \Magento\Framework\Controller\Result\JsonFactory
     */
    protected $resultJsonFactory;

    /**
     * Constructor
     *
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     * @param \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context
    ) {
        parent::__construct($context);
    }

    /**
     * Execute
     *
     * @return object
     */
    public function execute()
    {
        $filteredRequest = $this->getRequest()
            ->getParam("filterRequest") ?? [];
        $categoryId = $this->getRequest()
            ->getParam("categoryId") ?? null;
        $layout = $this->_view->getLayout();
        $block = $layout->createBlock(\Commercepundit\WebQuote\Block\Category\ListCabinets::class);
        $block->setTemplate('Commercepundit_WebQuote::Category/custom_cabinets_landing.phtml');
        $block->setFilteredData($filteredRequest);
        $block->setCategoryId($categoryId);
        return $this->getResponse()->setBody($block->toHtml());
    }
}
