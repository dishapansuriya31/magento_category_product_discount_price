<?php
/**
 * Commercepundit
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Commercepundit.com license that is
 * available through the world-wide-web at this URL:
 * http://commercepundit.com/license
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category   Commercepundit
 * @package    Commercepundit_WebQuote
 * @copyright  Copyright (c) Commercepundit (http://www.commercepundit.com/)
 * @license    http://www.commercepundit.com/LICENSE-1.0.html
 */
namespace Commercepundit\WebQuote\Controller\Index;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\HttpGetActionInterface as HttpGetActionInterface;
use Magento\Framework\App\ResourceConnection;
use Psr\Log\LoggerInterface;

class Categorydescription extends Action implements HttpGetActionInterface
{

    /**
     * @var ResourceConnection
     */
    protected $resource;

    /**
     * @var \Magento\Catalog\Model\CategoryFactory
     */
    protected $categoryFactory;

    /**
     * @var \Magento\Framework\App\Filesystem\DirectoryList
     */
    protected $_dir;

    /**
     * @var \Magento\Framework\Controller\Result\RawFactory
     */
    protected $resultRawFactory;

    /**
     * @var \Magento\Framework\Filesystem\Driver\File
     */
    protected $file;

    /**
     * CSV Processor
     *
     * @var \Magento\Framework\File\Csv
     */
    protected $csvProcessor;

    /**
     * @var LoggerInterface
     */
    private $logger;

    /**
     * Constructor
     *
     * @param ResourceConnection $resource
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Catalog\Model\CategoryFactory $categoryFactory
     * @param \Magento\Framework\Filesystem\DirectoryList $dir
     * @param \Magento\Framework\Controller\Result\RawFactory $resultRawFactory
     * @param \Magento\Framework\Filesystem\Driver\File $file
     * @param \Magento\Framework\File\Csv $csvProcessor
     * @param LoggerInterface $logger
     * @return string
     */
    public function __construct(
        ResourceConnection $resource,
        \Magento\Framework\App\Action\Context $context,
        \Magento\Catalog\Model\CategoryFactory $categoryFactory,
        \Magento\Framework\Filesystem\DirectoryList $dir,
        \Magento\Framework\Controller\Result\RawFactory $resultRawFactory,
        \Magento\Framework\Filesystem\Driver\File $file,
        \Magento\Framework\File\Csv $csvProcessor,
        LoggerInterface $logger
    ) {
        $this->resource = $resource;
        $this->categoryFactory = $categoryFactory;
        $this->_dir = $dir;
        $this->resultRawFactory = $resultRawFactory;
        $this->file = $file;
        $this->csvProcessor = $csvProcessor;
        $this->logger = $logger;
        parent::__construct($context);
    }

    /**
     * Execute
     */
    public function execute()
    {
        $result = $this->resultRawFactory->create();
        $connection = $this->resource->getConnection();
        $select_Allcategory = $connection->select()
            ->from(
                ['ccev' => 'catalog_category_entity'],
                ['row_id','path']
            );

        $data_Allcategory = $connection->fetchAll($select_Allcategory);
        $categoryNameId = [];

        foreach ($data_Allcategory as $categoryPath) {
            if ($categoryPath['row_id']!=="1" && $categoryPath['row_id']!=="2") {
                $categorypath = $categoryPath['path'];
                $categorypath = str_replace('1/2', '', $categorypath);
                $categoryIds = explode("/", $categorypath);
                $categoryIds = array_filter($categoryIds);

                $categoryfullname = "Default Category";
                foreach ($categoryIds as $cat_id) {
                    $category = $this->categoryFactory->create()->load($cat_id);
                    $categoryfullname .= "/" . $category->getName();
                }
                $categoryNameId[$categoryfullname] = $categoryPath['row_id'];
            }
        }

        $filename = $this->_dir->getPath('var') . '/categories.csv';

        if ($this->file->isExists($filename)) {
            $arrayFromCSV = $this->csvProcessor->getData($filename);
            $writer = new \Laminas\Log\Writer\Stream(BP . '/var/log/import_category_description.log');
            $logger = new \Laminas\Log\Logger();
            $logger->addWriter($writer);
            foreach ($arrayFromCSV as $csvData) {
                if (isset($categoryNameId[$csvData['0']])) {
                    $category_Id = $categoryNameId[$csvData['0']];
                    $category = $this->categoryFactory->create()->setStoreId(0)->load($category_Id);
                    $category->setDescription($csvData['1']);
                    try {
                        $category->save();
                        $logger->debug($category->getName() . ' => Done');
                    } catch (Exception $e) {
                        $logger->debug($category->getName() . ' => ' . $e->getMessage());
                        $this->logger->critical($e->getMessage());
                    }
                } else {
                    $logger->debug('Category not exits start');
                    $logger->debug($csvData);
                    $logger->debug('Category not exits end');
                }
            }
            $result->setContents('<strong>Description updated successfully.</strong>');
        } else {
            $result->setContents('<strong>categories.csv file not found in var directory.</strong>');
        }
        return $result;
    }
}
