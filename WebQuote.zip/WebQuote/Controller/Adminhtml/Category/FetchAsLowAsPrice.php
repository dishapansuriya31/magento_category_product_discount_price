<?php
/*
 *  Commercepundit
 *
 *  NOTICE OF LICENSE
 *
 * This source file is subject to the Commercepundit.com license that is
 * available through the world-wide-web at this URL:
 * http://commercepundit.com/license
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category   Commercepundit
 * @package    Commercepundit_WebQuote
 * @copyright  Copyright (c) Commercepundit (http://www.commercepundit.com/)
 * @license    http://www.commercepundit.com/LICENSE-1.0.html
 *
 */

namespace Commercepundit\WebQuote\Controller\Adminhtml\Category;

use Commercepundit\WebQuote\Model\TenByTenPrice;
use Magento\Backend\App\Action\Context;
use Magento\Framework\App\Action\HttpGetActionInterface;
use Magento\Framework\App\Action\HttpPostActionInterface;
use Magento\Store\Model\StoreManagerInterface;
/**
 * class FetchAsLowAsPrice
 *
 * Update ten by price data.
 */
class FetchAsLowAsPrice extends \Magento\Backend\App\Action implements HttpGetActionInterface, HttpPostActionInterface
{
    /**
     * @var TenByTenPrice
     */
    protected $tenByTenPrice;

    /**
     * @var StoreManagerInterface
     */
    protected $storeManager;

    /**
     * @param Context $context
     * @param TenByTenPrice $tenByTenPrice
     * @param Registry $registry
     */
    public function __construct(
        Context $context,
        TenByTenPrice $tenByTenPrice,
        StoreManagerInterface $storeManager
    ) {
        parent::__construct($context);
        $this->tenByTenPrice = $tenByTenPrice;
        $this->storeManager = $storeManager;
    }

    /**
     * Execute
     */
    public function execute()
    {
        $store = $this->getRequest()->getParam('store');
        if ((int)$store) {
            $storeId = $this->storeManager->getStore($store)->getId();
        } else {
            $storeId = $this->storeManager->getStore()->getId();
        }
        $categoryId = (int)$this->getRequest()->getParam('category_id');
        try {
            if ($categoryId > 0) {
                $this->tenByTenPrice->fetchAsLowAsPrice($categoryId,$storeId);
                $this->messageManager->addSuccess('As Low As Price data successfully updated.');
            }
        } catch (\Exception $e) {
            $this->messageManager->addError($e->getMessage());
        }
        return $this->_redirect('catalog/category/edit', ['_current' => true, 'id' => $categoryId]);
    }
}
