<?php
namespace Commercepundit\WebQuote\Controller\Adminhtml\Category;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Commercepundit\WebQuote\Model\TenByTenPriceFactory;
use Magento\Framework\Controller\ResultFactory;
use Psr\Log\LoggerInterface;
use Magento\Framework\App\ResourceConnection;
use Magento\Framework\Session\SessionManagerInterface;

class Submit extends Action
{
    /**
     * @var TenByTenPriceFactory
     */
    protected $tenByTenPriceFactory;

    /**
     * @var LoggerInterface
     */
    protected $logger;

    /**
     * @var ResourceConnection
     */
    protected $resource;

    /**
     * @var SessionManagerInterface
     */
    protected $session;

    /**
     * @param Context $context
     * @param TenByTenPriceFactory $tenByTenPriceFactory
     * @param LoggerInterface $logger
     * @param ResourceConnection $resource
     * @param SessionManagerInterface $session
     */
    public function __construct(
        Context $context,
        TenByTenPriceFactory $tenByTenPriceFactory,
        LoggerInterface $logger,
        ResourceConnection $resource,
        SessionManagerInterface $session
    ) {
        $this->tenByTenPriceFactory = $tenByTenPriceFactory;
        $this->logger = $logger;
        $this->resource = $resource;
        $this->session = $session;
        parent::__construct($context);
    }

    public function execute()
    {
        $params = $this->getRequest()->getParams();

        if (!empty($params)) {
            try {
                // Retrieve data from $params array
                $categoryIds = isset($params['selected_category_ids']) ? explode(',', $params['selected_category_ids']) : [];
                $discountInput = isset($params['discount_input']) ? (float) $params['discount_input'] : 0.0;
                $customerGroups = isset($params['customer_group']) ? $params['customer_group'] : [];

                // Get database connection
                $connection = $this->resource->getConnection();
                $tableName = $connection->getTableName('cp_ten_by_ten_price'); 

                // Ensure data is processed correctly
                foreach ($categoryIds as $categoryId) {
                    foreach ($customerGroups as $customerGroupId) {
                        // Check if the record exists
                        $select = $connection->select()
                            ->from($tableName)
                            ->where('entity_id = ?', $categoryId) // Assuming category_id and entity_id are the same
                            ->where('customer_group_id = ?', $customerGroupId);
                        $result = $connection->fetchRow($select);

                        if ($result) {
                          
                            $regularPrice = $result['regular_price'];

                            
                            $discountPrice = ($discountInput > 0) ? $regularPrice - ($regularPrice * ($discountInput / 100)) : $regularPrice;

                           
                            $updateData = ['discount_price' => $discountPrice];
                            $where = ['value_id = ?' => $result['value_id']];
                            $connection->update($tableName, $updateData, $where);
                        }
                    }
                }

                $this->messageManager->addSuccessMessage(__('Discount prices have been updated successfully.'));
            } catch (\Exception $e) {
                $this->logger->error('Error occurred while updating discount prices: ' . $e->getMessage());
                $this->messageManager->addErrorMessage(__('Error occurred while updating discount prices: ' . $e->getMessage()));
            }
        } else {
            $this->logger->error('No data received.');
            $this->messageManager->addErrorMessage(__('No data received.'));
        }

        // Redirect back to the form page
        $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
        $resultRedirect->setUrl($this->_redirect->getRefererUrl());
        return $resultRedirect;
    }

    /**
     * Validate form key
     *
     * @param string $formKey
     * @return bool
     */
    private function isValidFormKey($formKey)
    {
        return $formKey === $this->session->getFormKey();
    }
}
