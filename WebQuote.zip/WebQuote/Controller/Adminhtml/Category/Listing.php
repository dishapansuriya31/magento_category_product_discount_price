<?php

namespace Commercepundit\WebQuote\Controller\Adminhtml\Category;


use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;

class Listing extends Action
{
    /**
     * @var PageFactory
     */
    protected $resultPageFactory;

   

    public function __construct(Context $context, PageFactory $resultPageFactory)
    {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
    }

    /**
     * Execute action
     */
    public function execute()
    {
        $resultPage = $this->resultPageFactory->create();
        $resultPage->getConfig()->getTitle()->prepend(__('Category Listings'));

       
        return $resultPage;
    }
}
