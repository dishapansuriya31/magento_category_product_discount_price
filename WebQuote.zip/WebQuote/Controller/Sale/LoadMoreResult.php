<?php
/**
 * @package Commercepundit WebQuote
 * @copyright Copyright (c) 2018 Commercepundit
 * @license http://opensource.org/licenses/gpl-3.0.html GNU General Public License,version 3 (GPL-3.0)
 * @author Commercepundit
 */
namespace Commercepundit\WebQuote\Controller\Sale;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\HttpPostActionInterface as HttpPostActionInterface;
use Magento\Framework\View\Result\PageFactory;
class LoadMoreResult extends Action implements HttpPostActionInterface
{
    /**
     * @var \Magento\Framework\Controller\Result\JsonFactory
     */
    protected $resultJsonFactory;

    /**
     * @var PageFactory
     */
    protected $_resultPageFactory;

    /**
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory
     * @param PageFactory $resultPageFactory
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
        PageFactory $resultPageFactory
    ) {
        $this->resultJsonFactory = $resultJsonFactory;
        $this->_resultPageFactory = $resultPageFactory;
        parent::__construct($context);
    }

    /**
     * Execute
     *
     * @return object
     */
    public function execute()
    {
        $result = [];
        $catId = $this->getRequest()->getParam('cat_id');
        if ($catId){
            $resultPage = $this->_resultPageFactory->create();
            $pageType = $this->getRequest()->getParam('page_identifier');
            switch ($pageType) {
                case 'custom_cabinet':
                    $blockOutput = $resultPage->getLayout()
                        ->createBlock(\Commercepundit\WebQuote\Block\Sale\ShowAllProduct::class)
                        ->setTemplate('Commercepundit_WebQuote::sale/custom_cabinets.phtml')
                        ->setData('category_id',$catId)
                        ->toHtml();
                    break;
                case 'wood_range_hoods':
                    $blockOutput = $resultPage->getLayout()
                        ->createBlock(\Commercepundit\WebQuote\Block\Sale\ShowAllProduct::class)
                        ->setTemplate('Commercepundit_WebQuote::sale/wood_range_hoods.phtml')
                        ->setData('category_id',$catId)
                        ->toHtml();
                    break;
                case 'rev_a_shelf':
                    $blockOutput = $resultPage->getLayout()
                        ->createBlock(\Commercepundit\WebQuote\Block\Sale\ShowAllProduct::class)
                        ->setTemplate('Commercepundit_WebQuote::sale/rev_a_shelf.phtml')
                        ->setData('category_id',$catId)
                        ->toHtml();
                    break;
                case 'countertops':
                    $blockOutput = $resultPage->getLayout()
                        ->createBlock(\Commercepundit\WebQuote\Block\Sale\ShowAllProduct::class)
                        ->setTemplate('Commercepundit_WebQuote::sale/countertops.phtml')
                        ->setData('category_id',$catId)
                        ->toHtml();
                    break;
                case 'richelieu':
                    $blockOutput = $resultPage->getLayout()
                        ->createBlock(\Commercepundit\WebQuote\Block\Sale\ShowAllProduct::class)
                        ->setTemplate('Commercepundit_WebQuote::sale/richelieu.phtml')
                        ->setData('category_id',$catId)
                        ->toHtml();
                    break;
                default :
                    $blockOutput = null;
            }
            if ($blockOutput){
                $result = [
                    "success" => true,
                    "html"    => $blockOutput
                ];
            }else{
                $result = [
                    "success" => false,
                    "html"    => ''
                ];
            }
        }
        $resultJson = $this->resultJsonFactory->create();
        $resultJson->setData($result);
        return $resultJson;
    }
}
