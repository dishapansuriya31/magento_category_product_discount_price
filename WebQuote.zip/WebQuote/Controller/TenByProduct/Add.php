<?php
/*
 *  Commercepundit
 *
 *  NOTICE OF LICENSE
 *
 * This source file is subject to the Commercepundit.com license that is
 * available through the world-wide-web at this URL:
 * http://commercepundit.com/license
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category   Commercepundit
 * @package    Commercepundit_Customer
 * @copyright  Copyright (c) Commercepundit (http://www.commercepundit.com/)
 * @license    http://www.commercepundit.com/LICENSE-1.0.html
 *
 */

namespace Commercepundit\WebQuote\Controller\TenByProduct;

use Magento\Catalog\Model\ProductRepository;
use Commercepundit\Checkout\Model\Cart;
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Action\HttpGetActionInterface;
use Magento\Framework\App\Action\HttpPostActionInterface;
use Magento\Framework\Controller\Result\Json;
use Magento\Framework\Controller\Result\Redirect;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\Data\Form\FormKey;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;

/**
 * class Add
 *
 * Add ten by kitchen products in cart.
 *
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class Add extends Action implements HttpPostActionInterface, HttpGetActionInterface
{
    /**
     * @var FormKey
     */
    protected $formKey;

    /**
     * @var Cart
     */
    protected $cart;

    /**
     * @var ProductRepository
     */
    protected $productRepository;

    /**
     * @param Context $context
     * @param FormKey $formKey
     * @param Cart $cart
     * @param ProductRepository $productRepository
     */
    public function __construct(
        Context           $context,
        FormKey           $formKey,
        Cart              $cart,
        ProductRepository $productRepository
    ) {
        parent::__construct($context);
        $this->formKey = $formKey;
        $this->cart = $cart;
        $this->productRepository = $productRepository;
    }

    /**
     * Execute.
     *
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * phpcs:disable Generic.Metrics.NestingLevel
     */
    public function execute()
    {
        $resultRedirect = $this->resultRedirectFactory->create();
        $_tenBySku = $this->getRequest()->getParam('ten_by_sku') != null ? trim($this->getRequest()->getParam('ten_by_sku')) : '';
        if (empty($_tenBySku)) {
            return $resultRedirect->setUrl($this->_redirect->getRefererUrl());
        }
        try {
            $isAjaxReq = false;
            if ($this->getRequest()->isXmlHttpRequest()) {
                $isAjaxReq = true;
            }
            $tenBySkus = explode(',', $_tenBySku);
            $items = [];
            foreach ($tenBySkus as $tenBySku) {
                try {
                    $product = $this->_initProduct($tenBySku);
                    if ($product && $product->getId()) {
                        $params = [
                            'form_key' => $this->formKey->getFormKey(),
                            'product' => $product,
                            'qty' => 1,
                        ];
                        $options = [];
                        if ($product->getHasOptions()) {
                            foreach ($product->getOptions() as $option) {
                                if ($option->getIsRequire()) {
                                    foreach ($option->getValues() as $value) {
                                        if ($value['mp_is_default']) {
                                            $options[$value['option_id']] = $value['option_type_id'];
                                        }
                                    }
                                }
                            }
                            $params['options'] = $options;
                        }
                        $items[] = $this->cart->addProduct($product, $params);
                    }
                } catch (LocalizedException $e) {
                    $this->messageManager->addErrorMessage(
                        $this->_objectManager->get(\Magento\Framework\Escaper::class)->escapeHtml(
                            __('%1 is Not Available.', $tenBySku))
                    );
                    continue;
                }
            }
            $this->cart->save()->getQuote()->collectTotals();
            $this->_eventManager->dispatch(
                'ten_by_ten_products_add_after',
                [
                    'items' => $items,
                    'controller_action' => $this
                ]
            );
            $this->messageManager->addComplexSuccessMessage(
                'addCartSuccessMessage',
                [
                    'product_name' => '10x10 Kitchen Products',
                    'cart_url' => $this->getCartUrl(),
                ]
            );
        } catch (LocalizedException $e) {
            $this->messageManager->addErrorMessage(
                $this->_objectManager->get(\Magento\Framework\Escaper::class)->escapeHtml($e->getMessage())
            );
        } catch (\Exception $e) {
            $this->messageManager->addExceptionMessage(
                $e,
                __('We can\'t add this 10x10 items to your shopping cart right now.')
            );
            $this->_objectManager->get(\Psr\Log\LoggerInterface::class)->critical($e);
        }
        return $this->resultRepsonse($isAjaxReq);
    }

    /**
     * Get product.
     *
     * @param string $sku
     * @return false|\Magento\Catalog\Api\Data\ProductInterface|\Magento\Catalog\Model\Product
     * @throws NoSuchEntityException
     */
    protected function _initProduct(string $sku)
    {
        if ($sku) {
            $storeId = $this->_objectManager->get(
                \Magento\Store\Model\StoreManagerInterface::class
            )->getStore()->getId();
            try {
                return $this->productRepository->get($sku, false, $storeId, true);
            } catch (NoSuchEntityException $e) {
                return false;
            }
        }
        return false;
    }

    /**
     * Returns cart url
     *
     * @return string
     */
    private function getCartUrl(): string
    {
        return $this->_url->getUrl('checkout/cart', ['_secure' => true]);
    }

    /**
     * Result response.
     *
     * @param bool $isAjaxReq
     * @return Json|Redirect
     */
    public function resultRepsonse($isAjaxReq = true)
    {
        if ($isAjaxReq) {
            return $this->goBack();
        } else {
            $resultRedirect = $this->resultRedirectFactory->create();
            $resultRedirect->setRefererOrBaseUrl();
            return $resultRedirect;
        }
    }

    /**
     * Get back url.
     *
     * @param string $backUrl
     * @return Json
     */
    protected function goBack($backUrl = null): Json
    {
        $resultJson = $this->resultFactory->create(ResultFactory::TYPE_JSON);
        $result = [];
        if ($backUrl) {
            $result['backUrl'] = $backUrl;
        }
        return $resultJson->setData($result);
    }
}
