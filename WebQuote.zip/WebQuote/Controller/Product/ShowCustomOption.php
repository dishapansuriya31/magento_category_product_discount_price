<?php

/**
 * Commercepundit
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Commercepundit.com license that is
 * available through the world-wide-web at this URL:
 * http://commercepundit.com/license
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category   Commercepundit
 * @package    Commercepundit_WebQuote
 * @copyright  Copyright (c) Commercepundit (http://www.commercepundit.com/)
 * @license    http://www.commercepundit.com/LICENSE-1.0.html
 */

namespace Commercepundit\WebQuote\Controller\Product;

use Commercepundit\WebQuote\Controller\ShowProductCustomOption as ShowProductCustomOptionController;
use Magento\Framework\App\Action\HttpGetActionInterface as HttpGetActionInterface;
use Magento\Framework\Controller\ResultFactory;

/**
 * Review controller
 *
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class ShowCustomOption extends ShowProductCustomOptionController implements HttpGetActionInterface
{
    /**
     * Execute List action
     */
    public function execute()
    {
        $resultLayout = $this->resultFactory->create(ResultFactory::TYPE_LAYOUT);
        $resultLayout->addHandle('catalog_product_view_type_' . $this->initProduct()->getTypeId());
        return $resultLayout;
    }
}
