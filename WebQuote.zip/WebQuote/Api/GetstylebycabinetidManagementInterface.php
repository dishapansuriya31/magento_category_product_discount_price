<?php
/**
 * Commercepundit
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Commercepundit.com license that is
 * available through the world-wide-web at this URL:
 * http://commercepundit.com/license
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category   Commercepundit
 * @package    Commercepundit_WebQuote
 * @copyright  Copyright (c) Commercepundit (http://www.commercepundit.com/)
 * @license    http://www.commercepundit.com/LICENSE-1.0.html
 */

namespace Commercepundit\WebQuote\Api;

/**
 * To Get Cabinet Styles.
 * @api
 * @since 100.0.2
 */
interface GetstylebycabinetidManagementInterface
{

    /**
     * POST for stylebycabinetid api
     *
     * @param mixed $filterRequest
     * @return array
     */
    public function stylebycabinetid($filterRequest = []);
}
