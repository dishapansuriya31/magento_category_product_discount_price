<?php
/**
 * Commercepundit
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Commercepundit.com license that is
 * available through the world-wide-web at this URL:
 * http://commercepundit.com/license
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category   Commercepundit
 * @package    Commercepundit_WebQuote
 * @copyright  Copyright (c) Commercepundit (http://www.commercepundit.com/)
 * @license    http://www.commercepundit.com/LICENSE-1.0.html
 */

namespace Commercepundit\WebQuote\Helper;

use Commercepundit\General\Model\Config\Source\Boolean;
use Magento\Customer\Model\Session as CustomerSession;
use Magento\Framework\App\Helper\Context;
use Magento\Framework\App\Http\Context as AuthContext;
use Magento\Framework\App\ResourceConnection;
use Magento\Framework\Data\Collection;
use Magento\Store\Model\ScopeInterface;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Catalog\Model\Product\OptionFactory as ProductOption;
use Yotpo\Yotpo\Model\Config as YotpoConfig;
use Commercepundit\Checkout\Helper\Data as CheckoutHelper;
use Commercepundit\Hoods\Helper\Data as HoodsHelper;
use Commercepundit\Countertops\Helper\Data as CountertopsHelper;
use Magento\Catalog\Model\ResourceModel\Category\CollectionFactory as CategoryCollectionFactory;
use Commercepundit\Product\Helper\Price as ProductPriceHelper;
use Bread\BreadCheckout\Helper\Data as BreadHelper;

/**
 * WebQuote helper.
 * Data Helper Webquote
 *
 * @SuppressWarnings(PHPMD.CookieAndSessionMisuse)
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 * @SuppressWarnings(PHPMD.ExcessiveParameterList)
 */
class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    /**
     * @const META_TITLE
     */
    public const META_TITLE = 'seo/web_quote_landing/meta_title';

    /**
     * @const META_DESCRITION
     */
    public const META_DESCRITION = 'seo/web_quote_landing/meta_description';

    /**
     * @const META_DESCRITION
     */
    public const NEW_CATEGORY_LABEL_DAYS = 'new_category_label_section/new_category_label_group/days';

    /**
     * @const DEFAULT_MODE
     */
    public const DEFAULT_MODE = 'list';

    /**
     * @const SIGNATURE_ID
     */
    public const SIGNATURE_ID = 'commercepundit_cabinets/signatureconfiguration/signature_id';

    /**
     * @const CABINET_ATTRIBUTE_CODE
     */
    public const CABINET_ATTRIBUTE_CODE = 'cabinet_line_id';

    /**
     * @const CABINET_STYLE_ID
     */
    public const CABINET_STYLE_ID = 'style_id';

    /**
     * @const CABINET_COLOR_ID
     */
    public const CABINET_COLOR_ID = 'color_id';

    /**
     * @const CATEGORY_NAME
     */
    public const CATEGORY_NAME = 'hide_category_slider_section/hide_category_slider/category_name';

    /**
    * @var REMOVE_ADDTOCART_CABINETS
    */
    public const REMOVE_ADDTOCART_CABINETS = 'commercepundit_cabinets/cabinetconfiguration/remove_addtocart_for_cabinets';

    /**
     * @const NEW_TAG
     */
    public const NEW_TAG = 'New';


    /**
     * @var StoreManagerInterface
     */
    protected $storeManager;

    /**
     * @var ProductOption
     */
    protected $productCustomOptions;

    /**
     * @var ResourceConnection
     */
    protected $resourceConnection;

    /**
     * @var CustomerSession
     */
    protected $customerSession;

    /**
     * @var AuthContext
     */
    protected $authContext;

    /**
     * @var YotpoConfig
     */
    protected $yotpoConfig;

    /**
     * @var CategoryCollectionFactory
     */
    protected $categoryCollectionFactory;

    /**
     * @var \Commercepundit\Product\Helper\Price
     */
    protected $productPriceHelper;

    /**
     * @var BreadHelper
     */
    protected $breadHelper;

    /**
     * @var array
     */
    protected $multiplierData = [];

    /**
     * @param Context                   $context
     * @param StoreManagerInterface     $storeManager
     * @param ProductOption             $productCustomOptions
     * @param CustomerSession           $customerSession
     * @param ResourceConnection        $resourceConnection
     * @param AuthContext               $authContext
     * @param YotpoConfig               $yotpoConfig
     * @param CategoryCollectionFactory $categoryCollectionFactory
     * @param ProductPriceHelper        $productPriceHelper
     * @param BreadHelper               $breadHelper
     */

    public function __construct(
        Context                     $context,
        StoreManagerInterface       $storeManager,
        ProductOption               $productCustomOptions,
        CustomerSession             $customerSession,
        ResourceConnection          $resourceConnection,
        AuthContext                 $authContext,
        YotpoConfig                 $yotpoConfig,
        CategoryCollectionFactory   $categoryCollectionFactory,
        ProductPriceHelper          $productPriceHelper,
        BreadHelper                 $breadHelper,
    ) {
        $this->storeManager                 = $storeManager;
        $this->productCustomOptions         = $productCustomOptions;
        $this->customerSession              = $customerSession;
        $this->resourceConnection           = $resourceConnection;
        $this->authContext                  = $authContext;
        $this->yotpoConfig                  = $yotpoConfig;
        $this->categoryCollectionFactory    = $categoryCollectionFactory;
        $this->productPriceHelper           = $productPriceHelper;
        $this->breadHelper                  = $breadHelper;
        parent::__construct($context);
    }

    /**
     * [getStoreId Function to get Current Store Id]
     *
     * @return [int] [Store id of Current Store]
     */
    public function getStoreId()
    {
        return $this->storeManager->getStore()->getId();
    }

    /**
     * Get Meta description from configuration
     *
     * @return [string|object]           [System Configuration of the Field Stored in Admin System Configuration]
     */
    public function getCatalogMetaDescription()
    {
        $storeId = $this->getStoreId();
        return $this->scopeConfig->getValue(
            self::META_DESCRITION,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
    }

    /**
     * Get Meta title from configuration
     *
     * @return [string|object]           [System Configuration of the Field Stored in Admin System Configuration]
     */
    public function getCatalogMetaTitle()
    {
        $storeId = $this->getStoreId();
        return $this->scopeConfig->getValue(
            self::META_TITLE,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
    }

    /**
     * GetProductCustomOptions
     *
     * @param object $product
     * @ return [object| array]
     */
    public function getProductCustomOptions($product)
    {
        $customOptions = $this->productCustomOptions->create()->getProductOptionCollection($product);
        return $customOptions;
    }

    /**
     * GetConfigData
     *
     * @param string $path
     * @ return string
     */
    public function getConfigData($path)
    {
        $value = $this->scopeConfig->getValue($path, \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
        return $value;
    }

    /**
     * Get Signature Id
     *
     * @ return string
     */
    public function getSignatureId()
    {
        return $this->getConfigData(self::SIGNATURE_ID);
    }

    /**
     * Get ten by price discount data.
     *
     * @param int $categoryId
     * @param int $customerGroupId
     * @param int $websiteId
     * @return mixed|null
     * @throws \Magento\Framework\Exception\LocalizedException
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     */
    public function getTenByPriceDiscountData(int $categoryId, int $customerGroupId = 0, int $websiteId = 0)
    {
        if ($categoryId) {
            if ($this->isCustomerLogin() && !$customerGroupId) {
                $customerGroupId = $this->customerSession->getCustomerGroupId();
            }
            $connection = $this->resourceConnection->getConnection();
            $select = $connection->select()
                ->from(
                    $connection->getTableName('cp_ten_by_ten_price'),
                    ['regular_price', 'discount_price', 'customer_group_id','as_low_as_price']
                )
                ->where('entity_id = ?', $categoryId)
                ->where('website_id = ?', $websiteId)
                ->where('all_groups = 1 OR customer_group_id = ?', $customerGroupId);
            $priceData = $connection->fetchRow($select);
            if (!empty($priceData) && ($priceData['regular_price'] > 0 && $priceData['discount_price'] > 0)) {
                $origPrice = (float)$priceData['regular_price'];
                $discountPrice = (float)$priceData['discount_price'];
                $percentage = ($origPrice - $discountPrice) / $origPrice * 100;
                $savePrice = ($origPrice - $discountPrice);
                $priceData['percentage'] = __('%1% off', round($percentage, 2));
                $priceData['save_price'] = $savePrice;
                return $priceData;
            }
        }
        return null;
    }

    /**
     * Get customer login status.
     *
     * @return bool
     */
    public function isCustomerLogin(): bool
    {
        return (bool)$this->authContext->getValue(\Magento\Customer\Model\Context::CONTEXT_AUTH);
    }

    /**
     * Public function getCustomerGroupId
     *
     * @ return null|int
     */
    public function getGroupId()
    {
        $customerGroup = null;
        if ($this->customerSession->isLoggedIn()) :
            $customerGroup = $this->customerSession->getCustomer()->getGroupId();
        endif;
        return $customerGroup;
    }

    /**
     * Get Compared Product Options
     *
     * @param array $options
     * @param object $product
     * @param object $connection
     * @return string
     */
    public function getComparedProductOption($options, $product, $connection)
    {
        $matchedProductOptions = [];
        $productoptions = [];
        $productoptions['optionprice'] = 0;
        foreach ($options['options'] as $option) {
            $select = $connection->select()->from(
                ['CPO' => $connection->getTableName('catalog_product_option')],
                ['']
            )->joinLeft(
                ['CPOTV' => $connection->getTableName('catalog_product_option_type_value')],
                'CPO.option_id = CPOTV.option_id',
                [
                    'option_id' => 'CPOTV.option_id',
                    'option_type_id' => 'CPOTV.option_type_id'
                ]
            )->joinLeft(
                ['CPOTT' => $connection->getTableName('catalog_product_option_type_title')],
                'CPOTV.option_type_id = CPOTT.option_type_id',
                ['']
            )->joinLeft(
                ['CPOT' => $connection->getTableName('catalog_product_option_title')],
                'CPOTV.option_id = CPOT.option_id',
                ['']
            )->joinLeft(
                ['potp' => $connection->getTableName('catalog_product_option_type_price')],
                'CPOTV.option_type_id = potp.option_type_id',
                ['option_price' => 'potp.price']
            )->where('CPO.product_id = ?', $product->getId())
                ->where('CPOTT.title IN (?) ', $option['value'])
                ->where('CPOT.title IN (?) ', $option['label']);
            $option = $connection->fetchRow($select);
            $optionId = $option['option_id'] ?? null;
            $optionTypeId = $option['option_type_id'] ?? null;
            $optionPrice = $option['option_price'] ?? null;
            $matchedProductOptions[$optionId] = $optionTypeId;
            $productoptions['options'] = $matchedProductOptions;
            $productoptions['optionprice'] += $optionPrice;
        }
        return $productoptions;
    }

    /**
     * Set Style Daya To Quote Items
     *
     * @param object $quoteItem
     * @param object $product
     * @return object
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @SuppressWarnings(PHPMD.NPathComplexity)
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    public function setStyleDataItems($quoteItem, $product, $countertopPrice)
    {
        $cabinetLineId = null;
        $mappingCabinetLineId = null;
        $cabinetLineName = null;
        $styleId = null;
        $styleName = null;
        $colorId = null;
        $colorName = null;
        $woodspeciesId = null;
        $woodspeciesName = null;
        $styleCode = null;
        $cartGroupKey = null;
        $vendorCostPrice = null;

        if ($product->getCabinetLineId() && trim($product->getCabinetLineId())) {
            $cabinetLines = explode(',', $product->getCabinetLineId());
            if (!empty($cabinetLines)) {
                $cabinetLineId = reset($cabinetLines);
                $mappingCabinetLineId = $cabinetLineId;
                $cabinetLineData = $this->getCabinet($mappingCabinetLineId);
                $cabinetLineName = $cabinetLineData['supplier'] ?? null;
                if (!empty($cabinetLineData['parent_cabinet_line_id']) &&
                    (int)$cabinetLineData['parent_cabinet_line_id'] > 0) {
                    $cabinetLineId = (int)$cabinetLineData['parent_cabinet_line_id'];
                }
            }
        }

        $hoodsCabinetId = (int)$this->scopeConfig->getValue(
            HoodsHelper::HOODS_CONFIG_XML_PATH,
            ScopeInterface::SCOPE_STORE
        );
        $countertopsId = $this->scopeConfig->getValue(
            CountertopsHelper::COUNTERTOPS_ID_PATH,
            ScopeInterface::SCOPE_STORE
        );
        if ($cabinetLineId == $hoodsCabinetId) {
            $mainprice = $quoteItem->getPrice();
            $cartGroupKey = CheckoutHelper::HOODS_CART_GROUP_KEY;
        } elseif ($cabinetLineId == $countertopsId) {
            $categoryIds = $product->getCategoryIds();
            if (!empty($categoryIds)) {
                $categories = $this->categoryCollectionFactory->create()
                    ->addAttributeToSelect('name')
                    ->addIsActiveFilter()
                    ->addAttributeToFilter('entity_id', $categoryIds);
                $category = $categories->getFirstItem();
                $categoryName = $category->getName() ?? '';
                $styleName = str_replace('Countertops', '', $categoryName);
            }
            $cartGroupKey = CheckoutHelper::COUNTERTOPS_CART_GROUP_KEY;
            $mainprice  = $countertopPrice;
            $quoteItem->setCustomPrice($mainprice);
            $quoteItem->setOriginalCustomPrice($mainprice);
            $quoteItem->getProduct()->setIsSuperMode(true);
        } else {
            $styleId = $product->getStyleId();
            $styleName = $product->getAttributeText(self::CABINET_STYLE_ID);
            $colorId = $product->getColorId();
            $colorName = $product->getAttributeText(self::CABINET_COLOR_ID);
            if ($styleName != '' && $colorName != '') {
                $cartGroupKey = $styleName . '_' . $colorName;
            }
            $mainprice = $quoteItem->getProduct()->getPrice();
            $woodspeciesId = (int)$product->getWoodspecies();
            if ($woodspeciesId > 0) {
                $woodspeciesName = $product->getAttributeText('woodspecies');
            }
            $styleCode = $this->getStyleCode((int)$cabinetLineId, (int)$styleId, (int)$colorId, (int)$woodspeciesId);
        }

        if ($product && $product->getVendorCostPrice()) {
            $vendorCostPrice = (float)$product->getVendorCostPrice();
        }
        $quoteItem->setVendorCostPrice($vendorCostPrice);
        $quoteItem->setCabinetLineName($cabinetLineName);
        $quoteItem->setCabinetLineId($cabinetLineId);
        $quoteItem->setMappingCabinetLineId($mappingCabinetLineId);
        $quoteItem->setCartGroupKey($cartGroupKey);
        $quoteItem->setStyleId($styleId);
        $quoteItem->setStyleName($styleName);
        $quoteItem->setColorId($colorId);
        $quoteItem->setColorName($colorName);
        $quoteItem->setWoodTypeId($woodspeciesId > 0 ? $woodspeciesId : null);
        $quoteItem->setWoodtypeName($woodspeciesName);
        $quoteItem->setStyleCode($styleCode);
        $quoteItem->setProductMainPrice($mainprice);
        $quoteItem->set2020LineNumber(1);
        $quoteItem->setNetsku($product->getNetsku());
        $quoteItem->setAppliedMultiplier(null);
        $quoteItem->setIsTuk($product->getIsTuk() ?? Boolean::NO);
        $quoteItem->setIsRma($product->getIsRmaProduct() ?? Boolean::NO);
        $loginCustomerGroupId = $this->productPriceHelper->getLoginCustomerGroupId();
        $multiplier = (float)$this->getAppliedMultiplier(
            $mappingCabinetLineId,
            $loginCustomerGroupId
        );
        if ($multiplier > Boolean::NO) {
            $quoteItem->setAppliedMultiplier($multiplier);
        }
    }

    /**
     * Get Applied Multiplier
     *
     * @param  int $cabinetLineId
     * @param  int $customerGroupId
     * @return float
     */
    public function getAppliedMultiplier($cabinetLineId, $customerGroupId)
    {
        if (isset($this->multiplierData[$cabinetLineId]) &&
            isset($this->multiplierData[$cabinetLineId][$customerGroupId])
        ) {
            return $this->multiplierData[$cabinetLineId][$customerGroupId];
        }
        $this->multiplierData[$cabinetLineId][$customerGroupId] = 0;
        $multiplierData = $this->productPriceHelper->getMultiplierData($cabinetLineId, $customerGroupId);
        if (isset($multiplierData['percentage']) && (float)$multiplierData['percentage'] > 0) {
            $this->multiplierData[$cabinetLineId][$customerGroupId] = (float)$multiplierData['percentage'];
        }
        return $this->multiplierData[$cabinetLineId][$customerGroupId];
    }

    /**
     * Get Yotpo App Key
     *
     * @return string
     */
    public function getYotpoAppKey()
    {
        $storeId = $this->getStoreId();
        return $this->yotpoConfig->getAppKey($storeId, ScopeInterface::SCOPE_STORE);
    }

    /**
     * Get Yotpo App Key
     *
     * @return string
     */
    public function isYotpoEnabled()
    {
        $storeId = $this->getStoreId();
        return $this->yotpoConfig->isEnabled($storeId, ScopeInterface::SCOPE_STORE);
    }

    /**
     * Get Category Name
     *
     * @ return string
     */
    public function getCategoryName()
    {
        return $this->getConfigData(self::CATEGORY_NAME);
    }

    /**
     * Get Cabinets to Remove Addtocart
     *
     * @param  mixed $cabinetlines
     * @ return bool
     */
    public function getRemoveAddtocart($cabinetlines = NULL)
    {
        $displayAddToCart = true;
        $cabinetLineIds = $this->getConfigData(self::REMOVE_ADDTOCART_CABINETS);
        if($cabinetLineIds && $cabinetlines){
            $cabinetLineIds = explode(",", $cabinetLineIds);
            $cabinetlines = explode(",", $cabinetlines);
            $findArray = array_intersect($cabinetlines, $cabinetLineIds);
            if($findArray){
                $displayAddToCart = false;
            }
        }
        return $displayAddToCart;
    }

    /**
     * Get Style Specifications
     *
     * @param  int $styleId
     * @return array
     */
    public function getStyleSpecifications($styleId)
    {
        $connection = $this->resourceConnection->getConnection();
        $select = $connection->select()
                ->from(
                    $connection->getTableName('cp_style'),
                    ['style_id','name','door_spec','drawer_spec','cabinetbox_spec','details_spec',
                        'details_assembly','assembly_video', 'yotpo_product_id']
                )
                ->where('style_id = ?', (int)$styleId);
        return $connection->fetchRow($select);
    }

    /**
     * Get Cabinet data.
     *
     * @param int $cabinetId
     * @return array
     */
    public function getCabinet(int $cabinetId)
    {
        $connection = $this->resourceConnection->getConnection();
        $select = $connection->select()
            ->from(
                $connection->getTableName('cp_cabinet_line'),
                ['cabinet_name','supplier', 'parent_cabinet_line_id']
            )->where('cabinet_line_id = ?', $cabinetId);
        return $connection->fetchRow($select);
    }

    /**
     * Get Style Name
     *
     * @param  int $styleId
     * @return string|null
     */
    public function getStyleName($styleId)
    {
        $connection = $this->resourceConnection->getConnection();
        $select = $connection->select()
                ->from($connection->getTableName('cp_style'), ['name'])
                ->where('style_id = ?', (int)$styleId);
        return $connection->fetchone($select);
    }

    /**
     * Get Color Name
     *
     * @param  int $colorId
     * @return string|null
     */
    public function getColorName($colorId)
    {
        $connection = $this->resourceConnection->getConnection();
        $select = $connection->select()
                ->from($connection->getTableName('cp_color'), ['name'])
                ->where('color_id = ?', (int)$colorId);
        return $connection->fetchone($select);
    }

    /**
     * Get Wood Type
     *
     * @param  int $woodTypeId
     * @return string|null
     */
    public function getWoodTypeName($woodTypeId)
    {
        $connection = $this->resourceConnection->getConnection();
        $select = $connection->select()
                ->from($connection->getTableName('cp_wood_type'), ['type_name'])
                ->where('type_id = ?', (int)$woodTypeId);
        return $connection->fetchone($select);
    }

    /**
     * Get Color Type Name
     *
     * @param  int $colorId
     * @return string|null
     */
    public function getColorTypeName($colorId)
    {
        $connection = $this->resourceConnection->getConnection();
        $select = $connection->select()
                ->from(
                    ['cp_color' => $connection->getTableName('cp_color')],
                    ['']
                )
                ->join(
                    ['cp_color_type' => $connection->getTableName('cp_color_type')],
                    'cp_color_type.type_id = cp_color.type_id',
                    ['name' => 'cp_color_type.name']
                )
                ->where('color_id = ?', (int)$colorId);
        return $connection->fetchone($select);
    }

    /**
     * Get Style Code
     *
     * @param  int $cabinetLineId
     * @param  int $styleId
     * @param  int $colorId
     * @param  int|integer $woodTypeId
     * @return string
     */
    public function getStyleCode(int $cabinetLineId, int $styleId, int $colorId, int $woodTypeId = 0, $storeId = 0)
    {
        if ($storeId != 0) {
            $store = $this->storeManager->getStore($storeId);
        } else {
            $store = $this->storeManager->getStore();
        }
        if (!$store || !$store->getId()) {
            $store = $this->storeManager->getStore();
        }
        $collection = $this->categoryCollectionFactory->create();
        $collection->addAttributeToSelect('style_code');
        $collection->setStoreId($store->getId());
        $collection->addFieldToFilter('path', ['like' => "1/" . $store->getRootCategoryId() . "/%"]);
        $collection->addIsActiveFilter();
        $collection->addAttributeToFilter('style_code', array('notnull' => true));
        $collection->addAttributeToFilter('cabinetline', ['eq' => (int)$cabinetLineId]);
        $collection->addAttributeToFilter('style_id', ['eq' => (int)$styleId]);
        $collection->addAttributeToFilter('color_id', ['eq' => (int)$colorId]);
        if ((int)$woodTypeId > 0) {
            $collection->addAttributeToFilter('woodspecies_id', ['eq' => (int)$woodTypeId]);
        }
        $category = $collection->getFirstItem();
        if ($category && $category->getStyleCode()) {
            return $category->getStyleCode();
        }

        $connection = $this->resourceConnection->getConnection();
        if ((int)$woodTypeId > 0) {
            $select = $connection->select()
                    ->from($connection->getTableName('cp_style_wood_color'), ['style_code'])
                    ->where('type_id = ?', (int)$woodTypeId)
                    ->where('color_id = ?', (int)$colorId);
            return $connection->fetchone($select);
        }
        $select = $connection->select()
                ->from($connection->getTableName('cp_style_color'), ['style_code'])
                ->where('style_id = ?', (int)$styleId)
                ->where('color_id = ?', (int)$colorId);
        return $connection->fetchone($select);
    }

    /**
     * Get Bread Integration Key
     *
     * @return string|null
     */
    public function getBreadIntegrationKey() {
        return $this->breadHelper->getIntegrationKey();
    }

    /**
     * @param $product
     * @return string
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getCategoryNameByProduct($product){
        if (empty($product)) return '';
        $categoryNames = [];
        $assignedCategoryName = '';
        $categoryCollection = clone $product->getCategoryCollection();
        $categoryCollection->clear();
        $categoryCollection->addAttributeToSort('level', $categoryCollection::SORT_ORDER_DESC)
            ->addAttributeToFilter(
                'path', ['like' => "1/" . $this->storeManager->getStore()->getRootCategoryId() . "/%"]
            );
        $categoryCollection->setPageSize(1);
        $productCategory = $categoryCollection->getFirstItem();
        $categories = $this->getParentCategories($productCategory);
        if (!empty($categories)){
            foreach ($categories as $category) {
                $categoryNames[$category->getId()] = $category->getName();
            }
            $assignedCategoryName = implode(' > ', $categoryNames);
        }
        return $assignedCategoryName;
    }

    /**
     * Return parent categories of category
     *
     * @param \Magento\Catalog\Model\Category $category
     * @return \Magento\Framework\DataObject[]
     */
    public function getParentCategories($category)
    {
        $pathIds = array_reverse(explode(',', (string)$category->getPathInStore()));
        /** @var \Magento\Catalog\Model\ResourceModel\Category\Collection $categories */
        $categories = $this->categoryCollectionFactory->create();
        return $categories->setStore(
            $this->storeManager->getStore()
        )->addAttributeToSelect(
            'name'
        )->addAttributeToSelect(
            'url_key'
        )->addFieldToFilter(
            'entity_id',
            ['in' => $pathIds]
        )->addFieldToFilter(
            'is_active',
            1
        )->addFieldToFilter(
            'is_used_in_breadcrumb',
            array('neq' => 0)
        )
        ->addAttributeToSort('level', Collection::SORT_ORDER_ASC)
        ->load()
        ->getItems();
    }

    public function getIsNew($isNew=0,$endDate=NULL)
    {
        $isNewFlag = false;
        if($isNew && $endDate){
            $currentDate = new \DateTime();
            if($currentDate->format('m-d-Y') <= date('m-d-Y',strtotime($endDate))) {
                $isNewFlag = self::NEW_TAG;
            }
        }
        return $isNewFlag;
    }

    /**
     * Get Days from configuration
     *
     * @return [string|object][System Configuration of the Field Stored in Admin System Configuration]
     */
    public function getDaysForNewCategoryLable()
    {
        $storeId = $this->getStoreId();
        return $this->scopeConfig->getValue(
            self::NEW_CATEGORY_LABEL_DAYS,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
    }

    public function getEndDateForNew()
    {
        $days = $this->getDaysForNewCategoryLable()??0;
        $endDate = (new \DateTime())->modify('+'.$days.' days')->format('m/d/Y');
        return $endDate;
    }
}
