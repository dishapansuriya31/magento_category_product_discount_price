define([
    'jquery',
    'priceUtils',
    'ko'
], function($, priceUtils, ko){
    "use strict";
    function main(config) {
        var ajaxIsRunning = false;
        $(config.loadMoreSelector).click(function() {
            if(ajaxIsRunning == true) {
                return false;
            }
            var catId = $(this).attr('data-cat-id');
            var pageIdentifier = $(this).attr('data-page-identifier');
            var nextPage = parseInt($(this).attr('data-page-id')) + 1;
            $(config.loadMoreSelector).hide();
            var totalPages = $(config.totalPagesSelector).val();
            if (!totalPages) {
                totalPages = config.totalPages;
            }
            if(totalPages > 1 && totalPages >= nextPage) {
                ajaxIsRunning = true;
                var params = {p : nextPage, cat_id : catId, page_identifier: pageIdentifier};
                $.ajax({
                    type: "POST",
                    url: config.requestUrl,
                    data: params,
                    dataType: "json",
                    showLoader: true,
                    success : function(response) {
                        if (response.success == true){
                            var html = $(response.html);
                            var wrapper = config.wrapperContainer;
                            var updatedWrapper = html.find(wrapper);
                            if (updatedWrapper.length) {
                                $(wrapper).append(updatedWrapper.html()).trigger('contentUpdated');
                            } else {
                                $(config.loadMoreSelector).hide();
                                return false;
                            }
                            if (pageIdentifier == 'custom_cabinet'){
                                ko.cleanNode($(wrapper)[0]);
                                ko.applyBindings(this, $(wrapper)[0]);
                            }

                            if(totalPages <= nextPage) {
                                $(config.loadMoreSelector).hide();
                            } else {
                                $(config.loadMoreSelector).show();
                            }
                            $(config.loadMoreSelector).attr('data-page-id',nextPage);
                        }else{
                            console.warn("something went wrong.");
                        }
                        ajaxIsRunning = false;
                        if (config.isEnabledYotpo && config.isEnabledYotpo == true && typeof Yotpo !== 'undefined') {
                            var api = new Yotpo.API(yotpo);
                            api.refreshWidgets();
                        }
                    },
                    error : function(request,error) {
                        $('body').trigger('processStop');
                    },
                    complete : function(response) {
                        $('body').trigger('processStop');
                    }
                });
            }
        });
        $(document).on('click', '.more-swatch', function (e) {
            var cat_id = $(this).attr('data-cat-id'),
                key = $(this).attr('data-color-type');
            $('.category-data-' + cat_id +'_'+key+ '.less-color').show();
            $('.less-swatch-' + cat_id+'_'+key).show();
            $('.more-swatch-' + cat_id+'_'+key).hide();
        });
        $(document).on('click', '.less-swatch', function (e) {
            var cat_id = $(this).attr('data-cat-id'),
                key = $(this).attr('data-color-type');
            $('.category-data-' + cat_id +'_'+key+ '.less-color').hide();
            $('.less-swatch-' + cat_id+'_'+key).hide();
            $('.more-swatch-' + cat_id+'_'+key).show();
        });
        $(document).on('click', '.all-cabinet-widget-listing .category-selection .category-data', function (e) {
            updateCategoryData($(this));
        });
        function updateCategoryData(selectedColorElement) {
            var _parentId = $(selectedColorElement).attr('data-cat-id'),
                discount_price = $(selectedColorElement).attr("data-discount-price"),
                tenbypercentage = $(selectedColorElement).attr("data-discount-percentage"),
                regular_price = $(selectedColorElement).attr("data-regular-price"),
                sale_text = $(selectedColorElement).attr('data-sale-text'),
                as_low_as_price = $(selectedColorElement).attr("data-as-low-as-price"),
                as_low_as_price_format = $(selectedColorElement).attr("data-as-low-as-price_format");
            $("#cat_image_" + _parentId + " img").addClass("swatch-option-loading");
            $('.selectedcat_' + _parentId).text('');
            $("#selectedcat_"+_parentId+$(selectedColorElement).attr("data-color-type")).text($(selectedColorElement).attr("data-name"));
            $('#shippingtime_' + _parentId).text('SHIPPING TIME: ' + $(selectedColorElement).attr("data-shipping-time"));
            $('#selectedchildcaturl_' + _parentId).attr("href", $(selectedColorElement).attr("data-cat-url"));
            $('#selectedchildcaturlname_' + _parentId).attr("href", $(selectedColorElement).attr("data-cat-url"));
            var isChangesPr = false;
            if (regular_price && regular_price > 0) {
                $('#ten_by_price_' + _parentId).show();
                var _tenByClass = '';
                if (discount_price && discount_price > 0 && parseFloat(regular_price) > parseFloat(discount_price)) {
                    $('#ten_by_price_' + _parentId).find('.sale.sale-discount').show();
                    $('#ten_by_price_discount_' + _parentId).text(getFormatedPrice(discount_price));
                    $('#ten_by_price_percentage_' + _parentId).text(tenbypercentage);
                    isChangesPr = true;
                    if (typeof tenbypercentage == 'undefined') {
                        $('#ten_by_price_' + _parentId).find('.sale.sale-discount').hide();
                        isChangesPr = false;
                    }
                    $('#ten_by_price_regular_' + _parentId).addClass('regular');
                } else {
                    $('#ten_by_price_discount_' + _parentId).text('');
                    $('#ten_by_price_' + _parentId).find('.sale.sale-discount').hide();
                    $('#ten_by_price_regular_' + _parentId).removeClass('regular');
                }
                $('#ten_by_price_regular_' + _parentId).text(getFormatedPrice(regular_price));
                if (parseFloat(as_low_as_price) > 0 && as_low_as_price_format) {
                    $('#as_low_as_price_' + _parentId).text(as_low_as_price_format);
                    $('#ten_by_price_' + _parentId).find('.category-as-low-as-price').show();
                } else {
                    $('#as_low_as_price_' + _parentId).text(as_low_as_price_format);
                    $('#ten_by_price_' + _parentId).find('.category-as-low-as-price').hide();
                }
            } else {
                $('#ten_by_price_' + _parentId).hide();
            }
            if (isChangesPr === false && typeof sale_text != 'undefined' && sale_text != '') {
                $('#ten_by_price_percentage_' + _parentId).text(sale_text);
                $('#ten_by_price_' + _parentId).find('.sale.sale-discount').show();
                $('#ten_by_price_' + _parentId).show();
            }
            $("#cat_image_" + _parentId + " a").attr("href", $(selectedColorElement).attr("data-cat-url"));
            $("#cat_image_" + _parentId + " img").attr({
                'src': $(selectedColorElement).attr("data-image-url"),
                'alt': $(selectedColorElement).attr("data-name")
            });
            $('li[data-cat-id='+_parentId+'].active').removeClass('active');
            $(selectedColorElement).addClass('active');
            $('#get-free-sample_'+_parentId).attr({
                'data-style_id': $(selectedColorElement).attr("data-style_id"),
                'data-color_id': $(selectedColorElement).attr("data-color_id"),
                'data-cabinet_line_id': $(selectedColorElement).attr("data-cabinet_id"),
                'data-wood_type_id': $(selectedColorElement).attr("data-woodspecies_id")
            });
            $(".samplekit-small-detail").remove();
            $(".samplekit-info").hide();
            $(".product-combination-label").hide();
            $('.select-style-btn-get-free').removeClass('active');
            $("#cat_image_" + _parentId + " img").removeClass("swatch-option-loading");
        };
        function getFormatedPrice(price) {
            var currencyFormat = (config.storeCurrencyFormat) ?? "$%s";
            var priceFormat = {
                decimalSymbol: '.',
                groupLength: 3,
                groupSymbol: ",",
                integerRequired: false,
                pattern: currencyFormat,
                precision: 2,
                requiredPrecision: 2
            }
            return priceUtils.formatPrice(price, priceFormat);
        };
    };
    return main;
});
