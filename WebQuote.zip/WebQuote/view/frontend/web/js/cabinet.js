define([
    'jquery',
    'uiComponent',
    'ko',
    'mage/storage',
    'mage/url',
    'mage/template',
    'Magento_Customer/js/customer-data',
    'Magento_Ui/js/modal/modal',
    'slick',
    'owlcarousel',
    'jquery/jquery.cookie'
], function (
        $,
        Component,
        ko,
        storage,
        mageUrl,
        mageTemplate,
        customerData,
        modal,
        slick,
        cookie
    ) {
    'use strict';
    var self;
    const MORE_COLOR = 4; const COUNT_COLOR = 5; const CABINET_TITLE = " Cabinet Doors";
    $('body').trigger('processStop');

    var cabinetLineId = null;
    var emptystring = "<p>No matching Door Styles. Please select more options.</p>";
    return Component.extend({
        cabinetList: ko.observableArray([]),
        doorColorList: ko.observableArray([]),
        filterOptionList: ko.observableArray([]),
        mappingImage: ko.observable(null),
        selectedStyleName: ko.observable(null),
        selected_cabinet_name: ko.observable(null),        
        selectedColorName: ko.observable(null),
        selectedDoorColorName: ko.observable(null),
        styleSpecifications: ko.observable(null),
        styleI_d: ko.observable(null),
        standardColors: ko.observableArray([]),
        doorColors: ko.observableArray([]),
        designerColors: ko.observableArray([]),
        styleId: ko.observable(0),
        colorId: ko.observable(0),
        priceId: ko.observable(0),
        styleColorCabinetLineId: ko.observable(0),
        cabinetName: ko.observable(null),
        categoryattrid: ko.observable(0),
        stycolor: ko.observable(0),
        stlyeCabinateId: ko.observable(null),
        imagePath: ko.observable(null),
        defaultimg: ko.observable(0),
        shownElement: ko.observable(null),
        shownFilterElement: ko.observable(null),
        
        initialize: function () {
            self = this;
            this._super();
            self.doorColorList(this.styleCollection);
            if (!$.isEmptyObject(this.styleCollection)
                && this.styleCollection.hasOwnProperty("filter_options")
                ) {
                self.filterOptionList({
                    filter_options :this.styleCollection.filter_options
                });
            }
            $(document).on("DOMNodeInserted", "ul.standard-color", function() {
                $(this).find('div.color-image:first').trigger('click');
            });
            self.shownElement("door_listing_data");
            self.shownFilterElement("filter_listing_data");
            if (self.getFilterRequestCookie() && self.getFilterRequestCookie() !=null) {
                self.getStyleColorWithFiltered(self.getFilterRequestCookie());
            }
        },
        onClick: function(data){
            self.shownElement(null);
            self.shownFilterElement(null);
            $('div.category-listing-products,div.door-style-pdp-top-main').hide();

            var element = null;
            if(data=="door_listing_data"){
                element = "door_listing_data";
                self.shownElement(element);
                self.shownFilterElement("filter_listing_data");
                var title_line = $("ul.kitchen-layout-list li.active").find("input[name='cabinetlineradio']").attr('class');
                self.selected_cabinet_name(title_line+CABINET_TITLE);
                $(document).on("DOMNodeInserted", "ul.standard-color", function() {
                    $(this).find('div.color-image:first').trigger('click');
                });
            } 
            /*if(data=="select-line"){
                element = "cabinetlines-step";
                self.shownElement(element);
            }*/
            if(data=="cabinet-doors"){
                element = "door_listing_data";
                self.shownElement(element);
                self.shownFilterElement("filter_listing_data");
                $('span.cabinet-doors').removeClass('active');
            }
            if(data=="prev"){
                $('.webquote-main-wp').show();
                //$('#cabinetlines-step').hide();
            }
        },
        createCustomUrl: function(url, params) {
            var config = {
                method: 'rest',
                storeCode: 'default',
                version: 'V1',
                serviceUrl: ':method/:storeCode/:version',
            };
            var completeUrl = config.serviceUrl + url;
            return this.bindParams(completeUrl, params, config);
        },
        /**
         * @param {String} url
         * @param {Object} params
         * @return {*}
         */
        bindParams: function (url, params, config) {
            var urlParts;

            params.method = config.method;
            params.storeCode = config.storeCode;
            params.version = config.version;

            urlParts = url.split('/');
            urlParts = urlParts.filter(Boolean);

            $.each(urlParts, function (key, part) {
                part = part.replace(':', '');

                if (params[part] != undefined) { //eslint-disable-line eqeqeq
                    urlParts[key] = params[part];
                }
            });

            return urlParts.join('/');
        },
        selectColor: function (color) {
            $('div#style_id_'+color.style_id+' img').attr('src',color.mapping_image);
            self.mappingImage(null);
            self.selectedColorName(null);
            if (typeof(color.mapping_image) != 'undefined') {
                self.mappingImage(color.mapping_image);
            }
            if (typeof(color.color_name) != 'undefined') {
                self.selectedColorName(color.color_name);
            }
            if (typeof(color.color_id) != 'undefined') {
                self.colorId(color.color_id);
                self.styleId(color.style_id);
                self.priceId(color.price_id);
                self.styleColorCabinetLineId(color.cabinet_line_id);
                self.selectedStyleName(color.name);
                if (color.parent_cabinet_line_id) {
                    self.categoryattrid(color.cabinet_line_id+","+color.parent_cabinet_line_id);
                }else{
                    self.categoryattrid(color.cabinet_line_id+","+color.ori_cabinet_line_id);
                }
            }
        },
        renderSlider: function(){
            $(".kitchen-layout-list").owlCarousel({
              loop: false,
              margin: 0,
              autoWidth: true,
              dots: true,
              nav: true,
              items: 1,
              navText: [
                  "<i class='fa fa-caret-left'></i>",
                  "<i class='fa fa-caret-right'></i>"
              ],
              autoplay: false,
              autoplayHoverPause: false,
              responsive: {
                0: {
                  items: 1,
                  margin: 0,
                  dots: true
                },
                767: {
                  items: 1,
                  dots: true
                },
                1024: {
                  items: 1,
                  dots: false,
                  nav: false,
                  loop: false
                }
              }
            });
        },
        filterOpShow: function(indexKey) {
            var filterTitleCls = $(".style-filter-title");
            var filterTitleId  = $("#style_filter_title_"+indexKey);
            var filterSubCls   = $(".sub-filter-listing");
            var filterSubId    = $("#sub_filter_listing_"+indexKey);
            if (filterTitleId.hasClass('active')) {
                filterTitleCls.removeClass('active');
                filterSubCls.hide();
            }else{
                filterTitleId.addClass('active');
                filterSubCls.hide();
                filterSubId.show();
            }
        },
        isShowMoreSwatch: function () {
            $('div.door-color-selection').each(function(index){
                $(this).find('li.color-data:gt('+MORE_COLOR+')').hide();
                var colorcount = $(this).find('li.color-data').size();
                if(colorcount>5){
                    $(this).find('span.more-swatch:first').text("+"+ parseInt(colorcount-COUNT_COLOR));
                }else{
                    $(this).find('div.more-swatches').hide();
                }
            });
        },
        createFilterRequest: function(data) {
            var $filterCheckboxes = $('input:checkbox.filter-selection');
            var selectedFilters = {filterRequest:{}};
            $filterCheckboxes.filter(':checked').each(function() {
                if (!selectedFilters.filterRequest.hasOwnProperty(this.name)) {
                    selectedFilters.filterRequest[this.name] = [];
                }
                let valuePush = this.value;
                let stringResult = valuePush.split(',');
                selectedFilters.filterRequest[this.name].push(stringResult);
            });
            self.setFilterRequestInCookie(selectedFilters);
            self.getStyleColorWithFiltered(selectedFilters);
            return true;
        },
        getStyleColorWithFiltered: function(filterRequiredParam) {
            $("body").trigger('processStart');
            let requestUrl = '';
            if (customerData.get('customer')().data_id != undefined) {
                requestUrl = mageUrl.build(self.createCustomUrl("/cabinets-style/stylebycabinetid", {}));
            } else {
                requestUrl = mageUrl.build(self.createCustomUrl("/cabinets-style/stylebycabinetid", {}));
            }
            storage.post(
                requestUrl,
                JSON.stringify(
                    filterRequiredParam
                )
            ).done(function (result) {
                if (result.length) {
                    self.doorColorList(result.shift());
                    if (self.doorColorList().hasOwnProperty("styles_data")
                        && $.isEmptyObject(result.styles_data)
                        ) {
                        $('#emptyMsg').html(emptystring);
                    }
                }else{
                    self.doorColorList([]);
                    $('#emptyMsg').html(emptystring);
                }
                if (filterRequiredParam) {
                    $.each(filterRequiredParam.filterRequest, function(fieldName, selectedValue) {
                        $.each(selectedValue, function(key, value) {
                            $("input[name='"+fieldName+"'][value='" + value + "']").prop("checked", true);
                        });
                    });
                }
            }).complete(function (response) {
                self.isShowMoreSwatch();
                $("body").trigger('processStop');
            }).fail(function (response) {
                $("body").trigger('processStop');
                errorProcessor.process(response);
            });
        },
        setFilterRequestInCookie: function(filterRequest){
            $.cookie('web_quote_filter_request',JSON.stringify(filterRequest),{expires: 86400});          
        },
        getFilterRequestCookie: function(){
            var storedCookie = $.cookie('web_quote_filter_request');
            if (storedCookie) {
                return JSON.parse(storedCookie);
            }
            return null;
        },
        clearFilter: function(){
            $.cookie("web_quote_filter_request", null, { path: '/' });
            location.reload();
        },
    });
});