define(['jquery', 'uiComponent', 'ko'], function ($, Component, ko) {
        'use strict';
        var self;
        return Component.extend({
               
                categoryLists : ko.observableArray([]),
                selectedCategory : ko.observable(),
                initialize: function () {
                        self = this;
                        this.customerName = ko.observableArray([]);
                        this.customerData = ko.observable('');
                        this._super();
                        this.categoryLists(this.categoryData);
                        this.selectedCategory(this.categoryData[0]);

                },

                selectCategory: function (index) {
                        this.selectedCategory(index);
                },

                doorSliderInit: function(){
                        $(".door-layout-list").owlCarousel({
                            loop: false,
                            margin: 70,
                            autoWidth: true,
                            dots: false,
                            nav: true,
                            navText: [
                                "<i class='fa fa-caret-left'>Prev</i>",
                                "<i class='fa fa-caret-right'>Next</i>"
                            ],
                            autoplay: false,
                            autoplayHoverPause: false,
                            responsive: {
                              0: {
                                items: 1,
                                margin: 0,
                                autoWidth: false,
                                dots: true
                              },
                              767: {
                                items: 1,
                                margin: 30,
                                dots: true
                              },
                              1024: {
                                items: 1,
                              }
                            }
                          });
                },
        });
    }
);