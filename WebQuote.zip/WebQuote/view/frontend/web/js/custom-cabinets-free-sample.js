define([
    'jquery',
    'uiComponent',
    'ko',
    'mage/storage',
    'mage/url',
    'Magento_Checkout/js/model/error-processor',
    'Magento_Customer/js/customer-data',
    'Magento_Ui/js/modal/modal'
], function ($, Component, ko, storage,mageUrl,errorProcessor,customerData,modal) {
    'use strict';
    var self = this;
    $(document).on('click', '.select-style-btn-get-free', function (e) {
        self.getFreeSample($(this).attr("data-cat_id"));
        self.categoryId($(this).attr("data-cat_id"));
    });
    return Component.extend({
        sampleProductsData      : ko.observableArray([]),
        selectedStyleId         : ko.observableArray(0),
        selectedCabinetLineId   : ko.observableArray(0),
        selectedColorId         : ko.observableArray(0),
        selectedWoodSpecieId    : ko.observableArray(0),
        isShowDiffStylePopup: ko.observable(false),
        isShowSameCombination: ko.observable(false),
        orgStyleName: ko.observable(null),
        orgColorName: ko.observable(null),
        orgStyleImage: ko.observable(null),
        orgProductImage: ko.observable(null),
        dupStyleName: ko.observable(null),
        dupColorName: ko.observable(null),
        dupStyleImage: ko.observable(null),
        dupProductImage: ko.observable(null),
        addToCartUrl  : mageUrl.build('kitchen-cabinet-samples/index/addtocart/'),
        validationUrl : mageUrl.build('kitchen-cabinet-samples/index/checkforvalidation/'),
        cartPageUrl: ko.observable(mageUrl.build('checkout/cart')),
        categoryId:ko.observable(null),
        initialize: function () {
            self = this;
            this._super();
            self.selectedCabinetLineId(this.cabinetLineId);
            self.selectedColorId(this.colorId);
            self.selectedStyleId(this.styleId);
            self.cartPageUrl(this.cartUrl);
        },
        createCustomUrl: function(url, params) {
            var config = {
                method: 'rest',
                storeCode: 'default',
                version: 'V1',
                serviceUrl: ':method/:storeCode/:version',
            };
            var completeUrl = config.serviceUrl + url;
            return this.bindParams(completeUrl, params, config);
        },
        /**
         * @param {String} url
         * @param {Object} params
         * @return {*}
         */
        bindParams: function (url, params, config) {
            var urlParts;

            params.method = config.method;
            params.storeCode = config.storeCode;
            params.version = config.version;

            urlParts = url.split('/');
            urlParts = urlParts.filter(Boolean);

            $.each(urlParts, function (key, part) {
                part = part.replace(':', '');

                if (params[part] != undefined) { //eslint-disable-line eqeqeq
                    urlParts[key] = params[part];
                }
            });

            return urlParts.join('/');
        },
        getFreeSample: function (id) {
            self.sampleProductsData([]);
            var getFreeSelector     = "#get-free-sample_"+id;
            var samplekitSelector   = "#samplekit_info_"+id;

            $(".samplekit-info").hide();
            $(".product-combination-label").hide();
            $('.select-style-btn-get-free').removeClass('active');
            $(samplekitSelector).show();
            var isVisibleCurrentSampleKit = $(samplekitSelector).is(':hidden');
            var _colorId,
                _styleId,
                _cabinetId,
                _woodId;
            if (typeof $(getFreeSelector).attr("data-color_id") !== 'undefined') {
                _colorId = $(getFreeSelector).attr("data-color_id");
            } else {
                _colorId = $('ul.standard-category li[data-cat-id='+id+'].active').attr('data-color_id');
            }
            if (typeof $(getFreeSelector).attr("data-cabinet_line_id") !== 'undefined') {
                _cabinetId = $(getFreeSelector).attr("data-cabinet_line_id");
            } else {
                _cabinetId = $('ul.standard-category li[data-cat-id='+id+'].active').attr('data-cabinet_id');
            }
            if (typeof $(getFreeSelector).attr("data-style_id") !== 'undefined') {
                _styleId = $(getFreeSelector).attr("data-style_id");
            } else {
                _styleId = $('ul.standard-category li[data-cat-id='+id+'].active').attr('data-style_id');
            }
            if (typeof $(getFreeSelector).attr("data-wood_type_id") !== 'undefined') {
                _woodId = $(getFreeSelector).attr("data-wood_type_id");
            } else {
                _woodId = $('ul.standard-category li[data-cat-id='+id+'].active').attr('data-woodspecies_id');
            }
            var requiredParam = {
                colorId                 : _colorId,
                cabinetLineId           : _cabinetId,
                styleId                 : _styleId,
                woodTypeId              : _woodId,
                cat_id                  : id
            };
            self.selectedStyleId(requiredParam.styleId);
            self.selectedCabinetLineId(requiredParam.cabinetLineId);
            self.selectedColorId(requiredParam.colorId);
            self.selectedWoodSpecieId(requiredParam.woodTypeId);

            if ($(samplekitSelector).is(":visible")) {
                $(getFreeSelector).addClass('active');
                self.getFreeSampleProducts(requiredParam);
            }

            return this;
        },
        getFreeSampleProducts: function(requiredParam) {
            $("body").trigger('processStart');
            let sampleProductUrl = mageUrl.build(self.createCustomUrl("/cabinets-sampleproducts/get-by-stylecolor", {}));
            if (parseInt(self.selectedWoodSpecieId()) > 0) {
                sampleProductUrl = mageUrl.build(self.createCustomUrl("/cabinets-sampleproducts/get-by-woodcolor", {}));
            }
            var _samplekitInfo = "#samplekit_info_" + requiredParam.cat_id;
            if ($(_samplekitInfo+" .samplekit-inner ul#sample-product-list .product-combination-label").length != 0){
                $(_samplekitInfo+" .samplekit-inner ul#sample-product-list .product-combination-label").remove();
            }

            storage.post(
                sampleProductUrl,
                JSON.stringify({
                    colorId             : requiredParam.colorId,
                    cabinetLineId       : requiredParam.cabinetLineId,
                    styleId             : requiredParam.styleId,
                    woodTypeId          : requiredParam.woodTypeId
                }),
                false
            ).done(function (result) {
                self.sampleProductsData(result);
                if(self.sampleProductsData() == ''){
                    $(_samplekitInfo+" .samplekit-inner ul#sample-product-list").prepend(
                        '<span class="product-combination-label" style="color: #eb003b">Samples is not available for this combination</span>'
                    );
                }
                $("body").trigger('processStop');
            }).fail(function (response) {
                $("body").trigger('processStop');
                errorProcessor.process(response);
            });
        },
        addToCartSample: function(sampleProduct) {
            $("body").trigger('processStart');
            var modelOptions = {
                type: 'popup',
                responsive: true,
                innerScroll: true,
                title: 'Attention',
                buttons: false,
                modalClass: 'samecombination'
            };
            var freeProductSku = '',
                free_parent_product_id = '';
            if (typeof(sampleProduct.free_product_sku) != 'undefined') {
                freeProductSku = sampleProduct.free_product_sku;
            }
            if (typeof(sampleProduct.free_parent_product_id) != 'undefined') {
                free_parent_product_id = sampleProduct.free_parent_product_id;
            }
            $('[data-block="minicart"]').trigger('contentLoading');
            $.ajax({
                type: "POST",
                url: self.validationUrl,
                dataType : 'json',
                data: {
                    id              : sampleProduct.product_id,
                    style_id        : self.selectedStyleId(),
                    wood_type_id    : self.selectedWoodSpecieId(),
                    color_id        : sampleProduct.color_id,
                    cabinet_line_id : sampleProduct.cabinet_line_id ? sampleProduct.cabinet_line_id : self.selectedCabinetLineId(),
                    freeProductSku      : freeProductSku,
                    free_parent_product_id : free_parent_product_id
                },
                success: function(result) {
                    if (result) {
                        if(result.designer_quote){
                            var designerpopup = modal(modelOptions, $('#designer-quote-popup-modal_'+self.categoryId()));
                            $("#designer-quote-popup-modal_"+self.categoryId()).modal("openModal");
                        }
                        if(result.show_popup){
                            self.resetPopupData();
                            var add_free_product = result.add_free_product;
                            if (result.samecombination) {
                                self.isShowSameCombination(true);
                                self.isShowDiffStylePopup(false);
                                modelOptions.modalClass = 'duplicate-popup-main';
                                var popup = modal(modelOptions, $('#popup-modal_'+self.categoryId()));
                                $("#popup-modal_"+self.categoryId()).modal("openModal");
                                $("body").trigger('processStop');
                                $('#close-duplicate_'+self.categoryId()).click(function() {
                                    popup.closeModal();
                                    return false;
                                });
                            } else if (result.show_diff_style_popup) {
                                self.isShowSameCombination(false);
                                self.isShowDiffStylePopup(true);

                                self.orgStyleName(result.origstyle_name);
                                self.orgColorName(result.origcolor_name);
                                self.orgStyleImage(result.orig_styleimage);
                                self.orgProductImage(result.product_image);

                                self.dupStyleName(result.dupstyle_name);
                                self.dupColorName(result.dupcolor_name);
                                self.dupStyleImage(result.dup_styleimage);
                                self.dupProductImage(result.dup_product_image);

                                var popup = modal(modelOptions, $('#popup-modal_'+self.categoryId()));
                                $("body").trigger('processStop');
                                $("#popup-modal_"+self.categoryId()).modal("openModal");
                                $('#remove-duplicate_'+self.categoryId()).click(function() {
                                    popup.closeModal();
                                    return false;
                                });
                                $('._show #popup-modal_'+self.categoryId()+ '#continue-duplicate_'+self.categoryId()).unbind('click');
                            }
                            if(result.show_diff_style_popup) {
                                $('._show #popup-modal_'+self.categoryId()+ '#continue-duplicate_'+self.categoryId()).click(function () {
                                    if (!add_free_product) {
                                        freeProductSku = '';
                                        free_parent_product_id = '';
                                    }
                                    /*add to cart*/
                                    self.addDuplicateProductToCart(sampleProduct,freeProductSku,free_parent_product_id);
                                });
                            } else {
                                if (!add_free_product) {
                                    freeProductSku = '';
                                    free_parent_product_id = '';
                                }
                                /*add to cart*/
                                self.addDuplicateProductToCart(sampleProduct,freeProductSku,free_parent_product_id);
                            }
                        }
                        if (result.minicart) {
                            $('[data-block="minicart"]').replaceWith(result.minicart);
                            $('[data-block="minicart"]').trigger('contentUpdated');
                        }
                        if(result.message){
                            $("#sample-message-"  + self.categoryId()).html("");
                            if(result.success){
                                $('#sample-message-' + self.categoryId()).html('<div class="message-success success message"><div>'+result.message+'</div></div>');
                                $('body').trigger('catalogCategoryAddToCartAfter');
                            }else{
                                $('#sample-message-' + self.categoryId()).html('<div class="message-error error message"><div>'+result.message+'</div></div>');
                            }
                            $('#sample-message-' + self.categoryId()).fadeIn('slow').delay(10000).hide(0);
                        }
                    }
                    var sections = ['cart'];
                    customerData.invalidate(sections);
                    customerData.reload(sections, true);
                    $("body").trigger('processStop');
                },
                error: function(result) {
                    $("body").trigger('processStop');
                    errorProcessor.process(result);
                }
            });
        },
        addDuplicateProductToCart: function(sampleProduct,freeProductSku,free_parent_product_id) {
            $.ajax({
                type: "POST",
                url: self.addToCartUrl,
                dataType : 'json',
                data: {
                    id: sampleProduct.product_id,
                    style_id:self.selectedStyleId(),
                    wood_type_id:self.selectedWoodSpecieId(),
                    color_id:self.selectedColorId(),
                    cabinet_line_id: self.selectedCabinetLineId(),
                    freeProductSku:freeProductSku,
                    free_parent_product_id:free_parent_product_id
                },
                success: function(result) {
                    if (result.show_diff_style_popup) {
                        $('#popup-modal_'+self.categoryId()).modal('closeModal');
                    }
                    var sections = ['cart'];
                    customerData.invalidate(sections);
                    customerData.reload(sections, true);

                    if(result.message){
                        $(".message-box").html("");
                        if(result.success) {
                            $('.message-box').html('<div class="message-success success message"><div>'+result.message+'</div></div>');
                            $('.action.showcart').trigger("click");
                        } else {
                            $('.message-box').html('<div class="message-error error message"><div>'+result.message+'</div></div>');
                        }
                        $('.message-box').fadeIn('slow').delay(1000).hide(0);
                        $('body').trigger('catalogCategoryAddToCartAfter');
                    }
                },
                error: function(result) {
                    $("body").trigger('processStop');
                    errorProcessor.process(result);
                }
            });
        },
        resetPopupData: function() {
            self.orgStyleName(null);
            self.orgColorName(null);
            self.orgStyleImage(null);
            self.orgProductImage(null);
            self.dupStyleName(null);
            self.dupColorName(null);
            self.dupStyleImage(null);
            self.dupProductImage(null);
            self.isShowSameCombination(false);
            self.isShowDiffStylePopup(false);
        },
    });
});
