/**
 * Commercepundit
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Commercepundit.com license that is
 * available through the world-wide-web at this URL:
 * http://commercepundit.com/license
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category   Commercepundit
 * @package    Commercepundit_WebQuote
 * @copyright  Copyright (c) Commercepundit (http://www.commercepundit.com/)
 * @license    http://www.commercepundit.com/LICENSE-1.0.html
 */
define(
    [
         'Magento_Checkout/js/model/resource-url-manager'
    ],
    function (urlManager) {
        'use strict';
        return {
            /**
             * Retrieve style url
             * 
             * @return {string}
             */
            getStyleUrl: function () {
                var params = (urlManager.getCheckoutMethod() == 'guest') ? {} : {};
                var urls = {
                        'guest': '/cabinets-style/get-by-cabinets',
                        'customer': '/cabinets-style/get-by-cabinets'
                    };

                return urlManager.getUrl(urls, params);
            },

            /**
             * Retrieve style url
             * 
             * @return {string}
             */
            getStyleColorsUrl: function () {
                var params = (urlManager.getCheckoutMethod() == 'guest') ? {} : {};
                var urls = {
                        'guest': '/cabinets-style/stylebycabinetid',
                        'customer': '/cabinets-style/stylebycabinetid'
                    };

                return urlManager.getUrl(urls, params);
            },

            /**
             * Retrieve woodtype url
             * 
             * @return {string}
             */
            getWoodtypeUrl: function () {
                var params = (urlManager.getCheckoutMethod() == 'guest') ? {} : {};
                var urls = {
                        'guest': '/cabinets-woodspecies/get-by-style',
                        'customer': '/cabinets-woodspecies/get-by-style'
                    };

                return urlManager.getUrl(urls, params);
            },

            /**
             * Retrieve woodcolor url
             * 
             * @return {string}
             */
            getWoodcolorUrl: function () {
                var params = (urlManager.getCheckoutMethod() == 'guest') ? {} : {};
                var urls = {
                        'guest': '/cabinets-woodcolor/get-by-woodtype',
                        'customer': '/cabinets-woodcolor/get-by-woodtype'
                    };

                return urlManager.getUrl(urls, params);
            },

            /**
             * Retrieve stylecolor url
             * 
             * @return {string}
             */
            getStylecolorUrl: function () {
                var params = (urlManager.getCheckoutMethod() == 'guest') ? {} : {};
                var urls = {
                        'guest': '/cabinets-stylecolor/get-by-style',
                        'customer': '/cabinets-stylecolor/get-by-style'
                    };

                return urlManager.getUrl(urls, params);
            },

            /**
             * Retrieve woodsampleproducts url
             * 
             * @return {string}
             */
            getWoodSampleProductsUrl: function () {
                var params = (urlManager.getCheckoutMethod() == 'guest') ? {} : {};
                var urls = {
                        'guest': '/cabinets-sampleproducts/get-by-woodcolor',
                        'customer': '/cabinets-sampleproducts/get-by-woodcolor'
                    };

                return urlManager.getUrl(urls, params);
            },

            /**
             * Retrieve stylesampleproducts url
             * 
             * @return {string}
             */
            getStyleSampleProductsUrl: function () {
                var params = (urlManager.getCheckoutMethod() == 'guest') ? {} : {};
                var urls = {
                        'guest': '/cabinets-sampleproducts/get-by-stylecolor',
                        'customer': '/cabinets-sampleproducts/get-by-stylecolor'
                    };

                return urlManager.getUrl(urls, params);
            },
            /**
             * Retrieve post partner program data url
             * 
             * @return {string}
             */
            getPostPartnerUrl: function () {
                var params = (urlManager.getCheckoutMethod() == 'guest') ? {} : {};
                var urls = {
                        'guest': '/partner-program/post-partner-data',
                        'customer': '/partner-program/post-partner-data'

                    };

                return urlManager.getUrl(urls, params);
            },
            /**
             * Retrieve post Kitchen Catalog data url
             * 
             * @return {string}
             */
            getPostKitchenCatalogUrl: function () {
                var params = (urlManager.getCheckoutMethod() == 'guest') ? {} : {};
                var urls = {
                    'guest': '/cabinets/post-kitchencatalog-data',
                    'customer': '/cabinets/post-kitchencatalog-data'
                };

                return urlManager.getUrl(urls, params);
            },

            /**
             * Retrieve post free design data url
             * 
             * @return {string}
             */
            getFreeDesignPostUrl: function () {
                var params = (urlManager.getCheckoutMethod() == 'guest') ? {} : {};
                var urls = {
                        'guest': '/freedesign/post-freedesign-data',
                        'customer': '/freedesign/post-freedesign-data'
                    };

                return urlManager.getUrl(urls, params);
            },

            /**
             * Retrieve post free design data url
             * 
             * @return {string}
             */
            getSetserUrl: function () {
                var params = (urlManager.getCheckoutMethod() == 'guest') ? {} : {};
                var urls = {
                        'guest': '/freedesign/setserdesigner',
                        'customer': '/freedesign/setserdesigner'
                    };

                return urlManager.getUrl(urls, params);
            },

            /**
             * Retrieve style url by door
             * 
             * @return {string}
             */
            getDoorStyleUrl: function () {
                var params = (urlManager.getCheckoutMethod() == 'guest') ? {} : {};
                var urls = {
                        'guest': '/cabinets-style/get-by-door',
                        'customer': '/cabinets-style/get-by-door'
                };
                return urlManager.getUrl(urls, params);
            },

            /**
             * Retrieve Style and Color by door
             * 
             * @return {string}
             */
            getStyleColorByDoorUrl: function () {
                var params = (urlManager.getCheckoutMethod() == 'guest') ? {} : {};
                var urls = {
                        'guest': '/cabinets-style-color/get-by-door',
                        'customer': '/cabinets-style-color/get-by-door'
                };
                return urlManager.getUrl(urls, params);
            },

            /**
             * Retrieve post Get Quote data url
             * 
             * @return {string}
             */
            getPostGetQuoteUrl: function () {
                var params = (urlManager.getCheckoutMethod() == 'guest') ? {} : {};
                var urls = {
                    'guest': '/get-quote/post-quote-data',
                    'customer': '/get-quote/post-quote-data'
                };

                return urlManager.getUrl(urls, params);
            },
        };
    }
);