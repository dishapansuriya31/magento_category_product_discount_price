/**
 * Copyright © 2022 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
define([
    'jquery',
    'mage/template',
    'mage/translate',
    'jquery/ui'
], function ($, mageTemplate) {
    "use strict";

    $.widget('mage.productCustomOption', {
        loaderStarted: 0,
        options: {
            icon: '',
            texts: {
                loaderText: $.mage.__('Please wait...'),
                imgAlt: $.mage.__('Loading...')
            },
            template: '<div class="loading-mask" data-role="loader">' +
                    '<div class="loader">' +
                    '<img alt="<%- data.texts.imgAlt %>" src="<%- data.icon %>">' +
                    '<p><%- data.texts.loaderText %></p>' +
                    '</div>' + '</div>'

        },
        _create: function () {
            if($('div').hasClass('custom-option-product-link')){
                this._bindClick();
            }
        },

        _bindClick: function () {
            var self = this;
            self.createWindow();
            this.element.on('click', function (e) {
                var _form = $("#product-item-info_" + $(this).attr("data-id")).find("form.product-add-to-cart-form");
                if (!_form.valid()) {
                    e.preventDefault();
                    return false;
                }
                e.preventDefault();
                self.element.removeClass('active');
                $(this).addClass('active');
                self.show();
                self.ajaxLoad($(this));
            });
        },
        _render: function () {
            var html;

            if (!this.spinnerTemplate) {
                this.spinnerTemplate = mageTemplate(this.options.template);

                html = $(this.spinnerTemplate({
                    data: this.options
                }));

                html.prependTo($('body'));

                this.spinner = html;
            }
        },
        show: function () {
            $('body').addClass('custom-option-poup-open');
            $('body').append("<div id='fancybox-loading'><div></div></div>");
            return false;
        },
        hide: function () {
            $('body').removeClass('custom-option-poup-open');
            $('body #fancybox-loading').remove();
            return false;
        },

        ajaxLoad: function (link) {
            var self = this;
            if ($('#product-customoption-content-' + link.attr('data-id')).length > 0)
            {
                return self.showWindow($('#product-customoption-content-' + link.attr('data-id')));
            }
            var urlLink = link.attr('data-href');
            if (!urlLink)
                urlLink = link.attr('href');
            $.ajax({
                url: urlLink,
                showLoader: true,
                data: {},
                success: function (res) {
                    var itemShow = $('#product-customoption-content');
                    if (link.attr('data-id'))
                    {
                        if ($('#product-customoption-content-' + link.attr('data-id')).length < 1)
                        {
                            var wrapper = document.createElement('div');
                            $(wrapper).attr('id', 'product-customoption-content-' + link.attr('data-id'));
                            $(wrapper).addClass('wrapper_customoption_item');
                            $(wrapper).html(res);
                            $('#product-customoption-content').append(wrapper);
                            var _qty = parseInt($("#qty_" + link.attr('data-id')).val());
                        }
                        itemShow = $('#product-customoption-content-' + link.attr('data-id'));
                        $('#product-customoption-content-' + link.attr('data-id')).find(".control.qty-change").children("input#qty").val(_qty);
                        if (_qty > 1) {
                            $('#product-customoption-content-' + link.attr('data-id')).find('.quantity-minus').removeClass('disabled')
                        }
                        $('#product-customoption-content-' + link.attr('data-id') + '  .small_image').on('click', function (event) {
                        });
                    } else
                    {
                        $('#product-customoption-content').html(res);
                    }
                    //$('.cloud-zoom, .cloud-zoom-gallery').CloudZoom();
                    $('#product-customoption-content').trigger('contentUpdated');
                    self.showWindow(itemShow);
                }
            });
        },
        showWindow: function (itemShow)
        {
            this.hide();
            $('body').addClass('custom-option-poup-open');
            //var scrollY = $(window).scrollTop();
            var width = $('body').width();
            $('#customoption-window .wrapper_customoption_item').hide();
            $('#customoption-window').css({
               //top: scrollY + 100 + 'px',
                //left: width / 2 - $('#customoption-window').width() / 2 + 'px',
                display: 'block'
            });
            if (itemShow)
                itemShow.show();
            $('#customoption-background').removeClass('hidden');
        },
        hideWindow: function ()
        {
            $('#customoption-window').hide();
            $('#customoption-window .wrapper_customoption_item').hide();
            $('#customoption-background').addClass('hidden');
            $('#product-customoption-content').html('');
            $('body').removeClass('custom-option-poup-open');
        },
        createWindow: function ()
        {
            if ($('#customoption-background').length > 0)
                return;
            var qBackground = document.createElement('div');
            $(qBackground).attr('id', 'customoption-background');
            $(qBackground).addClass('hidden');
            $('body').append(qBackground);

            var qWindow = document.createElement('div');
            $(qWindow).attr('id', 'customoption-window');
            $(qWindow).html('<div id="customoption-header"><a href="javascript:void(0)" id="customoption-close">close</a></div><div class="customoption-view-content" id="product-customoption-content"></div>');
            $('body').append(qWindow);
            $('#customoption-close').on('click', this.hideWindow.bind(this));
        }
    });

    return $.mage.productCustomOption;
});
