define([
    'jquery',
    'Magento_Customer/js/customer-data',
    'mage/storage',
    'mage/url',
    'Magento_Checkout/js/model/error-processor',
    'Magento_Ui/js/modal/modal'
], function($,
    customerData,
    storage,
    mageUrl,
    errorProcessor,
    modal){
    "use strict";

    function main(config) {
        if($(".category-content").length > 0){
            if ($(window).width() >= 992) {
                $("#filter_listing_data").show();
                $(".clearFilter").show();
                $(".mobile-filter").hide();
                $("#mobile-selected-filter").hide();
            }else{
              $("#filter_listing_data").hide();
              $(".clearFilter").hide();
              $(".mobile-filter").show();
              $("#mobile-selected-filter").show();
            }
        }
        $(window).resize(function() {
            if ($(window).width() >= 992) {
                $("#filter_listing_data").show();
                $(".clearFilter").show();
                $(".mobile-filter").hide();
                $("#mobile-selected-filter").hide();
            }else{
              $("#filter_listing_data").hide();
              $(".clearFilter").hide();
              $(".mobile-filter").show();
              $("#mobile-selected-filter").show();
            }
        });
        $(document).on('click', '.category-data', function (e) {
            updateCat($(this));
        });
        $('.style-filter-title').unbind().click(function (e) {
            if ($(e.target).attr("class") != 'sub-filter-listing' && $(e.target).attr("class") != 'filter-selection checkbox') {
                filterOpShow($(this).attr('data-index'));
            }
            else if ($(e.target).attr("class") == 'filter-selection checkbox') {
                createFilterRequest();
            }
        });
        $(document).on('click', '.filter-remove-btn', function (e) {
            var filterKey = $(this).attr('data-filter-key'),
                filterVal = $(this).attr('data-filter-value');
            $(this).parent().remove();
            if (filterKey && filterVal) {
                $("input[name='"+filterKey+"'][value='" + filterVal + "']").prop("checked", false);
                createFilterRequest();
            }
        });
        $(document).on('click', function (e) {
            if ($(e.target).attr("class") != 'sub-filter-listing' &&
                $(e.target).attr("class") != 'filter-selection checkbox' &&
                $(e.target).attr("class") != 'style-filter-title' &&
                $(e.target).attr("class") != 'style-filter-label' &&
                $(".style-filter-title").hasClass('active')
            ) {
                var filterTitleCls = $(".style-filter-title");
                var filterSubCls   = $(".sub-filter-listing");
                if (filterTitleCls.hasClass('active')) {
                    filterTitleCls.removeClass('active');
                    filterSubCls.hide();
                }
            }
        });
        $(document).on('click', '.clearFilter', function (e) {
            location.reload();
        });
        $(document).on('click', '.more-swatch', function (e) {
            var cat_id = $(this).attr('data-cat-id'),
                key = $(this).attr('data-color-type');
            showCategory(cat_id, key);
        });
        $(document).on('click', '.less-swatch', function (e) {
            var cat_id = $(this).attr('data-cat-id'),
                key = $(this).attr('data-color-type');
            hideCategory(cat_id, key);
        });
        $(document).on('click', '.mobile-filter', function (e) {
            openFilter();
        });
        $(document).on('click', '.mobile-filter-apply', function (e) {
            if($(window).width() <= 991 && $("#filter_listing_data").hasClass('activefilterpopup')){
                $("#filter_listing_data").removeClass('activefilterpopup').modal("closeModal");
            }
            //createFilterRequest();
        });
        $(document).on('click', '.mobile-filter-reset', function (e) {
            location.reload();
        });
        /*$(document).on('change', '.filter-selection', function (e) {
            if ($(window).width() >= 767) {
                createFilterRequest();
            }
        });*/
        $(document).on('click', '.mobile-filter-popup .action-close', function (e) {
            $(".modal-popup.mobile-filter-popup").removeClass("_show");
        });
        $(document).on('click', '.mobile-filter-popup .mobile-filter-apply', function (e) {
            $(".modal-popup.mobile-filter-popup").removeClass("_show");
        });
        function createCustomUrl(url, params) {
            var config = {
                method: 'rest',
                storeCode: 'default',
                version: 'V1',
                serviceUrl: ':method/:storeCode/:version',
            };
            var completeUrl = config.serviceUrl + url;
            return bindParams(completeUrl, params, config);
        };
        /**
         * @param {String} url
         * @param {Object} params
         * @return {*}
         */
        function bindParams(url, params, config) {
            var urlParts;
            params.method = config.method;
            params.storeCode = config.storeCode;
            params.version = config.version;
            urlParts = url.split('/');
            urlParts = urlParts.filter(Boolean);
            $.each(urlParts, function (key, part) {
                part = part.replace(':', '');
                if (params[part] != undefined) { //eslint-disable-line eqeqeq
                    urlParts[key] = params[part];
                }
            });
            return urlParts.join('/');
        };
        function filterOpShow(indexKey){
            var filterTitleCls = $(".style-filter-title");
            var filterTitleId  = $("#style_filter_title_"+indexKey);
            var filterSubCls   = $(".sub-filter-listing");
            var filterSubId    = $("#sub_filter_listing_"+indexKey);
            if (filterTitleId.hasClass('active')) {
                filterTitleCls.removeClass('active');
                filterSubCls.hide();
            } else {
                filterTitleId.addClass('active');
                filterSubCls.hide();
                filterSubId.show();
            }
        };
        function getSelectedFilterAndSortByRequest(){
            var $filterCheckboxes = $('input:checkbox.filter-selection');
            var selectedFilters = {filterRequest: {},filterRequestOrig: {}};
            $filterCheckboxes.filter(':checked').each(function() {
                if (!selectedFilters.filterRequest.hasOwnProperty(this.name)) {
                    selectedFilters.filterRequest[this.name] = [];
                }
                if (!selectedFilters.filterRequestOrig.hasOwnProperty(this.name)) {
                    selectedFilters.filterRequestOrig[this.name] = {};
                }
                let valuePush = this.value;
                let stringResult = valuePush.split(',');
                selectedFilters.filterRequest[this.name].push(stringResult);
                selectedFilters.filterRequestOrig[this.name][valuePush] = valuePush;
            });
            selectedFilters.filterRequest['sort_by'] = $("#sort-order-option").val();
            return selectedFilters;
        }
        function createFilterRequest(){
            var $filterCheckboxes = $('input:checkbox.filter-selection');
            var selectedFilters = {filterRequest: {},filterRequestOrig: {}};
            $filterCheckboxes.filter(':checked').each(function() {
                if (!selectedFilters.filterRequest.hasOwnProperty(this.name)) {
                    selectedFilters.filterRequest[this.name] = [];
                }
                if (!selectedFilters.filterRequestOrig.hasOwnProperty(this.name)) {
                    selectedFilters.filterRequestOrig[this.name] = {};
                }
                let valuePush = this.value;
                let stringResult = valuePush.split(',');
                selectedFilters.filterRequest[this.name].push(stringResult);
                selectedFilters.filterRequestOrig[this.name][valuePush] = valuePush;
            });
            selectedFilters.filterRequest['sort_by'] = $("#sort-order-option").val();
            getStyleColorWithFiltered(selectedFilters);
            return true;
        };
        $("#sort-order-option").change(function() {
            var params = getSelectedFilterAndSortByRequest();
            applyFilterAndSortBy(params);
        });
        function applyFilterAndSortBy(params){
            $("body").trigger('processStart');
            $.ajax({
                type: "POST",
                url: config.customcabinetUrl,
                data: {
                    categoryId: config.customcategoryId,
                    filterRequest:params
                },
                showLoader: true,
                success : function(response) {
                    $(".custom_cabinet_section").replaceWith(response);
                    if ($.fn.applyBindings != undefined) {
                        $('.custom_cabinet_section').applyBindings();
                    }
                    /*$("#web-selected-filter").html($("#original-selected-filter").html());
                    $("#mobile-selected-filter").html($("#original-selected-filter").html());
                    updateFilteredCat();*/
                    if($(".category-content").length <= 0){
                        $(".showEmptyRecordsMsg").show();
                    }
                    if (config.isEnabledYotpo && config.isEnabledYotpo == true && typeof Yotpo !== 'undefined') {
                        var api = new Yotpo.API(yotpo);
                        api.refreshWidgets();
                    }
                    scrollToFilter();
                },
                error : function(request,error) {
                    $('.errormsgcabinets').show();
                    $('body').trigger('processStop');
                },
                complete : function(response) {
                    $('body').trigger('processStop');
                }
            });
        };
        function scrollToFilter(){
            if ($('.category-description').length) {
                $('html, body').animate({
                    scrollTop: parseFloat($('.category-description').position().top + $('.category-description').outerHeight(true))
                },500);
            }
            if ($('.list-sample-description').length) {
                $('html, body').animate({
                    scrollTop: parseFloat($('.list-sample-description').position().top + $('.list-sample-description').outerHeight(true))
                },500);
            }
        };
        function showCategory(cat_id, key) {
            $('.category-data-' + cat_id +'_'+key+ '.less-color').show();
            $('.less-swatch-' + cat_id+'_'+key).show();
            $('.more-swatch-' + cat_id+'_'+key).hide();
        };
        function hideCategory(cat_id ,key) {
            $('.category-data-' + cat_id +'_'+key+ '.less-color').hide();
            $('.less-swatch-' + cat_id+'_'+key).hide();
            $('.more-swatch-' + cat_id+'_'+key).show();
        };
        function getStyleColorWithFiltered(filterRequiredParam) {
            $("body").trigger('processStart');
            $.ajax({
                type: "POST",
                url: config.customcabinetUrl,
                data: {categoryId: config.customcategoryId,
                filterRequest:filterRequiredParam},
                dataType: "html",
                showLoader: true,
                success : function(response) {
                    $(".custom_cabinet_section").replaceWith(response);
                    if ($.fn.applyBindings != undefined) {
                        $('.custom_cabinet_section').applyBindings();
                    }
                    $("#web-selected-filter").html($("#original-selected-filter").html());
                    $("#mobile-selected-filter").html($("#original-selected-filter").html());
                    updateFilteredCat();
                    if($(".category-content").length <= 0){
                        $(".showEmptyRecordsMsg").show();
                    }
                    if (filterRequiredParam) {
                        if (filterRequiredParam.filterRequest.hasOwnProperty('sort_by')){
                            delete filterRequiredParam.filterRequest.sort_by;//Remove sort by option from request object because each loop required array.
                        }
                        $.each(filterRequiredParam.filterRequest, function(fieldName, selectedValue) {
                            $.each(selectedValue, function(key, value) {
                                $("input[name='"+fieldName+"'][value='" + value + "']").prop("checked", true);
                            });
                        });
                    }
                    if (config.isEnabledYotpo && config.isEnabledYotpo == true && typeof Yotpo !== 'undefined') {
                        var api = new Yotpo.API(yotpo);
                        api.refreshWidgets();
                    }
                    if ($('.category-description').length) {
                        $('html, body').animate({
                            scrollTop: parseFloat($('.category-description').position().top + $('.category-description').outerHeight(true))
                        },500);
                    }
                    if ($('.list-sample-description').length) {
                        $('html, body').animate({
                            scrollTop: parseFloat($('.list-sample-description').position().top + $('.list-sample-description').outerHeight(true))
                        },500);
                    }
                },
                error : function(request,error) {
                    $('.errormsgcabinets').show();
                    $('body').trigger('processStop');
                },
                complete : function(response) {
                   $('body').trigger('processStop');
                }
            });
        };
        function updateFilteredCat(){
            $(".category-data").each(function() {
                if($(this).attr("data-first-color") == true) {
                     updateCat($(this));
                }
            });
        }
        function updateCat(catdata){
            $('div#cat_id_' + catdata.attr("data-cat-id")+ ' img').addClass('swatch-option-loading');
            var colorName = catdata.attr("data-color-name"),
                colorType =  catdata.attr("data-color-type"),
                catId = catdata.attr("data-cat-id"),
                image = catdata.attr("data-image-url"),
                shipping_time = catdata.attr("data-shipping-time"),
                cat_url = catdata.attr("data-cat-url"),
                as_low_as_price = catdata.attr("data-as-low-as-price") ? catdata.attr("data-as-low-as-price") : 0,
                as_low_as_price_format = catdata.attr("data-as-low-as-price_format") ? catdata.attr("data-as-low-as-price_format") : null,
                discount_price = catdata.attr("data-discount-price") ? catdata.attr("data-discount-price") : null,
                discount_price_format = catdata.attr("data-discount-price_format") ? catdata.attr("data-discount-price_format") : null,
                tenbypercentage = catdata.attr("data-percentage-price") ? catdata.attr("data-percentage-price") : null,
                sell_tag_name = catdata.attr("data-sell-tag-name") ? catdata.attr("data-sell-tag-name") : null,
                is_sample = catdata.attr("data-is-sample") ? catdata.attr("data-is-sample") : false,
                is_tuk = catdata.attr("data-is-tuk-cat"),
                regular_price = catdata.attr("data-regular_price-price") ? catdata.attr("data-regular_price-price") : null,
                regular_price_format = catdata.attr("data-regular_price-price_format") ? catdata.attr("data-regular_price-price_format") : null,
                child_catId = catdata.attr("data-childcat-id"),
                styleId = catdata.attr("data-style_id"),
                colorId = catdata.attr("data-color_id"),
                cabinetId = catdata.attr("data-cabinet_id"),
                woodspeciesId = catdata.attr("data-woodspecies_id") ? catdata.attr("data-woodspecies_id") : null,
                sale_text = catdata.attr('data-sale-text');
            $('.selectedcat_' + catId).text('');
            $("#selectedcat_"+catId+colorType).text(colorName);
            $('#shippingtime_' + catId).text('SHIPPING TIME: ' + shipping_time);
            if (is_tuk != 1){
                $('#selectedchildcaturl_' + catId).attr("href", cat_url);//for sample page url cng only.
            }
            $('#categoryimagecustom_' + catId).attr("href", cat_url);
            $('#categorytitlecustom_' + catId).attr("href", cat_url);
            var _tenByClass = '',
            isChangedPer = false;

            if (is_sample == true) {
                if (sell_tag_name !== null) {
                    $('#ten_by_price_percentage_' + catId).text(sell_tag_name);
                    $('#ten_by_price_' + catId).find('.sale.sale-discount').show();
                } else {
                    $('#ten_by_price_' + catId).find('.sale.sale-discount').hide();
                }
            } else {
                if (discount_price != null
                    && regular_price != null) {
                    $('#ten_by_price_' + catId).show();
                    var _tenByClass = '';
                    if (discount_price && regular_price && regular_price > discount_price) {
                        $('#ten_by_price_discount_' + catId).text(discount_price_format);
                        if(tenbypercentage !== null){
                            $('#ten_by_price_percentage_' + catId).text(tenbypercentage);
                            isChangedPer = true;
                        };
                        if(tenbypercentage == null) $('#ten_by_price_' + catId).find('.sale.sale-discount').hide();
                        _tenByClass = 'regular'
                    } else {
                        $('#ten_by_price_discount_' + catId).text('');
                        $('#ten_by_price_' + catId).find('.sale.sale-discount').hide();
                    }
                    $('#ten_by_price_regular_' + catId).text(regular_price_format);
                    $('#ten_by_price_regular_' + catId).addClass(_tenByClass);
                    if (_tenByClass == '') {
                        $('#ten_by_price_regular_' + catId).removeClass('regular');
                    }
                    if (parseFloat(as_low_as_price) > 0 && as_low_as_price_format) {
                        $('#as_low_as_price_' + catId).text(as_low_as_price_format);
                        $('#ten_by_price_' + catId).find('.category-as-low-as-price').show();
                    } else {
                        $('#as_low_as_price_' + catId).text(as_low_as_price_format);
                        $('#ten_by_price_' + catId).find('.category-as-low-as-price').hide();
                    }
                }else{
                    $('#ten_by_price_' + catId).hide();
                }
            }
            if (isChangedPer === false && typeof sale_text != 'undefined' && sale_text != '') {
                $('#ten_by_price_percentage_' + catId).text(sale_text);
                $('#ten_by_price_' + catId).find('.sale.sale-discount').show();
                $('#ten_by_price_' + catId).show();
            }

            $('div#cat_id_' + catId+ ' img').attr('src', image);
            $('div#cat_id_' + catId+ ' img').attr('alt', colorName);
            $('li[data-cat-id='+catId+'].active').removeClass('active');
            $('li[data-childcat-id='+child_catId+']').addClass('active');
            $('#get-free-sample_'+catId).attr({
                'data-style_id'         : styleId,
                'data-color_id'         : colorId,
                'data-cabinet_line_id'  : cabinetId
            });
            if(woodspeciesId != null){
                $('#get-free-sample_'+catId).attr({
                    'data-wood_type_id' : woodspeciesId
                });
            }
            $(".samplekit-small-detail").remove();
            $(".samplekit-info").hide();
            $(".product-combination-label").hide();
            $('.select-style-btn-get-free').removeClass('active');
            $('div#cat_id_' + catId+ ' img').removeClass('swatch-option-loading');
        };
        function openFilter() {
           var modelOptions = {
                type: 'popup',
                responsive: true,
                innerScroll: true,
                title: '',
                buttons: false,
                modalClass: 'mobile-filter-popup'
            };
            $(".filter_listing_data").show();
            $(".mobile-filter-reset").show();
            $(".mobile-filter-apply").show();
            $(".clearFilter").hide();
            var designerpopup = modal(modelOptions, $('#filter_listing_data'));
            $("#filter_listing_data").addClass('activefilterpopup').modal("openModal");
        };
        var fixmeTop = jQuery(".filter-main-container").offset().top;
        jQuery(window).scroll(function() {
            var currentScroll = jQuery(window).scrollTop();
            if (currentScroll >= fixmeTop) {
                jQuery('.filter-main-container').addClass('sticky-filter');
            } else {
                jQuery('.filter-main-container').removeClass('sticky-filter');
            }
        });
        var isModelOpen = false;
        $(document).on('click', '.category-as-low-as-price', function (e) {
            e.preventDefault();
            $('body').trigger('processStart');
            isModelOpen = true;
            openFinancePrequalifyModel();
        });
        function openFinancePrequalifyModel() {
            if (typeof window.BreadPayments !== 'undefined') {
                if (isModelOpen == false) {
                    $('body').trigger('processStop');
                    return false;
                }
                if ($('#bread-placement-1').length) {
                    $('#bread-placement-1').html('');
                } else {
                    $(".custom_cabinet_section").append('<div id="bread-placement-1"></div>');
                }
                let pre_bread_sdk = window.BreadPayments;
                pre_bread_sdk.setup({
                    integrationKey: config.breadIntegrationKey,
                    containerID: 'bread-placement-1'
                });

                let pre_placementObject = {
                    allowCheckout: false,
                    financingType: "installment",
                    locationType: "checkout",
                    domID: 'bread-placement-1'
                };
                pre_bread_sdk.setInitMode('manual');
                pre_bread_sdk.setEmbedded(false);
                pre_bread_sdk.__internal__.setAutoRender(false);
                pre_bread_sdk.registerPlacements([pre_placementObject]);

                pre_bread_sdk.on('INSTALLMENT:APPLICATION_DECISIONED', () => {});
                pre_bread_sdk.on('INSTALLMENT:APPLICATION_CHECKOUT', () => {});
                pre_bread_sdk.on('INSTALLMENT:INITIALIZED', () => {
                    if (isModelOpen == false) {
                        const e = document.querySelector("[id*=zoid-checkout-component]");
                        e && e.remove();
                    }
                });
                pre_bread_sdk.on("INSTALLMENT:CUSTOMER_OPEN", (location,opts) => {
                    $('body').trigger('processStop');
                    if (isModelOpen == false) {
                        const e = document.querySelector("[id*=zoid-checkout-component]");
                        e && e.remove();
                    }
                });
                pre_bread_sdk.on("INSTALLMENT:CUSTOMER_CLOSE", (opts) => {
                    isModelOpen = false;
                    const e = document.querySelector("[id*=zoid-checkout-component]");
                    e && e.remove();
                });

                pre_bread_sdk.init();
                pre_bread_sdk.openExperienceForPlacement([pre_placementObject]);
            }
        };
    };
return main;
});
