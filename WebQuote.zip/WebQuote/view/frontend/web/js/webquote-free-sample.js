define([
    'jquery',
    'uiComponent',
    'ko',
    'mage/storage',
    'mage/url',
    'Magento_Ui/js/modal/modal',
    'Magento_Checkout/js/model/error-processor',
    'Magento_Customer/js/customer-data'
], function ($, Component, ko, storage,mageUrl,modal,errorProcessor,customerData) {
    'use strict';
    var self;
    var isFirstCall = true;
   
    $('#myTabs .item.title a').click(function(e) {
        var idtab = $(this).parent().attr('aria-controls');
        var catid = $(this).attr('data-catid');
        if($('.item.content#'+idtab).children().length === 0){
            $("body").trigger('processStart');
            $.ajax({
                type: "POST",
                url: $(this).attr('data-url'),
                data : {
                    id: idtab,
                    catid : catid
                },
                success: function(result) {
                    if (result) {
                        $("body").trigger('processStop');
                        var message = result.message;
                        $('.item.content#'+idtab).html(message);
                    }
                },
                error: function(result) {
                    $("body").trigger('processStop');
                    errorProcessor.process(result);
                }
            });
        }
     });
    return Component.extend({
        selectedStyleId: ko.observable(null),
        selectedCabinetLineId: ko.observable(0),
        selectedColorId: ko.observable(0),
        showColorChipOnly: ko.observable(null),
        selectedWoodSpeciesId: ko.observable(0),
        showFreeSampleContent: ko.observable(false),
        sampleProductsData: ko.observableArray([]),
        cartPageUrl: ko.observable(null),
        startDesignUrl: ko.observable(null),
        isShowDiffStylePopup: ko.observable(false),
        isShowSameCombination: ko.observable(false),
        orgStyleName: ko.observable(null),
        orgColorName: ko.observable(null),
        orgStyleImage: ko.observable(null),
        orgProductImage: ko.observable(null),
        dupStyleName: ko.observable(null),
        dupColorName: ko.observable(null),
        dupStyleImage: ko.observable(null),
        dupProductImage: ko.observable(null),
        sampleActiveClass: ko.observable(''),
        restrictRegion: ko.observable(null),
        isSampleProductsNotAvailable:ko.observable(false),
        initialize: function () {
            self = this;
            this._super();
            self.selectedCabinetLineId(this.webQuoteCabinetId);
            self.selectedColorId(this.webQuoteColorId);
            self.selectedStyleId(this.webQuoteStyleId);
            self.selectedWoodSpeciesId(this.webQuoteWoodSpeciesId);
            self.showColorChipOnly(this.webQuouteShowColorChipOnly);
            self.cartPageUrl(this.cartUrl);
            self.startDesignUrl(this.startDesignPageUrl);
            self.restrictRegion(this.restrictRegions);
        },
        getFreeSample: function () {
            self.sampleProductsData([]);
            if (self.showFreeSampleContent() == false) {
                self.sampleActiveClass('active');
                var _selectedColorId = self.getSelectedStyleColorData();
                if (_selectedColorId.selectedColor) {
                    self.getFreeSampleProducts();  // show spinner when fetching free samples
                    self.isSampleProductsNotAvailable(false);
                } else {
                    self.isSampleProductsNotAvailable(true);
                }
            } else {
                self.sampleActiveClass('');
            }
            self.showFreeSampleContent(!self.showFreeSampleContent());
        },
        createCustomUrl: function(url, params) {
            var config = {
                method: 'rest',
                storeCode: 'default',
                version: 'V1',
                serviceUrl: ':method/:storeCode/:version',
            };
            var completeUrl = config.serviceUrl + url;
            return this.bindParams(completeUrl, params, config);
        },
        /**
         * @param {String} url
         * @param {Object} params
         * @return {*}
         */
        bindParams: function (url, params, config) {
            var urlParts;

            params.method = config.method;
            params.storeCode = config.storeCode;
            params.version = config.version;

            urlParts = url.split('/');
            urlParts = urlParts.filter(Boolean);

            $.each(urlParts, function (key, part) {
                part = part.replace(':', '');

                if (params[part] != undefined) { //eslint-disable-line eqeqeq
                    urlParts[key] = params[part];
                }
            });

            return urlParts.join('/');
        },
        getFreeSampleProducts: function() {
            if (!isFirstCall) {
                $("body").trigger('processStart');
            }
            isFirstCall = false;
        
            let sampleProductUrl = mageUrl.build(self.createCustomUrl("/cabinets-sampleproducts/get-by-stylecolor", {}));
            if (parseInt(self.selectedWoodSpeciesId()) > 0) {
                sampleProductUrl = mageUrl.build(self.createCustomUrl("/cabinets-sampleproducts/get-by-woodcolor", {}));
            }
            var selectedCatData = self.getSelectedStyleColorData();
            storage.post(
                sampleProductUrl,
                JSON.stringify({
                    colorId: selectedCatData.selectedColor,
                    cabinetLineId: selectedCatData.selectedCabinet,
                    styleId: selectedCatData.selectedStyle,
                    woodTypeId: selectedCatData.selectedWoodType,
                    showColorChipOnly: self.showColorChipOnly(),
                }),
                false
            ).done(function (result) {
                self.sampleProductsData(result);
                if (self.sampleProductsData() == '') {
                    self.isSampleProductsNotAvailable(true);
                }
                if (!isFirstCall) {
                    $("body").trigger('processStop');
                }
            }).fail(function (response) {
                if (!isFirstCall) {
                    $("body").trigger('processStop');
                }
                errorProcessor.process(response);
            });
        },
    addToCartSample: function(sampleProduct) {
            $("body").trigger('processStart');
            var modelOptions = {
                type: 'popup',
                responsive: true,
                innerScroll: true,
                title: 'Attention',
                buttons: false,
                modalClass: 'samecombination'
            };
            var freeProductSku = '',
                free_parent_product_id = '';

            if (typeof(sampleProduct.free_product_sku) != 'undefined') {
                freeProductSku = sampleProduct.free_product_sku;
            }
            if (typeof(sampleProduct.free_parent_product_id) != 'undefined') {
                free_parent_product_id = sampleProduct.free_parent_product_id;
            }
            var selectedCatData = self.getSelectedStyleColorData();
            $.ajax({
                type: "POST",
                url: self.validationUrl,
                dataType : 'json',
                data: {
                    id: sampleProduct.product_id,
                    style_id:selectedCatData.selectedStyle,
                    wood_type_id:selectedCatData.selectedWoodType,
                    color_id:selectedCatData.selectedColor,
                    cabinet_line_id: selectedCatData.selectedCabinet,
                    freeProductSku:freeProductSku,
                    free_parent_product_id:free_parent_product_id
                },
                success: function(result) {
                    if (result) {
                        if(result.designer_quote){
                            var designerpopup = modal(modelOptions, $('#designer-quote-popup-modal'));
                            $("#designer-quote-popup-modal").modal("openModal");
                        }
                        if(result.show_popup){
                            self.resetPopupData();
                            var add_free_product = result.add_free_product;
                            if (result.samecombination) {
                                self.isShowSameCombination(true);
                                self.isShowDiffStylePopup(false);
                                modelOptions.modalClass = 'duplicate-popup-main';
                                var popup = modal(modelOptions, $('#popup-modal'));
                                $("#popup-modal").modal("openModal");
                                $("body").trigger('processStop');
                                $('#close-duplicate').click(function() {
                                    popup.closeModal();
                                    return false;
                                });
                            } else if (result.show_diff_style_popup) {
                                self.isShowSameCombination(false);
                                self.isShowDiffStylePopup(true);

                                self.orgStyleName(result.origstyle_name);
                                self.orgColorName(result.origcolor_name);
                                self.orgStyleImage(result.orig_styleimage);
                                self.orgProductImage(result.product_image);

                                self.dupStyleName(result.dupstyle_name);
                                self.dupColorName(result.dupcolor_name);
                                self.dupStyleImage(result.dup_styleimage);
                                self.dupProductImage(result.dup_product_image);

                                var popup = modal(modelOptions, $('#popup-modal'));
                                $("body").trigger('processStop');
                                $("#popup-modal").modal("openModal");
                                $('#remove-duplicate').click(function() {
                                    popup.closeModal();
                                    return false;
                                });
                                $('._show #popup-modal #continue-duplicate').unbind('click');
                            }
                            if(result.show_diff_style_popup) {
                                $('._show #popup-modal #continue-duplicate').click(function () {
                                    if (!add_free_product) {
                                        freeProductSku = '';
                                        free_parent_product_id = '';
                                    }
                                    /*add to cart*/
                                    self.addDuplicateProductToCart(sampleProduct,freeProductSku,free_parent_product_id);
                                });
                            } else {
                                if (!add_free_product) {
                                    freeProductSku = '';
                                    free_parent_product_id = '';
                                }
                                /*add to cart*/
                                self.addDuplicateProductToCart(sampleProduct,freeProductSku,free_parent_product_id);
                            }
                        }
                        if (result.minicart) {
                            $('[data-block="minicart"]').replaceWith(result.minicart);
                            $('[data-block="minicart"]').trigger('contentUpdated');
                        }
                        if(result.message){
                            $(".message-box").html("");
                            if(result.success){
                                $('.message-box').html('<div class="message-success success message"><div>'+result.message+'</div></div>');
                                //$('.action.showcart').trigger("click");
                                $('body').trigger('catalogCategoryAddToCartAfter');
                            }else{
                                $('.message-box').html('<div class="message-error error message"><div>'+result.message+'</div></div>');
                            }
                            $('.message-box').fadeIn('slow').delay(10000).hide(0);
                        }
                    }
                    var sections = ['cart'];
                    customerData.invalidate(sections);
                    customerData.reload(sections, true);
                    $("body").trigger('processStop');
                },
                error: function(result) {
                    $("body").trigger('processStop');
                    errorProcessor.process(result);
                }
            });
        },
        addDuplicateProductToCart: function(sampleProduct,freeProductSku,free_parent_product_id) {
            var selectedCatData = self.getSelectedStyleColorData();
            $('[data-block="minicart"]').trigger('contentLoading');
            $.ajax({
                type: "POST",
                url: self.addToCartUrl,
                dataType : 'json',
                data: {
                    id: sampleProduct.product_id,
                    style_id:selectedCatData.selectedStyle,
                    wood_type_id:selectedCatData.selectedWoodType,
                    color_id:selectedCatData.selectedColor,
                    cabinet_line_id: selectedCatData.selectedCabinet,
                    freeProductSku:freeProductSku,
                    free_parent_product_id:free_parent_product_id
                },
                success: function(result) {
                    if (result.show_diff_style_popup) {
                        $('#popup-modal').modal('closeModal');
                    }
                    var sections = ['cart'];
                    customerData.invalidate(sections);
                    customerData.reload(sections, true);

                    if(result.message){
                        $(".message-box").html("");
                        if(result.success) {
                            $('.message-box').html('<div class="message-success success message"><div>'+result.message+'</div></div>');
                            //$('.action.showcart').trigger("click");
                        } else {
                            $('.message-box').html('<div class="message-error error message"><div>'+result.message+'</div></div>');
                        }
                        $('.message-box').fadeIn('slow').delay(1000).hide(0);
                    }
                },
                error: function(result) {
                    $("body").trigger('processStop');
                    errorProcessor.process(result);
                }
            });
        },
        resetPopupData: function() {
            self.orgStyleName(null);
            self.orgColorName(null);
            self.orgStyleImage(null);
            self.orgProductImage(null);
            self.dupStyleName(null);
            self.dupColorName(null);
            self.dupStyleImage(null);
            self.dupProductImage(null);
            self.isShowSameCombination(false);
            self.isShowDiffStylePopup(false);
        },
        getColorChipLabel: function(){
            if(typeof(this.webQuouteShowColorChipOnly != 'undefined') && this.webQuouteShowColorChipOnly == 1){
                return "Free Color Chip";
            }
            return "Get Free Sample";
        },

        getSelectedStyleColorData: function () {
            var _activeCat = $('.category-image.active').parent().closest("li.sub-category-item");
            var _selectedColorId = _activeCat.attr('data-color_id');
            var _selectedStyleId = _activeCat.attr('data-style_id');
            var _selectedCabinetId = _activeCat.attr('data-cabinet_id');
            var _selectedWoodTypeId = _activeCat.attr('data-woodspecies_id');
            if (typeof _selectedColorId == 'undefined') {
                _selectedColorId = self.selectedColorId();
            }
            if (typeof _selectedStyleId == 'undefined') {
                _selectedStyleId = self.selectedStyleId();
            }
            if (typeof _selectedCabinetId == 'undefined') {
                _selectedCabinetId = self.selectedCabinetLineId();
            }
            if (typeof _selectedWoodTypeId == 'undefined') {
                _selectedWoodTypeId = self.selectedWoodSpeciesId();
            }
            return {
                'selectedColor': _selectedColorId,
                'selectedStyle': _selectedStyleId,
                'selectedCabinet': _selectedCabinetId,
                'selectedWoodType': _selectedWoodTypeId,
            };
        },
    });
});
