define([
    'jquery','mage/storage','Magento_Catalog/js/price-utils'
], function ($, storage, priceUtils) {
    const MORE_COLOR = 4;
    $(document).on("click","span.more-swatch",function() {
        $(this).parent().find('span.more-swatch').hide();
        $(this).parent().find('span.less-swatch').show();
        $(this).parent().parent().parent().find('li.color-data').show();

    });
    $(document).on("click","span.less-swatch",function() {
        $(this).parent().find('span.more-swatch').show();
        $(this).parent().find('span.less-swatch').hide();
        $(this).parent().parent().parent().find('li.color-data:gt('+MORE_COLOR+')').hide();
    });

    $(document).on("click","button.select-style-btn",function() {
        $(this).parent().parent().find('div.color-image.active').trigger('click');
        var style_id = $(this).parent().parent().find('div.color-image.active').closest('li').attr('id').split('__');
        $('#selected_style_id').val(style_id['0'].match(/\d+/));
        $('#selected_color_id').val(style_id['1'].match(/\d+/));
        //$('div#accordion div.category-name:first').trigger('click');
        var colorId = $('#selected_color_id').val();
        var CategoryUrl = null;
        var colordata = window.checkout.selectedColorData;
        if(colordata
            && colordata.colors.doorcolor[colorId].category_url){
            CategoryUrl = colordata.colors.doorcolor[colorId].category_url ?? null;
        }
        if(CategoryUrl)
        {
            $(location).attr('href',CategoryUrl);
        }
        $('span.cabinet-doors').addClass('active');
        $('.door-style-pdp-top-main,.category-listing-products,span.cabinet-type').show();
        $('div.door_listing-data').hide();
        $('div#filter_listing_data').hide();
        $('div.selected-door-style-info img.door-image').attr('src',$(this).parent().parent().find('img:first').attr('src'));
        $('div.selected-door-style-info img.door-image').attr('data-src',$(this).parent().parent().find('img:first').attr('src'));
        $('div.selected-door-style-info span.door-style').html($(this).parent().parent().find('figcaption').text());
        $('div.selected-door-style-info span.door-color').html($(this).parent().parent().find('.color-image.active img').attr('alt'));
    });

    $(document).on("click","div.category-left-side",function() {
        $('div.category-left-side').removeClass('active');
        $(this).addClass('active');
    });

    $(document).on("click","div.cabinet-types a",function() {
        $("div.cabinet-type-lists div").removeClass('active');
        $(this).closest('div').addClass('active');
    });

    $(document).on("click",".swipe-btn",function() {
        if ($(window).width() <= 767) {
            $(".swipe-btn").next().toggleClass('active');
            $(this).find('b').text(function(i, text) {
                return text === "Swipe Down" ? "Swipe Up" : "Swipe Down";
            });
            $(".swipe-btn").toggleClass('active');
        }
    });

    $(document).on("click","div.category-name",function() {
        var $this = $(this);
        $this.toggleClass('show');
        $this.next().slideToggle();
    });

    $(document).on("click","button.add",function() {
        $('div.finished_options div.mage-error').remove();
        $(this).parent().find('button.sub').prop("disabled", false);
        $(this).parents('.category-description').find('button.action.tocart.primary').prop("disabled", false);
        $(this).prev().val(+$(this).prev().val() + 1);
    });

    $(document).on("click","button.sub",function() {
        if ($(this).next().val() <= 2) {
            $(this).prop("disabled", true);
        }
        if ($(this).next().val() > 1) {
            if ($(this).next().val() > 1) $(this).next().val(+$(this).next().val() - 1);
        }
    });


    $(document).on("change","input[name='qty']",function() {
        if ($(this).val() < 1) {
            $(this).parents('.category-description').find('button.action.tocart.primary').prop("disabled", true);
            $(this).after("<div id='qty-error' class='mage-error'>Please enter a quantity greater than 0.</div>");
        }else{
            $(this).parents('.category-description').find('button.action.tocart.primary').prop("disabled", false);
            if ($(this).next("#qty-error").first().length) {
                $("#qty-error").remove();
            }
        }
        if ($(this).val() <= 1) {
            $(this).parents('.category-description').find('.field.qty button.sub').prop("disabled", true);
        } else {
            $(this).parents('.category-description').find('.field.qty button.sub').prop("disabled", false);
        }
        $(".option-container").click();
    });

    $(document).on("click",".open-button",function() {
        var popup_name = $(this).attr('popup-open');
        $('[popup-name="' + popup_name + '"]').fadeIn(300);
    });

    $(document).on("click","a.close-button",function() {
        var popup_name = $(this).attr('popup-close');
        $('[popup-name="' + popup_name + '"]').fadeOut(300);
    });

    $(document).on("click","a.door-listing",function() {
        $('span.cabinet-doors').trigger('click');
    });

    $(document).on("click","div.color-image",function() {
        $(this).parent().parent().find('div.color-image').removeClass('active');
        $(this).addClass('active');
        var swatchname = $(this).find('img').attr('alt');
        $(this).parent().parent().parent().parent().find('div.door-color-selected h5').html("<strong>Paint/Stain:</strong> "+swatchname);
    });

    $(document).on("click","span.category-list",function() {
        $('div.cabinet-types div').removeClass('active');
        $("div.category-data").addClass('active');
        $(this).closest('div').addClass('active');
    });

    $(document).on("click","span.cabinet-close",function() {
        $("div.cabinet-types").removeClass('active');
        $("div.category-data").removeClass('active');
    });

    $(document).on("click","div.mobile-view a",function() {
        $('div.category-options').addClass('active');
    });

    $(document).on("click","span.left-category-close",function() {
        $('div.category-options').removeClass('active');
    });

    $(document).on("click","div.category-options.active div.mobile-view a",function() {
        $('div.category-options').removeClass('active');
    });

    $(document).on("click","div.category-data.active .cabinet-type-lists > div",function() {
        $('div.category-data').removeClass('active');
    });

    /*Close filter options on side click*/
    $(document).bind('click', function(e) {
        var $clicked = $(e.target);
        if (!$clicked.parents().hasClass("filter-listing")) {
            $(".style-filter-title").removeClass('active');
            $(".filter-listing li ul").hide();
        }
    });

    /**
     * Change price in showing current span
     *
     * As per option selection
     * @return {string} Replace price with updated option selection
     */
    $(document).on("click",".option-container",function() {
        var finalAmount = 0;
        $(this).find('input[type=radio]:checked').each(function(ind, val){
            var dataPrice = $(this).attr('data-price');
            if (typeof dataPrice !== 'undefined' && dataPrice !== null){
                finalAmount +=  parseFloat(dataPrice);
            }
        });
        var qty = $(this).find(".input-text").val();
        finalAmount = finalAmount*qty;
        $(this).find('.price-container span:visible').html("<strong>"+getFormattedPrice(finalAmount)+"</strong>");
    });

    /**
     * Formats the price according to store
     *
     * @param {number} Price to be formatted
     * @return {string} Returns the formatted price
     */
    function getFormattedPrice(price) {
        var priceFormat = {
            decimalSymbol: '.',
            groupLength: 3,
            groupSymbol: ",",
            integerRequired: false,
            pattern: "$%s",
            precision: 2,
            requiredPrecision: 2
        };
        return priceUtils.formatPrice(price, priceFormat);
    }

});
