define([
    'jquery',
    'uiComponent',
    'ko',
    'Magento_Customer/js/customer-data',
    'mage/storage',
    'mage/url',
    'Magento_Checkout/js/model/error-processor',
    'Magento_Ui/js/modal/modal'
], function (
    $,
    Component,
    ko,
    customerData,
    storage,
    mageUrl,
    errorProcessor,
    modal
) {
    'use strict';
    var self;
    return Component.extend({
        sampleProductsData: ko.observableArray([]),
        selectedStyleId         : ko.observableArray(0),
        selectedCabinetLineId   : ko.observableArray(0),
        selectedColorId         : ko.observableArray(0),
        selectedWoodSpecieId    : ko.observableArray(0),
        initialize: function () {
            self = this;
            this._super();
        },
        selectChildCat: function (value) {
            if (typeof (value.image_url) != 'undefined') {
                $('div#cat_id_' + value.parent_cat_id + ' img').attr('src', value.image_url);
            }
            if (typeof (value.sale_tag) != 'undefined') {
                if (value.sale_tag){
                    $('div#sale_cat_id_' + value.parent_cat_id).addClass("sale-discount").text(value.sale_tag);
                }else{
                    $('div#sale_cat_id_' + value.parent_cat_id).text(' ').removeClass('sale-discount');
                }
            }
            if (typeof (value.name) != 'undefined'
                && typeof (value.color_type) != 'undefined') {
                $('.selectedcat_' + value.parent_cat_id).text('');
                $('#selectedcat_' + value.parent_cat_id+'_'+value.color_type).text(value.name);
            }
            if (typeof (value.url) != 'undefined') {
                $('#selectedchildcaturl_' + value.parent_cat_id).attr("href", value.url);
            }
            if (typeof (value.shipping_time) != 'undefined') {
                var shippingtime = value.shipping_time ? 'SHIPPING TIME: ' + value.shipping_time : '';
                $('#shippingtime_' + value.parent_cat_id).text(shippingtime);
            }
            if (typeof (value.style_id) != 'undefined'
                && typeof (value.color_id) != 'undefined'
                && typeof (value.cabinetline) != 'undefined'
                && value.style_id != null
                && value.color_id != null
                && value.cabinetline != null) {
                $('#get-free-sample_'+value.parent_cat_id).attr(
                    {
                        'data-style_id'         : value.style_id,
                        'data-color_id'         : value.color_id,
                        'data-cabinet_line_id'  : value.cabinet_line_id
                    }
                );
                if(typeof (value.woodspecies_id) != 'undefined'
                    && value.woodspecies_id != null){
                    $('#get-free-sample_'+value.parent_cat_id).attr(
                        {
                            'data-wood_type_id'         : value.woodspecies_id
                        }
                    );
                }
                self.sampleProductsData([]);
                $(".samplekit-info").hide();
                $(".product-combination-label").hide();
                $('.select-style-btn-get-free').removeClass('active');
            }

            if (typeof (value.discount_price) != 'undefined'
                && value.discount_price != null
                && typeof (value.regular_price) != 'undefined'
                && value.regular_price != null) {
                var discount_price = value.discount_price ? value.discount_price : '';
                var regular_price = value.regular_price ? value.regular_price : '';
                $('#ten_by_price_' + value.parent_cat_id).show();
                var _tenByClass = '';
                if (discount_price && regular_price && regular_price > discount_price) {
                    $('#ten_by_price_discount_' + value.parent_cat_id).text(discount_price);
                    _tenByClass = 'regular'
                } else {
                    $('#ten_by_price_discount_' + value.parent_cat_id).text('');
                }
                $('#ten_by_price_regular_' + value.parent_cat_id).text(regular_price);
                $('#ten_by_price_regular_' + value.parent_cat_id).addClass(_tenByClass);
            }else{
                $('#ten_by_price_' + value.parent_cat_id).hide();
            }
        },
        isShowMoreSwatch: function (categoryCounts, index) {
            if (categoryCounts == 6) {
                return true;
            }
            if (index > 4) {
                return false;
            }
            return true;
        },
        showCategory: function (category, key) {
            if (typeof (category.cat_id) != 'undefined') {
                $('.category-data-' + category.cat_id +'_'+key+ '.less-color').show();
                $('.less-swatch-' + category.cat_id+'_'+key).show();
                $('.more-swatch-' + category.cat_id+'_'+key).hide();
            }
        },
        hideCategory: function (category ,key) {
            if (typeof (category.cat_id) != 'undefined') {
                $('.category-data-' + category.cat_id +'_'+key+ '.less-color').hide();
                $('.less-swatch-' + category.cat_id+'_'+key).hide();
                $('.more-swatch-' + category.cat_id+'_'+key).show();
            }
        },
        getFreeSample: function (styleData) {
            var styleId = $('#get-free-sample_'+styleData.cat_id).attr('data-style_id');
            if (styleId.length < 0 && typeof(style_id) == 'undefined') {
                return self.sampleProductsData([]);
            }
            self.sampleProductsData([]);
            var getFreeSelector     = "#get-free-sample_"+styleData.cat_id;
            var clickedStyleId      = $(getFreeSelector).attr("data-style_id");
            var samplekitSelector   = "#samplekit_info_"+styleData.cat_id;

            $(".samplekit-info").hide();
            $(".product-combination-label").hide();
            $('.select-style-btn-get-free').removeClass('active');
            $(samplekitSelector).show();
            var isVisibleCurrentSampleKit = $(samplekitSelector).is(':hidden');
            var requiredParam = {
                colorId                 : $(getFreeSelector).attr("data-color_id"),
                cabinetLineId           : $(getFreeSelector).attr("data-cabinet_line_id"),
                styleId                 : clickedStyleId,
                woodTypeId              : $(getFreeSelector).attr("data-wood_type_id"),
                cat_id                  : styleData.cat_id
            };

            self.selectedStyleId(requiredParam.styleId);
            self.selectedCabinetLineId(requiredParam.cabinetLineId);
            self.selectedColorId(requiredParam.colorId);
            self.selectedWoodSpecieId(requiredParam.woodTypeId);

            if ($(samplekitSelector).is(":visible")) {
                $(getFreeSelector).addClass('active');
                self.getFreeSampleProducts(requiredParam);
            }

            return this;
        },
        getFreeSampleProducts: function(requiredParam) {
            $("body").trigger('processStart');
            let sampleProductUrl = mageUrl.build(self.createCustomUrl("/cabinets-sampleproducts/get-by-stylecolor", {}));
            if (parseInt(self.selectedWoodSpecieId()) > 0) {
                sampleProductUrl = mageUrl.build(self.createCustomUrl("/cabinets-sampleproducts/get-by-woodcolor", {}));
            }

            storage.post(
                sampleProductUrl,
                JSON.stringify({
                    colorId             : requiredParam.colorId,
                    cabinetLineId       : requiredParam.cabinetLineId,
                    styleId             : requiredParam.styleId,
                    woodTypeId          : requiredParam.woodTypeId
                }),
                false
            ).done(function (result) {
                self.sampleProductsData(result);
                if(self.sampleProductsData() == ''){
                    var productCombinationSelector   = "#product_combination_"+requiredParam.cat_id;
                    $(productCombinationSelector).show();
                }
                $("body").trigger('processStop');
            }).fail(function (response) {
                $("body").trigger('processStop');
                errorProcessor.process(response);
            });
        },
        createCustomUrl: function(url, params) {
            var config = {
                method: 'rest',
                storeCode: 'default',
                version: 'V1',
                serviceUrl: ':method/:storeCode/:version',
            };
            var completeUrl = config.serviceUrl + url;
            return this.bindParams(completeUrl, params, config);
        },
        bindParams: function (url, params, config) {
            var urlParts;

            params.method = config.method;
            params.storeCode = config.storeCode;
            params.version = config.version;

            urlParts = url.split('/');
            urlParts = urlParts.filter(Boolean);

            $.each(urlParts, function (key, part) {
                part = part.replace(':', '');

                if (params[part] != undefined) { //eslint-disable-line eqeqeq
                    urlParts[key] = params[part];
                }
            });

            return urlParts.join('/');
        },
        addToCartSample: function(sampleProduct) {
            $("body").trigger('processStart');
            var modelOptions = {
                type: 'popup',
                responsive: true,
                innerScroll: true,
                title: 'Attention',
                buttons: false,
                modalClass: 'samecombination'
            };
            var freeProductSku = '',
                free_parent_product_id = '';
            if (typeof(sampleProduct.free_product_sku) != 'undefined') {
                freeProductSku = sampleProduct.free_product_sku;
            }
            if (typeof(sampleProduct.free_parent_product_id) != 'undefined') {
                free_parent_product_id = sampleProduct.free_parent_product_id;
            }
            $('[data-block="minicart"]').trigger('contentLoading');
            $.ajax({
                type: "POST",
                url: self.validationUrl,
                dataType : 'json',
                data: {
                    id              : sampleProduct.product_id,
                    style_id        : self.selectedStyleId(),
                    wood_type_id    : self.selectedWoodSpecieId(),
                    color_id        : sampleProduct.color_id,
                    cabinet_line_id : sampleProduct.cabinet_line_id ? sampleProduct.cabinet_line_id : self.selectedCabinetLineId(),
                    freeProductSku      : freeProductSku,
                    free_parent_product_id : free_parent_product_id
                },
                success: function(result) {
                    if (result) {
                        if(result.designer_quote){
                            var designerpopup = modal(modelOptions, $('#designer-quote-popup-modal'));
                            $("#designer-quote-popup-modal").modal("openModal");
                        }
                        if(result.show_popup){
                            self.resetPopupData();
                            var add_free_product = result.add_free_product;
                            if (result.samecombination) {
                                self.isShowSameCombination(true);
                                self.isShowDiffStylePopup(false);
                                modelOptions.modalClass = 'duplicate-popup-main';
                                var popup = modal(modelOptions, $('#popup-modal'));
                                $("#popup-modal").modal("openModal");
                                $("body").trigger('processStop');
                                $('#close-duplicate').click(function() {
                                    popup.closeModal();
                                    return false;
                                });
                            } else if (result.show_diff_style_popup) {
                                self.isShowSameCombination(false);
                                self.isShowDiffStylePopup(true);

                                self.orgStyleName(result.origstyle_name);
                                self.orgColorName(result.origcolor_name);
                                self.orgStyleImage(result.orig_styleimage);
                                self.orgProductImage(result.product_image);

                                self.dupStyleName(result.dupstyle_name);
                                self.dupColorName(result.dupcolor_name);
                                self.dupStyleImage(result.dup_styleimage);
                                self.dupProductImage(result.dup_product_image);

                                var popup = modal(modelOptions, $('#popup-modal'));
                                $("body").trigger('processStop');
                                $("#popup-modal").modal("openModal");
                                $('#remove-duplicate').click(function() {
                                    popup.closeModal();
                                    return false;
                                });
                                $('._show #popup-modal #continue-duplicate').unbind('click');
                            }
                            if(result.show_diff_style_popup) {
                                $('._show #popup-modal #continue-duplicate').click(function () {
                                    if (!add_free_product) {
                                        freeProductSku = '';
                                        free_parent_product_id = '';
                                    }
                                    /*add to cart*/
                                    self.addDuplicateProductToCart(sampleProduct,freeProductSku,free_parent_product_id);
                                });
                            } else {
                                if (!add_free_product) {
                                    freeProductSku = '';
                                    free_parent_product_id = '';
                                }
                                /*add to cart*/
                                self.addDuplicateProductToCart(sampleProduct,freeProductSku,free_parent_product_id);
                            }
                        }
                        if (result.minicart) {
                            $('[data-block="minicart"]').replaceWith(result.minicart);
                            $('[data-block="minicart"]').trigger('contentUpdated');
                        }
                        if(result.message){
                            $(".message-box").html("");
                            if(result.success){
                                $('.message-box').html('<div class="message-success success message"><div>'+result.message+'</div></div>');
                                $('.action.showcart').trigger("click");
                            }else{
                                $('.message-box').html('<div class="message-error error message"><div>'+result.message+'</div></div>');
                            }
                            $('.message-box').fadeIn('slow').delay(10000).hide(0);
                        }
                    }
                    var sections = ['cart'];
                    customerData.invalidate(sections);
                    customerData.reload(sections, true);
                    $("body").trigger('processStop');
                },
                error: function(result) {
                    $("body").trigger('processStop');
                    errorProcessor.process(result);
                }
            });
        },
    });
});

