/*
 * Commercepundit
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Commercepundit.com license that is
 * available through the world-wide-web at this URL:
 * http://commercepundit.com/license
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category   Commercepundit
 * @package    Commercepundit_WebQuote
 * @copyright  Copyright (c) Commercepundit (http://www.commercepundit.com/)
 * @license    http://www.commercepundit.com/LICENSE-1.0.html
 *
 *
 */

define([
    'jquery',
    'Commercepundit_WebQuote/js/action/submit-filter',
    'Commercepundit_WebQuote/js/action/submit-filter-all',
    'priceUtils',
    'ko'
], function ($, submitFilterAction, submitFilterAllAction, priceUtils, ko) {
    "use strict";

    $.widget('mage.CabinetCategoryOptionSelector', {
        options: {},
        isModelOpen: false,

        /**
         * @private
         */
        _create: function () {
            this._EventListener();
            this._super();
        },

        _EventListener: function () {
            var $widget = this;
            var isAllCabinetPage = false;
            if (typeof $widget.options.isAllCabinetPage != "undefined" && $widget.options.isAllCabinetPage == true) {
                isAllCabinetPage = true;
            }
            $("html body").addClass("page-filter-view");
            var fixmeTop = jQuery(".filter-main-container").offset().top;
            $(window).scroll(function() {
                var currentScroll = jQuery(window).scrollTop();
                if (currentScroll >= fixmeTop) {
                    $('.filter-main-container').addClass('sticky-filter');
                } else {
                    $('.filter-main-container').removeClass('sticky-filter');
                }
            });
            $(document).on('click', '.all-cabinet-widget-listing .category-selection .category-data', function (e) {
                $widget.updateCategoryData($(this));
            });
            $(".common-listing .category-selection .category-data").unbind().click(function () {
                $widget.updateCategoryData($(this));
            });

            $(document).on('click', '.more-swatch', function (e) {
                var cat_id = $(this).attr('data-cat-id'),
                    key = $(this).attr('data-color-type');
                $('.category-data-' + cat_id +'_'+key+ '.less-color').show();
                $('.less-swatch-' + cat_id+'_'+key).show();
                $('.more-swatch-' + cat_id+'_'+key).hide();
            });

            $(document).on('click', '.less-swatch', function (e) {
                var cat_id = $(this).attr('data-cat-id'),
                    key = $(this).attr('data-color-type');
                $('.category-data-' + cat_id +'_'+key+ '.less-color').hide();
                $('.less-swatch-' + cat_id+'_'+key).hide();
                $('.more-swatch-' + cat_id+'_'+key).show();
            });

            $('.style-filter-title').unbind().click(function (e) {
                if ($(e.target).attr("class") != 'sub-filter-listing' && $(e.target).attr("class") != 'filter-selection checkbox') {
                    var indexKey = $(this).attr('data-index');
                    var filterTitleCls = $(".style-filter-title");
                    var filterTitleId  = $("#style_filter_title_"+indexKey);
                    var filterSubCls   = $(".sub-filter-listing");
                    var filterSubId    = $("#sub_filter_listing_"+indexKey);
                    if (filterTitleId.hasClass('active')) {
                        filterTitleCls.removeClass('active');
                        filterSubCls.hide();
                    } else {
                        filterTitleId.addClass('active');
                        filterSubCls.hide();
                        filterSubId.show();
                    }
                }
                else if ($(e.target).attr("class") == 'filter-selection checkbox') {
                    var filterRequest = $widget.createFilterRequest();
                    if (filterRequest) {
                        if (isAllCabinetPage == true) {
                            submitFilterAllAction($widget.options.filterRequestUrl,filterRequest,$widget.options);
                        } else {
                            submitFilterAction($widget.options.filterRequestUrl,filterRequest,$widget.options);
                        }
                    }
                }
            });

            $(document).on('click', '.filter-remove-btn', function (e) {
                var filterKey = $(this).attr('data-filter-key'),
                    filterVal = $(this).attr('data-filter-value');
                $(this).parent().remove();
                if (filterKey && filterVal) {
                    $("input[name='"+filterKey+"'][value='" + filterVal + "']").prop("checked", false);
                    var filterRequest = $widget.createFilterRequest();
                    if (filterRequest) {
                        if (isAllCabinetPage == true) {
                            submitFilterAllAction($widget.options.filterRequestUrl,filterRequest,$widget.options);
                        } else {
                            submitFilterAction($widget.options.filterRequestUrl,filterRequest,$widget.options);
                        }
                    }
                }
            });
            $(document).on('click', '#all-cabinet-widget-load-more', function (e) {
                var nextPage = parseInt($(this).attr('data-page-id')) + 1;
                var filterRequest = $widget.createFilterRequest();
                if (!filterRequest instanceof jQuery){
                    filterRequest = {
                        "filter_orig": {},
                        "filter_request": {},
                        "page": 1
                    };
                }
                filterRequest['page'] = nextPage;
                $('#all-cabinet-widget-load-more').hide();
                var totalPages = parseInt($('#total_pages').val());
                if (!totalPages && typeof $widget.options.totalPages != "undefined") {
                    totalPages = parseInt($widget.options.totalPages);
                }
                if(totalPages > 1 && totalPages >= nextPage) {
                    var _url = $widget.options.filterRequestUrl;
                    submitFilterAllAction($widget.options.filterRequestUrl,filterRequest,$widget.options,true,totalPages,nextPage);
                }
            });

            $(document).on('click', function (e) {
                if ($(e.target).attr("class") != 'sub-filter-listing' &&
                    $(e.target).attr("class") != 'filter-selection checkbox' &&
                    $(e.target).attr("class") != 'style-filter-title' &&
                    $(e.target).attr("class") != 'style-filter-label' &&
                    $(".style-filter-title").hasClass('active')
                ) {
                    var filterTitleCls = $(".style-filter-title");
                    var filterSubCls   = $(".sub-filter-listing");
                    if (filterTitleCls.hasClass('active')) {
                        filterTitleCls.removeClass('active');
                        filterSubCls.hide();
                    }
                }
            });

            $(document).on('click', '.clearFilter, .mobile-filter-reset', function (e) {
                location.reload();
            });

            $(document).on('click', '.category-as-low-as-price', function (e) {
                e.preventDefault();
                $('body').trigger('processStart');
                $widget.isModelOpen = true;
                $widget.openFinancePrequalifyModel();
            });
        },
        updateCategoryData(selectedColorElement) {
            var $widget = this;
            var _parentId = $(selectedColorElement).attr('data-cat-id'),
                discount_price = $(selectedColorElement).attr("data-discount-price"),
                as_low_as_price = $(selectedColorElement).attr("data-as-low-as-price"),
                tenbypercentage = $(selectedColorElement).attr("data-discount-percentage"),
                regular_price = $(selectedColorElement).attr("data-regular-price"),
            sale_text = $(selectedColorElement).attr('data-sale-text');
            $("#cat_image_" + _parentId + " img").addClass("swatch-option-loading");
            $('.selectedcat_' + _parentId).text('');
            $("#selectedcat_"+_parentId+$(selectedColorElement).attr("data-color-type")).text($(selectedColorElement).attr("data-name"));
            $('#shippingtime_' + _parentId).text('SHIPPING TIME: ' + $(selectedColorElement).attr("data-shipping-time"));
            $('#selectedchildcaturl_' + _parentId).attr("href", $(selectedColorElement).attr("data-cat-url"));
            $('#selectedchildcaturlname_' + _parentId).attr("href", $(selectedColorElement).attr("data-cat-url"));
            var isChangesPr = false;
            if (regular_price && regular_price > 0) {
                $('#ten_by_price_' + _parentId).show();
                var _tenByClass = '';
                if (discount_price && discount_price > 0 && parseFloat(regular_price) > parseFloat(discount_price)) {
                    $('#ten_by_price_' + _parentId).find('.sale.sale-discount').show();
                    $('#ten_by_price_discount_' + _parentId).text($widget.getFormatedPrice(discount_price));
                    $('#ten_by_price_percentage_' + _parentId).text(tenbypercentage);
                    isChangesPr = true;
                    if (typeof tenbypercentage == 'undefined') {
                        $('#ten_by_price_' + _parentId).find('.sale.sale-discount').hide();
                        isChangesPr = false;
                    }
                    $('#ten_by_price_regular_' + _parentId).addClass('regular');
                } else {
                    $('#ten_by_price_discount_' + _parentId).text('');
                    $('#ten_by_price_' + _parentId).find('.sale.sale-discount').hide();
                    $('#ten_by_price_regular_' + _parentId).removeClass('regular');
                }
                $('#ten_by_price_regular_' + _parentId).text($widget.getFormatedPrice(regular_price));
                if (parseFloat(as_low_as_price) > 0) {
                    $('#as_low_as_price_' + _parentId).text($widget.getFormatedPrice(as_low_as_price));
                    $('#ten_by_price_' + _parentId).find('.category-as-low-as-price').show();
                } else {
                    $('#as_low_as_price_' + _parentId).text($widget.getFormatedPrice(as_low_as_price));
                    $('#ten_by_price_' + _parentId).find('.category-as-low-as-price').hide();
                }
            } else {
                $('#ten_by_price_' + _parentId).hide();
            }
            if (isChangesPr === false && typeof sale_text != 'undefined' && sale_text != '') {
                $('#ten_by_price_percentage_' + _parentId).text(sale_text);
                $('#ten_by_price_' + _parentId).find('.sale.sale-discount').show();
                $('#ten_by_price_' + _parentId).show();
            }
            $("#cat_image_" + _parentId + " a").attr("href", $(selectedColorElement).attr("data-cat-url"));
            $("#cat_image_" + _parentId + " img").attr({
                'src': $(selectedColorElement).attr("data-image-url"),
                'alt': $(selectedColorElement).attr("data-name")
            });
            $('li[data-cat-id='+_parentId+'].active').removeClass('active');
            $(selectedColorElement).addClass('active');
            $('#get-free-sample_'+_parentId).attr({
                'data-style_id': $(selectedColorElement).attr("data-style_id"),
                'data-color_id': $(selectedColorElement).attr("data-color_id"),
                'data-cabinet_line_id': $(selectedColorElement).attr("data-cabinet_id"),
                'data-wood_type_id': $(selectedColorElement).attr("data-woodspecies_id")
            });
            $(".samplekit-small-detail").remove();
            $(".samplekit-info").hide();
            $(".product-combination-label").hide();
            $('.select-style-btn-get-free').removeClass('active');
            $("#cat_image_" + _parentId + " img").removeClass("swatch-option-loading");
        },
        createFilterRequest: function () {
            var $filterCheckboxes = $('input:checkbox.filter-selection');
            var filterRequest = {
                "filter_orig": {},
                "filter_request": {},
                "page": 1
            };
            filterRequest.filter_orig["categories_id"] = $("input[name=orig_cat_id]").val();
            $("li.style-filter-title").map(function () {
                filterRequest.filter_orig[$(this).attr("data-name")] = $(this).attr("data-orig-" + $(this).attr("data-name"));
            });
            $($filterCheckboxes.filter(":checked")).map(function () {
                if (typeof filterRequest.filter_request[this.name] != "undefined" && filterRequest.filter_request[this.name] != null) {
                    var value = filterRequest.filter_request[this.name];
                    if ((value != "undefined" || value != null) && value.length) {
                        value = value + "," + this.value;
                        filterRequest.filter_request[this.name] = value;
                    }
                    else {
                        filterRequest.filter_request[this.name] = this.value;
                    }
                } else {
                    filterRequest.filter_request[this.name] = this.value;
                }
            });
            return filterRequest;
        },
        getFormatedPrice: function (price) {
            var currencyFormat = this.options.currencyFormat;
            var priceFormat = {
                decimalSymbol: '.',
                groupLength: 3,
                groupSymbol: ",",
                integerRequired: false,
                pattern: currencyFormat,
                precision: 2,
                requiredPrecision: 2
            }
            return priceUtils.formatPrice(price, priceFormat);
        },
        openFinancePrequalifyModel: function () {
            var $widget = this;
            if (typeof window.BreadPayments !== 'undefined') {
                if ($widget.isModelOpen == false) {
                    $('body').trigger('processStop');
                    return false;
                }
                if ($('#bread-placement-1').length) {
                    $('#bread-placement-1').html('');
                } else {
                    $("#custom_cabinet_Data").append('<div id="bread-placement-1"></div>');
                }
                let pre_bread_sdk = window.BreadPayments;
                pre_bread_sdk.setup({
                    integrationKey: this.options.breadIntegrationKey,
                    containerID: 'bread-placement-1'
                });

                let pre_placementObject = {
                    allowCheckout: false,
                    financingType: "installment",
                    locationType: "checkout",
                    domID: 'bread-placement-1'
                };
                pre_bread_sdk.setInitMode('manual');
                pre_bread_sdk.setEmbedded(false);
                pre_bread_sdk.__internal__.setAutoRender(false);
                pre_bread_sdk.registerPlacements([pre_placementObject]);

                pre_bread_sdk.on('INSTALLMENT:APPLICATION_DECISIONED', () => {});
                pre_bread_sdk.on('INSTALLMENT:APPLICATION_CHECKOUT', () => {});
                pre_bread_sdk.on('INSTALLMENT:INITIALIZED', () => {
                    if ($widget.isModelOpen == false) {
                        const e = document.querySelector("[id*=zoid-checkout-component]");
                        e && e.remove();
                    }
                });
                pre_bread_sdk.on("INSTALLMENT:CUSTOMER_OPEN", (location,opts) => {
                    $('body').trigger('processStop');
                    if ($widget.isModelOpen == false) {
                        const e = document.querySelector("[id*=zoid-checkout-component]");
                        e && e.remove();
                    }
                });
                pre_bread_sdk.on("INSTALLMENT:CUSTOMER_CLOSE", (opts) => {
                    $widget.isModelOpen = false;
                    const e = document.querySelector("[id*=zoid-checkout-component]");
                    e && e.remove();
                });

                pre_bread_sdk.init();
                pre_bread_sdk.openExperienceForPlacement([pre_placementObject]);
            }
        },
    });
    return $.mage.CabinetCategoryOptionSelector;
})
