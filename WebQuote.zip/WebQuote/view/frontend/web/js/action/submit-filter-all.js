/*
 * Commercepundit
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Commercepundit.com license that is
 * available through the world-wide-web at this URL:
 * http://commercepundit.com/license
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category   Commercepundit
 * @package    Commercepundit_Customer
 * @copyright  Copyright (c) Commercepundit (http://www.commercepundit.com/)
 * @license    http://www.commercepundit.com/LICENSE-1.0.html
 *
 *
 */

define([
    'jquery',
    'mage/storage',
    'ko'
], function ($, storage, ko) {
        'use strict';
    return function (url, filterRequest, options,isLoadMore = false,totalPages = 1,nextPage = 1) {
        $("body").trigger('processStart');
        if ($('.filter-main-container').hasClass('sticky-filter')) {
            $('.filter-main-container').removeClass('sticky-filter');
        }
        return storage.post(
            url,
            JSON.stringify(filterRequest)
        ).done(
            function (response) {
                var loadMoreDiv = null;
                var wrapper = null;
                var html = $(response);
                if (typeof options.loadMoreDiv != "undefined") {
                    loadMoreDiv = '#'+options.loadMoreDiv;
                }
                if (typeof options.listingDiv != "undefined") {
                    wrapper = '#'+options.listingDiv;
                }
                var updatedWrapper = html.find(wrapper);
                if (updatedWrapper.length && updatedWrapper.children().length > 0) {
                    if (isLoadMore == true) {
                        $(wrapper).append(updatedWrapper.html()).trigger('contentUpdated');
                    } else {
                        $(wrapper).html(updatedWrapper.html()).trigger('contentUpdated');
                    }
                    $(".showEmptyRecordsMsg").hide();
                } else {
                    $(wrapper).html(null);
                    $(".showEmptyRecordsMsg").show();
                    if (loadMoreDiv && $(loadMoreDiv).length) {
                        $(loadMoreDiv).hide();
                        $(loadMoreDiv).attr('data-page-id',1);
                    }
                }


                if (isLoadMore != true) {
                    var totalPagesInput = '#total_pages';
                    var updatedTotalPages = html.find(totalPagesInput);
                    if (updatedTotalPages.length) {
                        $(totalPagesInput).val(updatedTotalPages.val());
                        if (updatedTotalPages.val() <= 1) {
                            if (loadMoreDiv && $(loadMoreDiv).length) {
                                $(loadMoreDiv).hide();
                                $(loadMoreDiv).attr('data-page-id',1);
                            }
                        } else if (updatedTotalPages.val() > 1) {
                            if (loadMoreDiv && $(loadMoreDiv).length) {
                                $(loadMoreDiv).show();
                                $(loadMoreDiv).attr('data-page-id',1);
                            }
                        }
                    }
                    var selectedFilters = '#original-selected-filter';
                    var updatedSelectedFilters = html.find(selectedFilters);
                    if (updatedSelectedFilters.length) {
                        $('#web-selected-filter').html(updatedSelectedFilters.html());
                        $('#mobile-selected-filter').html(updatedSelectedFilters.html());
                    }
                } else {
                    if (loadMoreDiv && $(loadMoreDiv).length) {
                        if(totalPages <= nextPage) {
                            $(loadMoreDiv).hide();
                        } else {
                            $(loadMoreDiv).show();
                        }
                        $(loadMoreDiv).attr('data-page-id',nextPage);
                    }
                }

                ko.cleanNode($('.custom_cabinet_section')[0]);
                ko.applyBindings(this, $('.custom_cabinet_section')[0]);
                if (options.isEnabledYotpo && options.isEnabledYotpo == true &&
                    typeof Yotpo !== 'undefined') {
                    var api = new Yotpo.API(yotpo);
                    api.refreshWidgets();
                }
            }
        ).fail(
            function (response) {
                $('.errormsgcabinets').show();
            }
        ).always(
            function (response) {
                if (isLoadMore != true) {
                    if ($('.filter-main-container').length) {
                        $('html, body').animate({
                            scrollTop: parseFloat($('.filter-main-container').offset().top - 100)
                        }, "slow", function () {
                            $('html,body').clearQueue();
                        });
                    }
                }
                $('body').trigger('processStop');
            }
        );
    }
    }
);
