/*
 * Commercepundit
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Commercepundit.com license that is
 * available through the world-wide-web at this URL:
 * http://commercepundit.com/license
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category   Commercepundit
 * @package    Commercepundit_Customer
 * @copyright  Copyright (c) Commercepundit (http://www.commercepundit.com/)
 * @license    http://www.commercepundit.com/LICENSE-1.0.html
 *
 *
 */

define([
    'jquery',
    'mage/storage',
    'mage/apply/main',
    'ko'
], function ($, storage, mage, ko) {
        'use strict';
    var categoryContainer = $('.custom_cabinet_section');
    return function (url, filterRequest, options) {
        $("body").trigger('processStart');
        if ($('.filter-main-container').hasClass('sticky-filter')) {
            $('.filter-main-container').removeClass('sticky-filter');
        }
        return storage.post(
            url,
            JSON.stringify(filterRequest)
        ).done(
            function (response) {
                if (response.category) {
                    categoryContainer.html(response.category);
                }
                ko.cleanNode(categoryContainer[0]);
                $(categoryContainer).applyBindings();
                if (mage) {
                    mage.apply();
                }
                if ($(".category-content").length <= 0) {
                    $(".showEmptyRecordsMsg").show();
                }
                $("#web-selected-filter").html($("#original-selected-filter").html());
                $("#mobile-selected-filter").html($("#original-selected-filter").html());
                if (options.isEnabledYotpo && options.isEnabledYotpo == true &&
                    typeof Yotpo !== 'undefined') {
                    var api = new Yotpo.API(yotpo);
                    api.refreshWidgets();
                }
            }
        ).fail(
            function (response) {
                $('.errormsgcabinets').show();
            }
        ).always(
            function (response) {
                if ($('.filter-main-container').length) {
                    $('html, body').animate({
                        scrollTop: parseFloat($('.filter-main-container').offset().top - 100)
                    }, "slow", function () {
                        $('html,body').clearQueue();
                    });
                }
                $('body').trigger('processStop');
            }
        );
    }
    }
);
