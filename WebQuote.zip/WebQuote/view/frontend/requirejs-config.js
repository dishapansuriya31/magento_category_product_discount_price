/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

 var config = {
    map: {
        '*': {
            slick: 'Commercepundit_WebQuote/js/slick',
            'productCustomOption': 'Commercepundit_WebQuote/js/productCustomOption'
        }
    },
    paths: {
        slick: 'Commercepundit_WebQuote/js/slick'
    },
    shim: {
        slick: {
            deps: ['jquery']
        }
    }
};
