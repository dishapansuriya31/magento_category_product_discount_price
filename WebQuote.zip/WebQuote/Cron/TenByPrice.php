<?php
/*
 *  Commercepundit
 *
 *  NOTICE OF LICENSE
 *
 * This source file is subject to the Commercepundit.com license that is
 * available through the world-wide-web at this URL:
 * http://commercepundit.com/license
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category   Commercepundit
 * @package    Commercepundit_Customer
 * @copyright  Copyright (c) Commercepundit (http://www.commercepundit.com/)
 * @license    http://www.commercepundit.com/LICENSE-1.0.html
 *
 */

namespace Commercepundit\WebQuote\Cron;

use Commercepundit\WebQuote\Model\TenByTenPrice;
use Magento\Catalog\Model\ProductRepository;
use Magento\Catalog\Model\ResourceModel\Category\CollectionFactory as CategoryCollectionFactory;
use Magento\Framework\Exception\LocalizedException;
use Magento\Eav\Model\Entity\Attribute\Source\Boolean;
use Magento\Store\Model\StoreManagerInterface;

/**
 * class TenByPrice
 *
 * Fetch and save ten by price data.
 */
class TenByPrice
{
    /**
     * @var CategoryCollectionFactory
     */
    private $_categoryCollectionFactory;

    /**
     * @var ProductRepository
     */
    private $_productRepository;

    /**
     * @var TenByTenPrice
     */
    private $_tenBypriceModel;

    /**
     * @var StoreManagerInterface
     */
    protected $storeManager;

    /**
     * @param CategoryCollectionFactory $categoryCollectionFactory
     * @param ProductRepository $productRepository
     * @param TenByTenPrice $tenByTenPrice
     */
    public function __construct(
        CategoryCollectionFactory $categoryCollectionFactory,
        ProductRepository         $productRepository,
        TenByTenPrice             $tenByTenPrice,
        StoreManagerInterface $storeManager
    ) {
        $this->_categoryCollectionFactory = $categoryCollectionFactory;
        $this->_productRepository = $productRepository;
        $this->_tenBypriceModel = $tenByTenPrice;
        $this->storeManager = $storeManager;
    }

    /**
     * Execute.
     *
     * @return void
     */
    public function execute()
    {
        try {
            $websiteId = $this->storeManager->getDefaultStoreView()->getWebsiteId();
            $storeId = $this->storeManager->getWebsite($websiteId)->getDefaultStore()->getId();
            $categoryCollection = $this->_categoryCollectionFactory->create()
                ->addAttributeToFilter('ten_by_price_sku', ['neq' => 'NULL'])
                ->addAttributeToFilter('is_show_ten_by_ten_add_to_cart_button', Boolean::VALUE_YES)
                ->addAttributeToFilter('ten_by_ten_update_price', Boolean::VALUE_YES);
            if ($categoryCollection->getSize()) {
                foreach ($categoryCollection as $category) {
                    $this->_tenBypriceModel->fetchTenByPrice($category,$storeId);
                }
            }
        } catch (LocalizedException|\Exception $e) {
            $this->printLog($e->getMessage());
        }
    }

    /**
     * Logger.
     *
     * @param mixed $log
     * @return void
     */
    public function printLog($log)
    {
        $writer = new \Laminas\Log\Writer\Stream(BP . '/var/log/tenByPriceCron.log');
        $logger = new \Laminas\Log\Logger();
        $logger->addWriter($writer);
        $logger->debug($log);
    }
}
