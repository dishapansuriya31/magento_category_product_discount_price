<?php
/*
 *  Commercepundit
 *
 *  NOTICE OF LICENSE
 *
 * This source file is subject to the Commercepundit.com license that is
 * available through the world-wide-web at this URL:
 * http://commercepundit.com/license
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category   Commercepundit
 * @package    Commercepundit_WebQuote
 * @copyright  Copyright (c) Commercepundit (http://www.commercepundit.com/)
 * @license    http://www.commercepundit.com/LICENSE-1.0.html
 *
 */

namespace Commercepundit\WebQuote\Cron;

use Commercepundit\WebQuote\Model\TenByTenPrice;
use Magento\Framework\App\ResourceConnection;
use Magento\Store\Model\StoreManagerInterface;

/**
 * class AsLowAsPrice
 *
 * Fetch and save AsLowAs Price data.
 */
class AsLowAsPrice
{
    /**
     * @var TenByTenPrice
     */
    private $tenByTenPrice;

    /**
     * @var StoreManagerInterface
     */
    private $storeManager;

    /**
     * @var ResourceConnection
     */
    public $resourceConnection;

    /**
     * @param TenByTenPrice $tenByTenPrice
     * @param StoreManagerInterface $storeManager
     * @param ResourceConnection $resourceConnection
     */
    public function __construct(
        TenByTenPrice $tenByTenPrice,
        StoreManagerInterface $storeManager,
        ResourceConnection $resourceConnection
    ) {
        $this->tenByTenPrice = $tenByTenPrice;
        $this->storeManager = $storeManager;
        $this->resourceConnection = $resourceConnection;
    }

    /**
     * Execute.
     *
     * @return void
     */
    public function execute()
    {
        try {
            $websiteId = $this->storeManager->getDefaultStoreView()->getWebsiteId();
            $storeId = $this->storeManager->getWebsite($websiteId)->getDefaultStore()->getId();
            $connection = $this->resourceConnection->getConnection();
            $select = $connection->select()
                ->from(
                    $connection->getTableName('cp_ten_by_ten_price'),
                    ['category_id' => 'DISTINCT(entity_id)']
                );
            $categoryIds = $connection->fetchAll($select);
            if (!empty($categoryIds)) {
                foreach ($categoryIds as $categoryId) {
                    $this->tenByTenPrice->fetchAsLowAsPrice($categoryId,$storeId);
                }
            }
        } catch (\Exception $e) {
            $this->printLog($e->getMessage());
        }
    }

    /**
     * Logger.
     *
     * @param mixed $log
     * @return void
     */
    public function printLog($log)
    {
        $writer = new \Laminas\Log\Writer\Stream(BP . '/var/log/asLowAsPriceCron.log');
        $logger = new \Laminas\Log\Logger();
        $logger->addWriter($writer);
        $logger->debug($log);
    }
}
