<?php

declare(strict_types=1);

namespace Commercepundit\WebQuote\Cron;

use \Psr\Log\LoggerInterface;

class NewCategoryLabelcron
{
    protected $logger;
    protected $checkCron;
    protected $newcategorylabel;
    protected $scopeConfig;
    protected $storeManager;

    public function __construct(
        LoggerInterface $logger,
        \Commercepundit\WebQuote\Model\NewCategoryLabel $newcategorylabel,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Store\Model\StoreManagerInterface $storeManager
    )
    {

        $this->logger = $logger;
        $this->newcategorylabel = $newcategorylabel;
        $this->scopeConfig = $scopeConfig;
        $this->storeManager = $storeManager;
    }

    public function execute()
    {
        $isEnable = $this->getConfigValue('new_category_label_section/new_category_label_cron/enable_cron');
        if (!$isEnable) {
            return $this;
        }
        $this->newcategorylabel->changeLabelInfo();
        return $this;
    }

    

    public function getConfigValue($path)
    {
        return $this->scopeConfig->getValue($path, \Magento\Store\Model\ScopeInterface::SCOPE_STORE, $this->storeManager->getStore()->getStoreId());
    }
}
